# STELLAR LEGACY — V117.3.1 • HOTFIX VENDA HALO

Atualização INCREMENTAL para a V117.3 (não substituir com ZIP cumulativo anterior).
Instalação: colocar este ZIP na raiz do GitHub e executar Actions → Instalador Universal.

## Corrigido
- Venda de drones Halo/Nova verificada contra o save oficial antes da operação.
- Não exige que o save genérico do navegador, bloqueado por conflito de Hangar, termine antes de vender um drone cuja montagem já está confirmada.
- Se a montagem local divergir, avisa e solicita consentimento para recarregar a montagem oficial. Não remove nem vende nada nessa etapa; piloto revê o drone e confirma novamente.
- Depois da venda, atualiza Hangar e inventário com a resposta autoritativa do servidor, incluindo os equipamentos devolvidos.
- Previne cliques simultâneos de venda e não envia preço, saldo ou equipamento do cliente para cobrança.
- Mantém o controle de zona segura, farm offline, transações protegidas, PvP, Autopilot e todas as medidas de integridade da V117.3.

## Validação
- npm run check: 282 arquivos JavaScript sintaticamente válidos, 0 imports ausentes.
- npm test: 485/485 aprovados na base V117.3, incluindo 5 novos testes da V117.3.1.
- Nada de SQL novo, nenhuma escrita direta nas contas.

## Homologação real obrigatória
- Na própria base X-1/X-8, selecionar um Halo com equipamento, confirmar venda, verificar crédito e retorno do laser ao inventário.
- Se aparecer aviso de montagem diferente, revisar e confirmar a recuperação do Hangar; depois tentar vender novamente.
- Reconectar e validar a contagem de drones, as duas configurações de batalha e os saldos.
- Somente após isso afirmar que a correção funcionou no Android/Render.
