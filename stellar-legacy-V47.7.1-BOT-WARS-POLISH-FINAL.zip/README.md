# STELLAR LEGACY V47.7.1 — BOT WARS POLISH

Instalador PATCH para o GitHub `main` que ja esteja na versao V47.7.0. Envie SOMENTE este ZIP para a raiz do repositorio e rode o instalador universal.

- **IA v2:** bots priorizam pilotos inimigos em alcance quando o ADM habilita ataque a jogadores no modo conquista; alvos tem verificacao de sessao ativa, faccao, distancia e zonas seguras. Contra bots eles flanqueiam/orbitam ou recuam quando muito danificados. Bots possuem classes INTERCEPTOR, ASSALTO, GUARDIAO e SUPORTE.
- **Treinamento:** ao atingir um bot, ele reage com dano SIMULADO e nao retira HP da conta.
- **Sprites:** reutiliza imagens existentes `public/assets/v2212/ships/*-map.webp` de Terra, Marte e Jupiter, carregadas pelo cache do jogo, sem baixar assets adicionais no ZIP.
- **Minimapa:** exibe mapa atual por ex. MAPA 4-2 no painel expandido ou recolhido.
- **UNIVERSO:** o mesmo botao sai da posicao flutuante para a barra de botoes do menu principal, preservando ID e listeners originais.

**Sem SQL novo.** Mantem a tabela `stellar_warbot_events_v477` e configuracoes do ADM, saves, economia, relés, recompensas e login intactos. Bots desligados por padrao na configuracao original.

`npm run check` aplica a integracao idempotente e verifica a versao dos recursos; `npm test` executa a suite completa na Action. Novos testes isolados testam tiros em pilotos, treino, zona segura, sprites, minimapa, controle ADM e integridade do multiplayer.
