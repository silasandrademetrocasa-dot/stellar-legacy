import assert from 'node:assert/strict';import fs from 'node:fs';
import {decodeGlb} from '../public/modules/stellar-ship3d-v50.js';
const f='public/assets/v52_3',game=fs.readFileSync('public/game.js','utf8');
assert(game.includes('STELLAR_VISUAL_FLEET_V52_3'));
assert(game.includes("from './modules/stellar-ship3d-v50.js?v=47.7.6'"),'cache-busting V47.7.6');
assert(game.includes('drawAssetAt(ctx,\'ore_\''));
assert(game.includes('drawAssetAt(ctx,\'box_loot\''));
assert(game.includes('drawAsset(ctx,\'box_bonus\''));
let ok=0;
for(const id of ['aux9',...['streuner','recruitStreuner','aiderStreuner','bossStreuner','lordakia','bossLordakia','saimon','bossSaimon','mordon','bossMordon','devolarium','bossDevolarium','sibelon','bossSibelon'].map(x=>'npc_'+x),...['Prometium','Endurium','Terbium','Prometid','Duranium','Promerium','Xenomit'].map(x=>'ore_'+x),...['bonus','loot','mystery','elite','repair','ammo'].map(x=>'box_'+x)]){
  const path=`${f}/models/${id}.glb`,png=`${f}/cards/${id}.png`;
  assert(fs.existsSync(path)&&fs.existsSync(png),id);
  const raw=fs.readFileSync(path),buf=raw.buffer.slice(raw.byteOffset,raw.byteOffset+raw.byteLength);
  assert(decodeGlb(buf).length>0,'malha: '+id);ok++;
}
for(const id of ['phoenix','leonov','liberator','piranha','vengeance','bigboy','goliath','citadel','aegis','spearhead','defcom','yamato','nostromo'])assert(fs.existsSync(`${f}/cards/ship_${id}.png`));
const mod=fs.readFileSync('public/modules/stellar-ship3d-v50.js','utf8');
assert(mod.includes('/assets/v52_3/models/ore_Prometium.glb'));
assert(mod.includes('/assets/v52_3/models/aux9.glb'));
assert(mod.includes('Math.PI/2+angle'));
console.log(`✅ V52.3 verificada: 13 naves, ${ok} GLBs, cache busting e sprites 2D`);
