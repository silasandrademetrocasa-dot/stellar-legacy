/* Stellar Legacy V52.3: unified premium assets, V47.7.6 cache fix.
 * Never touches balance/auth/cargo/merchant/combat logic.
 * Runs after V52 patch; supports re-run safely.
 */
import fs from 'node:fs';import assert from 'node:assert/strict';
const file='public/game.js',mark='STELLAR_VISUAL_FLEET_V52_3';
let src=fs.readFileSync(file,'utf8');
assert(src.includes('STELLAR_VISUAL_FLEET_V52_0'),'Instale V52 antes da V52.3');
const changed=!src.includes(mark);
// Cache busting required by historical V47.7.6 release validator.
// Import may be present since V50.1 and must be updated even on repeated runs.
const old="from './modules/stellar-ship3d-v50.js';";
const newer="from './modules/stellar-ship3d-v50.js?v=47.7.6';";
if(src.includes(old))src=src.replace(old,newer);
assert(src.includes(newer),'V52.3 import do renderizador sem versão');
if(changed){
  assert(src.includes('/assets/v52/cards/'),'V52.3: cards V52 não encontrados');
  src=src.replaceAll('/assets/v52/cards/','/assets/v52_3/cards/');
  // Only render extra 3D map resources at HIGH quality; retain premium classic
  // 2D cards in MEDIUM and LOW to protect older Android performance.
  function mutate(fn,until,needle,replacement,label){
    const a=src.indexOf(fn),b=src.indexOf(until,a+fn.length);
    assert(a>=0&&b>a,'V52.3 função ausente: '+label);
    const seg=src.slice(a,b);
    assert(seg.split(needle).length===2,'V52.3 âncora '+label+' não é única');
    src=src.slice(0,a)+seg.replace(needle,replacement)+src.slice(b);
  }
  mutate('function drawOres(){','function drawLoot(){',
    '  if(img&&img.naturalWidth){',
    `  if(resolvedQualityMode()==='high'&&STELLAR_3D_V50.drawAssetAt(ctx,'ore_'+o.type,(o.rot||0)+nowSec()*.08,Math.max(26,o.r*3.2),p.x,p.y))continue;\n  if(img&&img.naturalWidth){`,
    'ore 3D');
  mutate('function drawBonusBoxes(){','function createOres(){',
    '    if(img?.naturalWidth){',
    `    if(resolvedQualityMode()==='high'&&STELLAR_3D_V50.drawAsset(ctx,'box_bonus',0,size*scale)){}\n    else if(img?.naturalWidth){`,
    'bonus 3D');
  mutate('function drawLoot(){','function drawNpcModel(',
    '  if(img&&img.naturalWidth){',
    `  if(resolvedQualityMode()==='high'&&STELLAR_3D_V50.drawAssetAt(ctx,'box_loot',0,42*pulse,p.x,p.y))continue;\n  if(img&&img.naturalWidth){`,
    'loot 3D');
  src='/* '+mark+' */\n'+src;
}
fs.writeFileSync(file,src);
console.log('✅ V52.3: rotação, loja/hangar, AUX, 14 NPCs e resources/box 3D alto + sprites clássicos no médio/baixo; import cache busting corrigido');
