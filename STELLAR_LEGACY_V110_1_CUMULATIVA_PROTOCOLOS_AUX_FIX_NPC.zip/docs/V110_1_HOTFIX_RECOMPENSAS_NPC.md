# V110.1 — Recuperação da V106.9 sem perder os Protocolos AUX V110

## Causa raiz

A versão V110.0 incluiu o `server/index.js` construído de um snapshot antigo.
A substituição omitiu `grantNpcRewardSafelyV1069` e o caminho `readReceipt` para
recuperar recompensas de NPC após timeout, que eram exigidos pelo teste
`tests/v1069-npc-reward-delivery.test.mjs`. O instalador GitHub recusou o
pacote no passo **Validar projeto**; a publicação não foi efetuada.

## Correção cumulativa

- `server/index.js`: restaura import e a integração `grantNpcRewardSafelyV1069({grant,readReceipt})`, sem modificar o handler `applyAuxAdvancedActionV110`.
- `server/world.js`: preserva a ordenação dos abates do mesmo proprietário antes dos awaits, pontua Elite após confirmação de recompensa e registra recuperações de recibo.
- `server/npc-reward-delivery-v1069.js`: inclui helper idempotente e fila, mesmo se o arquivo não tiver permanecido no repositório.
- `tests/v1069-npc-reward-delivery.test.mjs` + `tests/v1101-aux-npc-compatibility.test.mjs`: evitam regressões futuras da integração, sem desabilitar testes legados.
- Mantém **todos** os arquivos funcionais da V110.0: 15 protocolos, loja, craft, UI, itens, CONF1/CONF2 e persistência.

## Não altera

Não adiciona SQL, não modifica saldo, preço ou recompensa, não remove proteção
antifraude, não altera regras do loot; não cria pagamentos no cliente.

## Resultado da validação

`npm run verify`: 317/317 testes aprovados na base de código local, incluindo 8 casos V106.9
(e 2 novos da V110.1), sem deploy real ao GitHub ou Render.

## Teste de homologação após publicar

1. Confirmar GitHub Actions (Validar projeto e Publicar somente se testes passarem).
2. Confirmar rede e login Web; AUX permanece visível e os 15 protocolos aparecem com as artes V109.
3. Comprar um protocolo I, equipar em CONF 1, mudar para CONF 2, retornar e sincronizar.
4. Farmar 10 a 20 NPCs de missão; conferir que o avanço e a economia não regridem.
5. Recarregar sem criar bônus duplos, revisar logs `npc-reward` / `SAVE_NPC_STALE`.
