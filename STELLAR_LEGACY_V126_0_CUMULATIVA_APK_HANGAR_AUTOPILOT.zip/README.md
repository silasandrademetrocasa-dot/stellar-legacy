# V126.0 — APK, Hangar e Autopilot

**Cumulativa única**: inclui as alterações V121–V125 da distribuição anterior e correções V126.

- Hangar CONF1/CONF2: se a resposta da gravação falhar, confirma apenas após comparação com o save do servidor.
- Autopilot: verificações de recuperação e decisões com cadência reduzida no Android; não altera combate.
- Porão/vendas permanecem validados no servidor; esses gargalos ainda precisam de medição de latência.
- SQL V126: **nenhum**. Não zerar saves nem ativar enforce.
- Testes: npm run check e npm test (570 aprovados).

Detalhes: docs/V126_0_APK_PERFORMANCE_CONFIRM_SAVE.md

---

## Histórico V125

# Stellar Legacy V125.0 — ECONOMIA + LOCAL-FIRST, UM DEPLOY

Contém cumulativamente as V121, V122, V123 e as alterações V125 sobre o projeto.
Base de instalação verificada: V122.0 (47.7.61) ou V123.0 (47.7.62).
Instale SOMENTE este arquivo ZIP via workflow Instalador Universal.

O SQL não destrutivo `sql/STELLAR_V125_0_ECONOMY_OPERATION_RECEIPTS.sql` já foi aplicado no projeto Supabase stellar-legacy; NÃO precisa executar novamente.

Mudanças V125:
- Vendas, ações econômicas comuns e compras de munição em lote com recibos duráveis e comparação da revisão econômica.
- ID de requisição permanece após desconexão e é retirado somente após resposta confirmada.
- Replays de compras em lote retornam a operação original mesmo que preço do catálogo tenha mudado.
- Preserva compras V123 e a recuperação de resgate do Farm, save local-first e checkpoints V121/V122.

Limites: as RPCs NPC, Passe, missões, PvP, leilão, clãs, Warfront e a liquidação original do Farm ainda são escritores legados e NÃO foram consolidadas nesta versão. NÃO ativar enforce nem apagar dados.
Testes Node automatizados não são equivalentes a teste no Android, multiplayer real ou Farm de 8h.
Leia docs/V125_0_CUMULATIVA_ECONOMIA_RECONCILIACAO.md.
