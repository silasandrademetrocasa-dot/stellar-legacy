# Stellar Legacy — Hotfix do instalador + Target + AUX-9

## Por que o instalador falhava
`npm run check` executava `scripts/v4776-apply-patch.mjs`, que é um **script de migração** (alteração do código fonte), não um validador. A V47.7.6 já está aplicada; o script tenta substituir trechos antigos novamente e para em `expected 1 anchor, got 0`. A publicação fica bloqueada antes do commit.

## O que este PATCH faz
- Altera somente `package.json > scripts.check` para executar `node scripts/verify-release.mjs`, que **valida** a integridade do projeto sem modificar arquivos. `npm test` e `check:v21` continuam no fluxo normal.
- Inclui a correção de interface da aba Target (fechada só seta, aberta com informações).
- Inclui a nova arte branca/ciano do AUX-9 para o Hangar. O comportamento do jogo, equipamentos e progressão não mudam.
- **Sem SQL, sem alterações nos saves.**

## Instalação
1. Na raiz do repositório GitHub, **remova o ZIP anterior que falhou** (se ele ainda estiver lá).
2. Envie somente este ZIP para a raiz do `main` (não descompacte manualmente).
3. Execute o workflow `Stellar Legacy — Instalador Universal`.
4. O workflow aplicará os 3 arquivos do patch e validará o projeto. Publicará somente com todos os testes aprovados.

O script `scripts/v4776-apply-patch.mjs` não é apagado, apenas deixa de rodar automaticamente em cada check; a migração já está incorporada na versão atual.
