# STELLAR LEGACY V113.1 — FORJA AUX-9 • APEX & UNIVERSO

Instalar SOMENTE sobre a V113.0 (ou uma base posterior com os mesmos arquivos) usando Instalador Universal.
ZIP incremental. Nao inclui jogo inteiro.

## Regras
N1 continua na loja (Dano/HP/Escudo 50k STL; Box/Porao 100M CR por unidade).
N2: 4 N1 da MESMA familia + 10 Fragmentos Apex + 250k STL (AUX LV8, na base).
N3: 4 N2 da MESMA familia + 10 Fragmentos Universo + 500k STL + 180M CR (AUX LV15, no Universo).
Apex Overlord: 10% de 1 fragmento por abate online confirmado.
Universo U-1/U-2/U-3: 10% de 1 fragmento por abate online confirmado.
Somente dono do abate recebe fragmentos, com recibo unico no Supabase; Farm Offline nao e alterado.

## ADM
Lojas > AUX permite ajustar os precos de montagem (respeitando pisos) e as chances dos drops (0-25%).
Receita 4 protocolos anteriores + 10 fragmentos nao pode ser modificada no frontend.

## Banco
Tabelas e RPC de fragmentos aplicadas e verificadas no Supabase. Os 5 precos de fabricacao foram gravados no catalogo.
**NAO EXECUTE SQL DO ZIP NOVAMENTE.** O script incluso serve de referencia/historico.

## Instalacao
1. Deixe apenas o ZIP V113.1 na raiz do repositorio.
2. Execute GitHub Actions > Instalador Universal.
3. Confirme que todos os testes passam e o Render faz deploy.
4. Reabra o navegador para carregar o game.js e novo modulo v1131.
5. Valide craft N2/N3 em conta de teste e confira o saldo do servidor.

## Validacao
380 testes automatizados + auditoria de imports/arquivos (npm run check). Mais a simulacao do Instalador Universal.
A migracao SQL foi confirmada; drops reais e crafts reais precisam de homologacao em jogo apos deploy.

## Preservado
Autopilot V112, Farm Offline V111.1, combate V113, visual, Designers, CONF1/2, recompensas de NPC e arquivos de mapa.
O server/world.js foi baseado na V113.0 e altera apenas o argumento do abate para marcar o dono elegivel ao drop.
