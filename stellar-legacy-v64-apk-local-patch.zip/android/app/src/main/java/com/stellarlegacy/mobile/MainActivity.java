package com.stellarlegacy.mobile;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.webkit.WebViewAssetLoader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * APK V64: codigo e graficos sao locais. Somente /api/*, /ws e endpoints
 * explicitos seguem para Render. Nunca incluir chaves privilegiadas ou saves aqui.
 */
public final class MainActivity extends Activity {
    private WebView webView;
    private String baseUrl;
    private String trustedHost;
    private Set<String> localFiles = Collections.emptySet();
    private WebViewAssetLoader localLoader;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(3, 8, 22));
        getWindow().setNavigationBarColor(Color.rgb(3, 8, 22));

        baseUrl = BuildConfig.STELLAR_SERVER_URL;
        Uri base = Uri.parse(baseUrl);
        trustedHost = base.getHost();
        if (!"https".equals(base.getScheme()) || trustedHost == null) {
            showError("Configuracao HTTPS invalida. Recompile com STELLAR_SERVER_URL.");
            return;
        }
        try { localFiles = readFileList(); }
        catch (IOException e) {
            showError("Arquivos locais incompletos. Recompile o APK.");
            return;
        }
        localLoader = new WebViewAssetLoader.Builder()
                .setDomain(trustedHost)
                .addPathHandler("/", this::handleAsset)
                .build();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(3, 8, 22));
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // O jogo e escrito em JS.
        settings.setDomStorageEnabled(true); // Apenas sessao/aparencia local, nao saldo offline.
        settings.setDatabaseEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebChromeClient(new WebChromeClient());
        // Nao adicionar addJavascriptInterface: JS nao ganha acesso a APIs nativas privilegiadas.
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!isOwnDomain(uri)) return null;
                String path = uri.getEncodedPath();
                if (path == null || path.isEmpty() || "/".equals(path)) path = "/index.html";
                // Comunicacao autentica com o backend; WebSocket nao passa por este interceptor.
                if (path.equals("/api") || path.startsWith("/api/") || path.equals("/health")) return null;
                // Falha fechada: arquivos desconhecidos nao caem na rede por engano.
                if (!localFiles.contains(path.substring(1))) return failClosed();
                WebResourceResponse response = localLoader.shouldInterceptRequest(uri.buildUpon().encodedPath(path).build());
                return response == null ? failClosed() : response;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (isOwnDomain(uri)) return false;
                // Links externos somente no navegador do aparelho, nunca recebem o JS do jogo.
                if ("https".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                }
                return true;
            }
        });
        // A raiz do servidor permanece a origem da pagina; /, CSS, JS e graficos vem do APK.
        // Isso preserva caminhos /api/*, ws://... e a autenticacao existente sem CORS novo.
        webView.loadUrl(baseUrl + "/");
    }

    private boolean isOwnDomain(Uri uri) {
        return "https".equals(uri.getScheme()) && trustedHost.equalsIgnoreCase(uri.getHost())
                && uri.getPort() == -1;
    }

    private Set<String> readFileList() throws IOException {
        Set<String> files = new HashSet<>();
        try (InputStream stream = getAssets().open("www/stellar-local-files.txt");
             BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) if (!line.isEmpty()) files.add(line);
        }
        if (!files.contains("index.html") || !files.contains("game.js") || !files.contains("api.js"))
            throw new IOException("Local files missing");
        return Collections.unmodifiableSet(files);
    }

    private WebResourceResponse handleAsset(String relativePath) {
        // Chamado apenas para arquivos publicados e incluídos no manifesto gerado.
        if (relativePath == null || !localFiles.contains(relativePath)) return failClosed();
        try {
            InputStream bytes = getAssets().open("www/" + relativePath);
            WebResourceResponse response = new WebResourceResponse(mimeType(relativePath),
                    isText(relativePath) ? "UTF-8" : null, bytes);
            Map<String, String> headers = new HashMap<>();
            headers.put("Cache-Control", "private, max-age=0");
            headers.put("X-Content-Type-Options", "nosniff");
            response.setResponseHeaders(headers);
            return response;
        } catch (IOException e) { return failClosed(); }
    }

    private static boolean isText(String path) {
        return path.endsWith(".html") || path.endsWith(".js") || path.endsWith(".css")
                || path.endsWith(".json") || path.endsWith(".svg") || path.endsWith(".webmanifest")
                || path.endsWith(".txt");
    }
    private static String mimeType(String p) {
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".js")) return "text/javascript";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".webmanifest")) return "application/manifest+json";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".glb")) return "model/gltf-binary";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".ico")) return "image/x-icon";
        if (p.endsWith(".woff2")) return "font/woff2";
        if (p.endsWith(".woff")) return "font/woff";
        return "application/octet-stream";
    }
    private static WebResourceResponse failClosed() {
        WebResourceResponse response = new WebResourceResponse("text/plain", "UTF-8",
                new java.io.ByteArrayInputStream("Arquivo local ausente".getBytes(StandardCharsets.UTF_8)));
        response.setStatusCodeAndReasonPhrase(404, "Not Found");
        return response;
    }
    private void showError(String message) {
        TextView label = new TextView(this);
        label.setText(message);
        label.setPadding(40, 80, 40, 40);
        label.setTextColor(Color.WHITE);
        label.setBackgroundColor(Color.rgb(3, 8, 22));
        setContentView(label);
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
