# 🚀 Stellar Legacy V64 — Android APK LOCAL (base web 47.7.20)

## Objetivo e formato

Todos os 728 arquivos do diretório `public/` são considerados para o pacote. O build inclui
os recursos públicos reais (HTML/CSS/JS, WebP, PNG, 125 GLBs e demais assets) na instalação Android.
**O APK NÃO contém o backend `server/`, banco, tabelas SQL, tokens persistentes nem a chave service_role.**
O motor do jogo é a base V64 do seu ZIP. A web continua existindo, mas o foco agora é APK.

O WebView abre a raiz HTTPS do seu Render. `WebViewAssetLoader` responde LOCALMENTE com os arquivos
que já estão no APK, usando o MESMO domínio HTTPS: `/`, `/index.html`, `/game.js`, `/assets/*`,
`/modules/*`, `/icons/*` etc. **Somente** `/api/*` e `/health` passam normalmente para a rede;
`wss://DOMINIO/ws` permanece rede real via WebSocket. Recursos locais desconhecidos retornam 404,
sem download de fallback da versão web. O Supabase continua sendo acessado pela configuração
pública retornada pelo servidor e sob as regras existentes de autenticação e segurança.

### Economia e segurança

- Tudo que possa alterar moeda, XP, minério, inventário, compras, drops e recompensas
  deve continuar validado no Render/Supabase, **nunca por escrita local/offline**.
- `game_saves` e `profiles` permanecem no banco; o `/api/save` existente mantém seus guards,
  verificações de revisão e validação. Não foi feita migração de saldo para o celular.
- A `SUPABASE_SERVICE_ROLE_KEY` e outras credenciais privadas devem existir SOMENTE nas variáveis
  privadas do Render. **Nunca** em GitHub Variables, recursos do APK ou JavaScript.
- A `STELLAR_SERVER_URL` é endereço **público**, não segredo.
- Se não houver conexão, gráficos locais aparecem, mas login, salvamento, compra e combate
  online não vão funcionar. Não inventar recompensas offline para sincronizar depois.
- A migração local não equivale a uma auditoria de segurança completa do SQL/RLS ou da lógica
  do servidor. Antes de distribuição ampla, auditar políticas RLS, RPCs e operações de crédito.

### Limitações desta primeira versão

- Google OAuth dentro de WebView é restringido pelo Google; o botão Google foi ocultado
  **somente no APK**. E-mail e senha permanecem disponíveis. Futuramente usar Android App Links
  + navegador externo/Custom Tabs para login Google. Reset de senha por link precisa ser testado
  com a configuração de redirect do Supabase.
- Push do service worker/PWA desativado SOMENTE no APK (nativo poderá ser integrado depois).
- Alterar a interface ou sprites embutidos requer lançar novo APK. Alterar dados do servidor
  não requer rebuild quando o protocolo continuar compatível. Evite atualizações incompatíveis.
- APK debug gerado por GitHub Actions pode ter chave diferente a cada execução:
  para atualizar o jogo instalado SEM reinstalar, use release assinado com uma mesma chave guardada.
- `applicationId` inicial: `com.stellarlegacy.mobile`. Escolha um identificador definitivo
  ANTES de distribuir, pois mudá-lo faz o Android tratar como outro aplicativo.

## Como compilar pelo GitHub (sem Android Studio)

1. Envie **somente o ZIP de patch** `stellar-legacy-v64-apk-local-patch.zip` para a RAIZ
   do repositório GitHub que já possui a V64 atual. Deixe somente **um ZIP** na raiz.
2. Em **Actions > 🚀 Stellar Legacy — Instalador Universal > Run workflow**,
   instale o patch. Esse workflow aplicará `android/`, dois scripts e este README,
   sem substituir `server/`, `public/`, `sql/` ou o seu save/banco atual.
3. Depois crie o workflow novo em `.github/workflows/stellar-apk-local-v64.yml`
   com o arquivo YAML fornecido **separadamente**. O instalador universal protege
   `.github/`, por isso propositalmente não tenta atualizar workflows.
4. GitHub > **Settings > Secrets and variables > Actions > Variables > New repository variable**.
5. Nome: `STELLAR_SERVER_URL`. Valor: endereço HTTPS principal do jogo, por exemplo
   `https://darkorbit-legacy.onrender.com` **se este ainda for o domínio ativo**.
   Não use `http://`, barra final ou `/api`.
6. GitHub > **Actions > 🚀 Stellar Legacy V64 — APK Local > Run workflow**.
   Deixe `build_release` desmarcado para o primeiro teste.
7. Após o workflow concluir, abra a execução > **Artifacts** e baixe
   `Stellar-Legacy-V64-APK-Local-Teste`. Extraia o `.zip` do artifact para encontrar o `.apk`.
8. Instale o APK no Android e confira login por e-mail, uso de sprites/GLB,
   WebSocket, save, moedas após relogar, compras/recompensas e reconexão.

### APK release assinado (atualizações estáveis)

Crie uma keystore FORA do repositório e mantenha cópia segura, por exemplo:

```bash
keytool -genkeypair -v -keystore stellar-release.jks -alias stellar -keyalg RSA -keysize 3072 -validity 10000
base64 -w0 stellar-release.jks  # salvar resultado somente em GitHub Actions Secrets
```

Em Settings > Secrets and variables > Actions > Secrets, configure:
`STELLAR_KEYSTORE_BASE64`, `STELLAR_KEYSTORE_PASSWORD`, `STELLAR_KEY_ALIAS`,
`STELLAR_KEY_PASSWORD`. NÃO compartilhe estes valores por chat nem adicione ao ZIP.
Depois execute o workflow com `build_release=true`.

**Atenção:** mantenha a MESMA keystore e o MESMO `applicationId` para permitir atualização
sem reinstalação. Guarde backup da chave: perdê-la pode impedir futuras atualizações.

## Compilar localmente no Android Studio (alternativo)

Requer Node >=18, Android SDK 36, JDK 17, Gradle 8.13 e conexão durante a compilação
para baixar dependências Android (não para baixar os assets do jogo depois de instalado).

```bash
node scripts/prepare-apk-assets.js
node scripts/verify-apk.js
cd android
STELLAR_SERVER_URL=https://SEU-SERVIDOR.onrender.com gradle :app:assembleDebug
```

O arquivo estará em `android/app/build/outputs/apk/debug/app-debug.apk`.

## Auditoria rápida depois de instalar

No Android, faça login e reproduza os fluxos principais; compare saldo e itens ao relogar
na web. Tentar editar `sessionStorage`/assets do APK NUNCA deve conceder recursos reais.
Toda operação de economia necessita validação no servidor e política RLS restritiva.
O processo de atualização deve manter versões de app e backend compatíveis.
