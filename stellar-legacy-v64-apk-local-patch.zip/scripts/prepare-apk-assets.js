#!/usr/bin/env node
/**
 * Replica APENAS public/ para dentro do app. Nada de backend, SQL, .env, saves ou segredos.
 * Gera lista fechada de recursos embarcados. Nao altera a versao web original.
 */
import {cpSync,rmSync,mkdirSync,readFileSync,writeFileSync,readdirSync,statSync,existsSync} from 'node:fs';
import {join,resolve,relative} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(fileURLToPath(new URL('..',import.meta.url)));
const src=join(root,'public');
const dest=join(root,'android/app/src/main/assets/www');
if (!existsSync(join(src,'index.html')) || !existsSync(join(src,'game.js')) || !existsSync(join(src,'api.js'))) throw new Error('public/ incompleto');
rmSync(dest,{recursive:true,force:true});
mkdirSync(dest,{recursive:true});
cpSync(src,dest,{recursive:true,filter:(source)=>{
  const name=relative(src,source).replaceAll('\\','/');
  return !name.startsWith('.') && !name.endsWith('.map') && name !== 'sw.js';
}});
// Service Worker/PWA web desativado SOMENTE no APK (sem push do navegador/prompt de instalar PWA).
const pwa=join(dest,'modules/v21/pwa.js');
if(!existsSync(pwa))throw new Error('Modulo PWA nao encontrado, a estrutura mudou');
writeFileSync(pwa,
  '// APK LOCAL: sem Service Worker, instalacao PWA ou cache que faca fallback para a web.\n'
  +'export function registerStellarPwaV21() {}\n'
  +'export async function offerInstallV21() { return false; }\n');
// Google OAuth bloqueia login de navegadores incorporados. Login com email/senha permanece disponivel.
// Adicionar Custom Tabs + App Links em uma futura etapa para habilitar OAuth de maneira suportada.
const indexFile=join(dest,'index.html');
let html=readFileSync(indexFile,'utf8');
if (!html.includes('</head>'))throw new Error('HTML sem head');
html=html.replace('</head>',
  '<!-- APK LOCAL: o Google OAuth em WebView requer fluxo nativo externo. -->\n'
  +'<style id="stellar-apk-local">#googleLoginArea,#installStellarApp{display:none!important}</style>\n'
  +'</head>');
writeFileSync(indexFile,html);
const files=[];let bytes=0;
function walk(path){for(const d of readdirSync(path,{withFileTypes:true})){
  const f=join(path,d.name);
  if(d.isDirectory())walk(f);
  else if(d.isFile()){
    const sub=relative(dest,f).replaceAll('\\','/');
    if(sub.startsWith('.')||sub.includes('/.'))throw new Error('Arquivo oculto suspeito: '+sub);
    if(!/\.(html|css|js|json|webmanifest|webp|png|jpe?g|svg|glb|ico|woff2?|ttf|mp3|ogg|wav)$/i.test(sub))
      throw new Error('Arquivo nao previsto no APK: '+sub);
    files.push(sub);bytes+=statSync(f).size;
  }
}};
walk(dest);files.sort();
writeFileSync(join(dest,'stellar-local-files.txt'),files.join('\n')+'\n');
const count=(prefix)=>files.filter(p=>p.startsWith(prefix)).length;
if(!files.includes('index.html')||!files.includes('game.js')||count('assets/')<200)throw new Error('Pacote de jogo incompleto');
console.log(`OK APK local: ${files.length} arquivos, ${(bytes/1048576).toFixed(2)} MiB; 0 arquivos do server/sql/saves; web original preservada.`);
