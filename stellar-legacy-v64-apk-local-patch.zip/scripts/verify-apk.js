#!/usr/bin/env node
import {readFileSync,existsSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const root=resolve(fileURLToPath(new URL('..', import.meta.url)));
const web=join(root,'public'), bundled=join(root,'android/app/src/main/assets/www');
const file=(base,p)=>readFileSync(join(base,p),'utf8');
const index=file(bundled,'index.html');
const files=file(bundled,'stellar-local-files.txt').trim().split('\n');
assert(files.length>=600, 'Faltando recursos do Stellar Legacy');
for(const f of files){
 assert(!f.includes('..')&&!f.startsWith('/'),'Caminho perigoso '+f);
 assert(existsSync(join(bundled,f)),'Arquivo nao encontrado '+f);
 assert(!/^(server|sql|tests|scripts)\//.test(f),'Segredo/codigo de backend no APK');
}
assert(index.includes('stellar-apk-local'));
assert(!file(bundled,'modules/v21/pwa.js').includes('serviceWorker.register'));
assert(file(web,'modules/v21/pwa.js').includes('serviceWorker.register'),'Nao alterar a web');
assert(file(web,'index.html')!==index,'HTML local nao adaptado');
assert(file(web,'game.js')===file(bundled,'game.js'),'Logica do cliente divergiu');
assert(file(web,'api.js')===file(bundled,'api.js'),'Protocolo da API divergiu');
assert(!file(bundled,'stellar-local-files.txt').includes('sw.js'),'SW nao deve ir no APK');
const native = file(join(root,'android/app/src/main/java/com/stellarlegacy/mobile'),'MainActivity.java');
assert(native.includes('path.startsWith("/api/")') && native.includes('WebViewAssetLoader'));
assert(!native.includes('addJavascriptInterface(') || native.includes('// Nao adicionar addJavascriptInterface'));
console.log(`OK: ${files.length} arquivos locais completos, economia/API do cliente inalteradas, servidor fora do APK.`);
