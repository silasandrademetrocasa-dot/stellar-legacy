# STELLAR LEGACY V117.0 — CUMULATIVA COM FOCO TOTAL EM V116.7

Pacote incremental único: incorpora V116.4, V116.5 e mudanças V116.6–V116.8.
Base interna: 47.7.60; execute o Instalador Universal na raiz do GitHub.
SEM SQL NOVO. Sem mudança em save, inventário, crédito, Farm Offline, lojas e drops.

MELHORIAS PRINCIPAIS:
• Perfil Alto em Android: orçamento 30 FPS; DPR adaptativo do Canvas sem baixar arte/sprites.
• Atualizações WebSocket NPC em índice por ID, evitando busca O(n²) por lote.
• NPCs fora da câmera têm interpolação visual mais espaçada; bosses, targets e eventos sempre atualizados.
• Menos etiquetas distantes no Alto Mobile, preservando sprite e inimigos importantes.
• Agenda e varredura de entidades de evento em 500 ms, mantendo simulação/combate 20Hz.
• Relatório de performance e microbenchmark reproduzível.
• Testes de regressão cobrem segurança de compras, NPCs, missão e Farm Offline.

AUDITORIA:
Conferir docs/v117/LEIA_PRIMEIRO_V117_CUMULATIVA.md.
A meta 30 FPS exige homologação real no Moto E7; teste sintético não é FPS real.
SAVE_NPC_STALE segue pendente, não foi burlado nem removido.
