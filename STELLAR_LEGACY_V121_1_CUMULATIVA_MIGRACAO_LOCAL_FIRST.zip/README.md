# Stellar Legacy — Base V121.0 (laboratório)

- [Roadmap e inventário do jogo](docs/ROADMAP_STELLAR_LEGACY_V121.md)
- [Catálogo com os nomes oficiais](docs/CATALOGO_OFICIAL_STELLAR_LEGACY_V121.md)
- [Procedimento local-first e segurança](docs/ARQUITETURA_LOCAL_FIRST_V121.md)
- [Limpeza auditada do repositório](docs/LIMPEZA_GITHUB_V121.md)

## Instalação

1. Salve o ZIP original do projeto e o backup do banco.
2. Coloque **somente o ZIP incremental V121** na raiz do repositório.
3. Execute **Instalador Universal** no GitHub Actions; o workflow verifica o código antes do commit.
4. No Web/Render, abra `/lab-v121.html` para testar IndexedDB com catálogo do jogo.
5. Para espelhamento opt-in no jogo real: `/?localfirst=1`. Sem essa opção o funcionamento V120 permanece o mesmo.
6. A migração de Créditos/STL, lojas, leilão, PvP e Farm para o gateway local-first ainda não está finalizada. Não ativar `enforce`.
7. `sql/STELLAR_V121_0_CATALOGO_OFICIAL_PREPARAR.sql` é a migração opcional para criar a tabela canônica de nomes; sem alteração dos IDs legados.

> Versão do `package.json`: 47.7.60. O rótulo V121.0 identifica a etapa arquitetural, sem mudança no protocolo de rede de produção.
