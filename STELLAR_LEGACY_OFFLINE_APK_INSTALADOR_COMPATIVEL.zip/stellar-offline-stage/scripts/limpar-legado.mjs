// Acao EXPLICITA e destrutiva para substituir somente arquivos rastreados no Git.
// A manifestacao de hashes evita apagar o jogo antigo se o bundle offline estiver incompleto.
import fs from 'node:fs';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
if(process.env.STELLAR_CONFIRM !== 'SUBSTITUIR_LEGADO_V130_POR_OFFLINE'){
 console.error('Confirme a substituicao pelo workflow manual.');process.exit(2);
}
const manifest=JSON.parse(fs.readFileSync('OFFLINE_BUNDLE_MANIFEST.json','utf8'));
const expected=new Set(Object.keys(manifest.files));
expected.add('OFFLINE_BUNDLE_MANIFEST.json');
let missing=[];
for(const [file,sha] of Object.entries(manifest.files)){
 if(!fs.existsSync(file)){missing.push(file);continue;}
 const digest=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
 if(digest!==sha)missing.push(file+' (hash diferente)');
}
if(missing.length){console.error('Bundle incompleto ou alterado! Abortando sem apagar.',missing.slice(0,20));process.exit(3);}
const tracked=execFileSync('git',['ls-files','-z'],{encoding:'utf8'}).split('\0').filter(Boolean);
const old=tracked.filter(file=>!expected.has(file));
console.log('Arquivos online legados identificados:',old.length);
for(const path of old){
 if(path.startsWith('.git/'))throw Error('Caminho proibido');
 fs.rmSync(path,{force:true});
}
console.log('Legado removido no workspace. Para concluir, fazer git add -A, commit e push.');
