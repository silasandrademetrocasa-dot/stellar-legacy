#!/usr/bin/env node
// Full offline repository replacement. Runs ONLY by explicit GitHub Actions workflow.
// All changes are made in a temporary CI checkout; commit happens only after tests/build.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';

if(process.env.STELLAR_CONFIRM !== 'ATIVAR_STELLAR_OFFLINE_COMPLETO'){
  console.error('Activation requires explicit confirmation ATIVAR_STELLAR_OFFLINE_COMPLETO');
  process.exit(2);
}
const root=process.cwd();
const stage=path.join(root,'stellar-offline-stage');
const manifest=JSON.parse(fs.readFileSync(path.join(stage,'OFFLINE_BUNDLE_MANIFEST.json'),'utf8'));
const files=Object.entries(manifest.files ?? {});
if(manifest.format!=='stellar-offline-replacement-v2' || files.length<110) throw Error('Offline manifest incomplete');
const preservedWorkflow='.github/workflows/ativar-offline-completo.yml';
if(!fs.existsSync(path.join(root,preservedWorkflow))) throw Error('Activation workflow missing');
for(const [rel,sha] of files){
  if(rel.includes('\\') || path.posix.isAbsolute(rel) || rel.split('/').includes('..') || rel.split('/').includes('.') || rel==='stellar-offline-stage' || rel.startsWith('stellar-offline-stage/')) throw Error('Unsafe path '+rel);
  const source=path.join(stage,rel); const st=fs.lstatSync(source);
  if(!st.isFile() || st.isSymbolicLink()) throw Error('Invalid source '+rel);
  const digest=crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex');
  if(digest!==sha) throw Error('Offline file changed or corrupted: '+rel);
}
for(const [rel] of files){
  const source=path.join(stage,rel); const target=path.join(root,rel);
  fs.mkdirSync(path.dirname(target),{recursive:true});
  for(let p=path.dirname(target); p!==root && p!==path.dirname(root); p=path.dirname(p)){
    if(fs.lstatSync(p).isSymbolicLink()) throw Error('Target symlink '+p);
  }
  if(fs.existsSync(target) && fs.lstatSync(target).isSymbolicLink()) throw Error('Target symlink '+rel);
  fs.copyFileSync(source,target);
}
const keep=new Set([...files.map(([f])=>f),preservedWorkflow]);
const tracked=execFileSync('git',['ls-files','-z'],{encoding:'utf8'}).split('\0').filter(Boolean);
for(const rel of tracked){
  if(keep.has(rel))continue;
  if(rel.startsWith('.git/'))throw Error('Protected git metadata');
  const full=path.join(root,rel);
  if(fs.existsSync(full)){
    const stat=fs.lstatSync(full);
    if(stat.isFile()||stat.isSymbolicLink())fs.unlinkSync(full);
  }
}
fs.rmSync(stage,{recursive:true,force:true});
console.log('Offline replacement staged: '+files.length+' file(s). Removed legacy paths from checkout: '+(tracked.filter(x=>!keep.has(x)).length));
