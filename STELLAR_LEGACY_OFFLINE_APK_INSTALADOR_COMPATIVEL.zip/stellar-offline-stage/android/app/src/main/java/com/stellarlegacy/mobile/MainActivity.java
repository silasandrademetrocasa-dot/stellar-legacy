package com.stellarlegacy.mobile;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.io.ByteArrayInputStream;
import org.json.JSONObject;

/** Android offline: APK inclui 100% do game e assets. Nunca abre URL de servidor. */
public final class MainActivity extends Activity {
    private static final String ORIGIN="https://appassets.androidplatform.net";
    private static final int EXPORT=7001, IMPORT=7002;
    private static final int MAX_BACKUP_BYTES=8*1024*1024;
    private WebView game;
    private String pendingExport;
    private WebViewAssetLoader loader;
    @Override public void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);
        loader=new WebViewAssetLoader.Builder()
            .addPathHandler("/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        game=new WebView(this);
        game.setBackgroundColor(Color.rgb(4,8,21));
        game.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        game.setLayerType(WebView.LAYER_TYPE_HARDWARE,null);
        WebSettings cfg=game.getSettings();
        cfg.setJavaScriptEnabled(true);cfg.setDomStorageEnabled(true);cfg.setDatabaseEnabled(true);
        cfg.setAllowFileAccess(false);cfg.setAllowContentAccess(false);
        cfg.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        cfg.setBlockNetworkLoads(true);
        cfg.setCacheMode(WebSettings.LOAD_NO_CACHE);
        cfg.setMediaPlaybackRequiresUserGesture(true);
        cfg.setJavaScriptCanOpenWindowsAutomatically(false);
        cfg.setSupportMultipleWindows(false);
        // Apenas codigo empacotado pode chamar esta ponte; dominio externo bloqueado.
        game.addJavascriptInterface(new LocalBackup(),"StellarNativeBackup");
        game.setWebChromeClient(new WebChromeClient());
        game.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req){
                Uri u=req.getUrl();
                if(!"https".equals(u.getScheme()) || !"appassets.androidplatform.net".equalsIgnoreCase(u.getHost())){
                    return forbidden();
                }
                WebResourceResponse local=loader.shouldInterceptRequest(u);
                return local==null?forbidden():local;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                Uri u=request.getUrl();
                return !"https".equals(u.getScheme()) || !"appassets.androidplatform.net".equalsIgnoreCase(u.getHost());
            }
        });
        setContentView(game);
        game.loadUrl(ORIGIN+"/index.html");
    }
    private WebResourceResponse forbidden(){
        return new WebResourceResponse("text/plain","UTF-8",403,"Forbidden",
            java.util.Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }
    private class LocalBackup {
        @JavascriptInterface public void exportSave(String json){
            if(json==null||json.length()>MAX_BACKUP_BYTES)return;
            runOnUiThread(()->{
                pendingExport=json;
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE,"stellar-offline-save.json");
                startActivityForResult(i,EXPORT);
            });
        }
        @JavascriptInterface public void importSave(){
            runOnUiThread(()->{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                startActivityForResult(i,IMPORT);
            });
        }
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try{
            if(requestCode==EXPORT && pendingExport!=null){
                try(OutputStream o=getContentResolver().openOutputStream(uri)){
                    if(o==null)throw new Exception("Destino indisponivel");
                    o.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                }
                pendingExport=null;
                Toast.makeText(this,"Backup salvo",Toast.LENGTH_SHORT).show();
            }else if(requestCode==IMPORT){
                byte[] bytes;
                try(InputStream in=getContentResolver().openInputStream(uri);
                    ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    if(in==null)throw new Exception("Arquivo indisponivel");
                    byte[] buffer=new byte[8192];int n;
                    while((n=in.read(buffer))!=-1){
                        if(out.size()+n>MAX_BACKUP_BYTES)throw new Exception("Backup muito grande");
                        out.write(buffer,0,n);
                    }
                    bytes=out.toByteArray();
                }
                String content=new String(bytes,StandardCharsets.UTF_8);
                game.evaluateJavascript("window.StellarNativeImport("+JSONObject.quote(content)+")",null);
            }
        }catch(Exception e){Toast.makeText(this,"Falha no backup: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    @Override protected void onPause(){
        if(game!=null)game.evaluateJavascript("window.StellarOfflineFlush&&window.StellarOfflineFlush()",null);
        super.onPause();
    }
    @Override public void onBackPressed(){
        if(game!=null){game.evaluateJavascript("document.querySelector('#panelLayer')?.hidden===false ? document.querySelector('#closePanel')?.click() : null",null);}
        else super.onBackPressed();
    }
    @Override protected void onDestroy(){
        if(game!=null){game.stopLoading();game.destroy();game=null;}
        super.onDestroy();
    }
}
