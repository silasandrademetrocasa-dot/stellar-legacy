# Stellar Legacy — Universo Solo • APK Android offline

**Entrega de substituicao integral para um repositorio limpo.**
Este pacote e o codigo-fonte completo de uma versao SOLO/LOCAL do jogo. **Nao e a migracao integral e identica de todas as telas e modulos da antiga V130 online.** Ele foi construido a partir do prototipo offline de recuperacao, com arte local e nucleo offline independente.

## Android normal (nao requer GitHub Pages)

1. Em um **branch limpo** do repositorio oficial, substitua os arquivos antigos pelos do ZIP (ver cuidados abaixo). `web/` contem as artes e o motor completo do jogo offline.
2. Em **Actions**, execute **Stellar Legacy - APK 100% Offline** → **Run workflow**. Opcao `build_release=false` gera APK debug instalavel.
3. Abra o run concluido, secao **Artifacts**, baixe **Stellar-Legacy-Offline-APK**; extraia o `.apk` e instale no Android.
4. O app abre a tela embutida `https://appassets.androidplatform.net/index.html`, atendida **inteiramente pelos arquivos internos do APK**. Nao abre GitHub Pages e nao depende de Wi-Fi/4G, Render ou Supabase.
5. Para release assinado, configurar os secrets `STELLAR_KEYSTORE_BASE64`, `STELLAR_KEYSTORE_PASSWORD`, `STELLAR_KEY_ALIAS`, `STELLAR_KEY_PASSWORD` e usar `build_release=true`.
6. Compilacao local, com Android SDK 35 + Java 17 + Gradle 8.9: `gradle -p android :app:assembleDebug`.

### Assinatura e instalacao sobre APK antigo

O ID Android foi mantido `com.stellarlegacy.mobile` para manter a identidade, **mas um APK debug assinado com chave diferente NAO atualiza o APK anterior**. Antes de desinstalar o jogo antigo, preserve quaisquer saves antigos pela opcao de exportacao disponivel nele. O save solo nao e automaticamente migrado da V130. Se desinstalar, pode perder os dados locais do aplicativo anterior. Assinar com a MESMA chave dos APKs anteriores possibilita atualizacao, mas ainda assim o save online e offline sao incompativeis.

## Substituir o repositorio original com seguranca

**Nao basta apenas enviar o ZIP por um instalador que so adiciona arquivos**: arquivos e workflows antigos de Render/Supabase ainda permanecerao no repositorio, mesmo se nao forem usados pelo APK. Para remover mesmo o legado, use uma branch de backup e substitua a arvore inteira pelos arquivos deste ZIP com `git rm -r` (com excecao de `.git`) antes de copiar, fazer commit e push. Se o repositorio atual tem arquivos privados nao incluídos neste pacote, preserve-os antes da limpeza.

Se usar um instalador ZIP que apenas sobrepoe conteudos, voce ainda pode gerar o novo APK desde que copie **`web/`, `android/`, `package.json`, `tests/` e `.github/workflows/gerar-apk-offline.yml`**, mas para remover definitivamente o codigo antigo voce precisara apaga-lo no repositorio.

## Saves e gameplay

- IndexedDB e a unica autoridade de persistencia; fila unica de operacoes; checksum; checkpoints A/B/C; resgate de Farm ate 8h.
- Venda do porao desconta recurso e adiciona creditos no mesmo snapshot persistido; sem resposta remota.
- Exportacao/importacao de save JSON pela opcao **Ajustes** e seletor nativo de arquivos Android.
- 43 naves, recursos com os nomes Ferron/Cryon/Virel/Ferrite/Duracite/Solarium/Voidite, 33 setores, batalha, coleta, loja, hangar, CONF1/CONF2, farm, missao, eventos individuais, relay 12h escudo + 12h disputa local.
- **Nao existe multiplayer sincronizado entre dispositivos** nem leilao/PvP real; clãs inimigos podem apenas ser simulados. Economia online nao migra para esta build.
- Nunca limpe dados do aplicativo sem antes exportar o save. A protecao do IndexedDB nao substitui copia externa.

## Testes

`npm test` e `npm run check`. Os testes nao substituem a compilacao APK no GitHub e o teste final em Android fisico.
