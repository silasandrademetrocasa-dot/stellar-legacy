export const resources = [
 {id:'Prometium',name:'Ferron',price:1000,icon:'ore_Prometium.png'},
 {id:'Endurium',name:'Cryon',price:1500,icon:'ore_Endurium.png'},
 {id:'Terbium',name:'Virel',price:2500,icon:'ore_Terbium.png'},
 {id:'Prometid',name:'Ferrite',price:10000,icon:'ore_Prometid.png'},
 {id:'Duranium',name:'Duracite',price:15000,icon:'ore_Duranium.png'},
 {id:'Promerium',name:'Solarium',price:35000,icon:'ore_Promerium.png'},
 {id:'Xenomit',name:'Voidite',price:0,icon:'ore_Xenomit.png'}
];
export const shipIds = 'aurora pioneer pathfinder vanguard gale meridian striker lynx viper raptor kensei shogun valkyrie leviathan helios sovereign seraph wraith prism mirage nullifier guardian bulwark bastion ironclaw lancer reclaimer venatrix plaguewing hellrunner echo gravastar stormrider ravager praetor interdictor doppel nexus-prime leviathan-x lumina warden phantom concord'.split(' ');
export const ships = shipIds.map((id,i)=>({id,name: id.split('-').map(x=>x[0].toUpperCase()+x.slice(1)).join(' '),hp:16000+i*2000,shield:12000+i*1850,damage:280+i*42,speed:170+(i%7)*12,price:i===0?0:Math.round((90000+i*i*30000)/1000)*1000}));
export const enemies=[
 {name:'Scavenger',hp:1100,dmg:90,credit:2200,stl:1,sprite:'streuner.webp'},
 {name:'Vrax',hp:2800,dmg:140,credit:4700,stl:2,sprite:'mordon.webp'},
 {name:'Zyron',hp:5200,dmg:200,credit:9300,stl:4,sprite:'saimon.webp'},
 {name:'Kharon',hp:9000,dmg:300,credit:17800,stl:7,sprite:'devolarium.webp'},
 {name:'Dreadnox',hp:18000,dmg:470,credit:38000,stl:13,sprite:'bossMordon.webp'},
 {name:'Colossar',hp:44000,dmg:770,credit:90000,stl:31,sprite:'bossSaimon.webp'}
];
export const maps = [
 ...['1','2','3'].flatMap(zone=>Array.from({length:8},(_,i)=>`${zone}-${i+1}`)),
 '4-1','4-2','4-3','U-1','U-2','U-3','Aurora','Nexus','Eclipse'
];
export const mapLabel=(id)=>id.startsWith('1-')?'Terra':id.startsWith('2-')?'Marte':id.startsWith('3-')?'Júpiter':id.startsWith('4-')?'PvP':id.startsWith('U-')?'Universo':'Astral';
export const mapImage=(id)=>`./assets/world/${/^([1234]-[1-8]|U-[123])$/.test(id)?id.replace('-','_'):'4_1'}_baixo.webp`;
export const shopItems=[
 {id:'laser_arc1',name:'Laser ARC-1',type:'laser',currency:'credits',price:16000,bonus:20},
 {id:'laser_arc2',name:'Laser ARC-2',type:'laser',currency:'credits',price:70000,bonus:45},
 {id:'laser_arc3',name:'Laser ARC-3',type:'laser',currency:'credits',price:320000,bonus:80},
 {id:'laser_arc4',name:'Laser ARC-4',type:'laser',currency:'stl',price:500,bonus:160},
 {id:'escudo_alfa',name:'Escudo Alfa',type:'shield',currency:'credits',price:15000,bonus:750},
 {id:'escudo_titan',name:'Escudo Titan',type:'shield',currency:'stl',price:300,bonus:2500},
 {id:'motor_pulsar',name:'Motor Pulsar',type:'motor',currency:'credits',price:80000,bonus:7},
 {id:'drone_halo',name:'Drone Halo',type:'drone',currency:'credits',price:100000,bonus:28},
 {id:'drone_nova',name:'Drone Nova',type:'drone',currency:'stl',price:300,bonus:80},
 {id:'aux9',name:'AUX-9',type:'aux',currency:'stl',price:950,bonus:140},
 {id:'ammo_arc',name:'Munição laser avançada',type:'ammo',currency:'credits',price:9000,bonus:500},
 {id:'missil_falcao',name:'Míssil Falcão',type:'missile',currency:'credits',price:11000,bonus:100}
];
export const fmt=n=>Math.floor(n||0).toLocaleString('pt-BR');
