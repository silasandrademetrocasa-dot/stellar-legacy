import { resources,ships,enemies,maps,mapLabel,mapImage,shopItems,fmt } from './catalog.js';
import { retrieve,commit,exportData,importData } from './storage.js';
const $=id=>document.getElementById(id), esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)), rand=(a,b)=>a+Math.random()*(b-a), uid=()=>globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random()}`;
let state, world={npcs:[],ores:[],map:'',target:null}, viewport={w:1,h:1}, dest=null, auto=false, inCombat=false, last=performance.now(), fpsTs=performance.now(), fpsFrames=0, frameFps=0, elapsedSave=0, nextNpcAttack=0, nextPlayerAttack=0, nextAi=0, lastHud=0, currentPanel='', inputLocked=false, dirty=false;
const resourceById=Object.fromEntries(resources.map(r=>[r.id,r]));
const clsShip=id=>ships.find(x=>x.id===id)||ships[0];
const S=(s=state)=>clsShip(s.ship);
function fresh(){let resources={};for(const r of Object.keys(resourceById))resources[r]=0;return {schema:1,seq:0,name:'Piloto Solo',level:1,xp:0,credits:120000,stl:1400,map:'1-1',x:0,y:0,ship:'aurora',ownedShips:['aurora'],hp:16000,shield:12000,resources,capacity:1900,items:{laser_arc1:2,escudo_alfa:2,ammo_arc:1000},conf:1,confs:{1:{laser:2,shield:2,motor:0,drone:0},2:{laser:2,shield:2,motor:0,drone:0}},kills:0,loot:0,sales:0,missions:[{id:'first',kind:'kill',need:8,start:0,done:false,claimed:false},{id:'mine',kind:'collect',need:30,start:0,done:false,claimed:false},{id:'merchant',kind:'sell',need:150,start:0,done:false,claimed:false}],relay:{owner:'Neutro',capturedAt:0},clan:'Aurora',farm:{active:false,startedAt:0,minutes:60},events:{lastClaim:''},lastActive:Date.now(),logs:[],receipts:[]};}
const capacity=(s=state)=>Math.round(s.capacity);const cargoCount=(s=state)=>Object.values(s.resources).reduce((a,b)=>a+(+b||0),0);const power=()=>{const c=state.confs[state.conf];return S().damage+(c.laser||0)*80+(c.drone||0)*25};const maxHp=(s=state)=>S(s).hp;const maxShield=(s=state)=>S(s).shield+(s.confs[s.conf].shield||0)*750;
// Fila UNICA: compra, venda, saque, resgate e equipamento nao competem entre si.
// Nunca anuncia sucesso antes do commit atomico no IndexedDB.
let operationQueue=Promise.resolve();
function transact(action,fn,{backup=false}={}){
 const job=operationQueue.catch(()=>{}).then(async()=>{
  inputLocked=true;
  try{
   const draft=structuredClone(state);
   if(fn(draft)===false)return false;
   draft.seq=(Number(draft.seq)||0)+1;
   draft.lastActive=Date.now();
   draft.logs.unshift({at:draft.lastActive,action});
   draft.logs.length=Math.min(draft.logs.length,50);
   await commit(draft,{checkpoint:backup||draft.seq%15===0});
   // Movimento em curso nao fica preso na transacao que salvou o inventario.
   const moved=dirty && dest && (draft.x!==state.x||draft.y!==state.y);
   const x=state.x,y=state.y;
   state=draft;
   if(moved){state.x=x;state.y=y;dirty=true;}else dirty=false;
   updateHud();return true;
  }catch(err){show('Falha ao salvar: '+err.message);console.error(err);return false;}
  finally{inputLocked=false;}
 });
 operationQueue=job.catch(()=>{});
 return job;
}
function notify(txt){const host=$('gameMessages');const el=document.createElement('p');el.textContent=txt;host.prepend(el);while(host.children.length>3)host.lastChild.remove();setTimeout(()=>el.remove(),4500)}
let noticeTimer;function show(txt){const n=$('notice');n.textContent=txt;n.classList.add('visible');clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>n.classList.remove('visible'),2600);}
function updateHud(){if(!state)return;$('cr').textContent=fmt(state.credits);$('stl').textContent=fmt(state.stl);$('level').textContent=state.level;$('pilotName').textContent=state.name;$('mapName').textContent=`${mapLabel(state.map)} • ${state.map}`;const path=`./assets/ships/${state.ship}.webp`;if(!$('shipImage').getAttribute('src')||!$('shipImage').getAttribute('src').endsWith('/'+state.ship+'.webp'))$('shipImage').src=path;
 const hp=clamp(state.hp/maxHp()*100,0,100),sh=clamp(state.shield/maxShield()*100,0,100);$('hpFill').style.width=hp+'%';$('hpLabel').textContent=`HP ${fmt(state.hp)} / ${fmt(maxHp())}`;$('shieldFill').style.width=sh+'%';$('shieldLabel').textContent=`ESC ${fmt(state.shield)} / ${fmt(maxShield())}`;$('autopilotBtn').textContent=auto?'◉ AUTOPILOT ON':'◉ AUTOPILOT OFF';$('autopilotBtn').classList.toggle('active',auto);$('fightBtn').classList.toggle('active',inCombat)}
function makeWorld(){world.npcs=[];world.ores=[];world.target=null;world.map=state.map;const zone=state.map.startsWith('1')?0:state.map.startsWith('2')?1:state.map.startsWith('3')?2:3;for(let i=0;i<11;i++){const e=enemies[clamp(zone+Math.floor(rand(0,3)),0,enemies.length-1)];world.npcs.push({id:uid(),kind:'npc',x:rand(-950,950),y:rand(-950,950),hp:e.hp,max:e.hp,e,alive:true,lastHit:0,el:null});}
 for(let i=0;i<18;i++){const r=resources[Math.floor(rand(0,Math.min(6,zone+4)))];world.ores.push({id:uid(),kind:'ore',x:rand(-1000,1000),y:rand(-1000,1000),r,qty:Math.floor(rand(3,13)),el:null});}
 $('mapBackdrop').style.backgroundImage=`url('${mapImage(state.map)}')`;createEntities();updateHud();}
function createEntities(){const host=$('world');host.replaceChildren();for(const obj of [...world.npcs,...world.ores]){const el=document.createElement('div');el.className=obj.kind==='npc'?'sprite':'oreSprite';el.dataset.id=obj.id;const im=document.createElement('img');im.src=obj.kind==='npc'?`./assets/npcs/${obj.e.sprite}`:`./assets/ores/${obj.r.icon}`;el.append(im);if(obj.kind==='npc'){const bar=document.createElement('div');bar.className='smallbar';bar.innerHTML='<i style="width:100%"></i>';el.append(bar);const name=document.createElement('div');name.className='spriteName';name.textContent=obj.e.name;el.append(name)}el.addEventListener('pointerdown',ev=>{ev.stopPropagation();if(obj.kind==='npc'){world.target=obj;inCombat=true;show('Alvo: '+obj.e.name);$('selectedTarget').hidden=false;updateTargetLabel()}else{dest={x:obj.x,y:obj.y,ore:obj.id};show('Coletando '+obj.r.name)}}, {passive:true});obj.el=el;host.append(el);}}
function updateTargetLabel(){const t=world.target;$('selectedTarget').hidden=!t;if(t)$('selectedTarget').textContent=`⚔ ${t.e.name} · HP ${fmt(Math.max(0,t.hp))}`;}
function worldToScreen(x,y){return {x:viewport.w/2+x-state.x,y:viewport.h/2+y-state.y};}
function renderEntities(){const w=viewport.w,h=viewport.h;for(const o of [...world.npcs,...world.ores]){if(!o.el)continue;const p=worldToScreen(o.x,o.y),visible=p.x>-75&&p.x<w+75&&p.y>-75&&p.y<h+75&&o.alive!==false;o.el.style.display=visible?'':'none';if(visible){o.el.style.left=p.x+'px';o.el.style.top=p.y+'px';if(o.kind==='npc')o.el.querySelector('i').style.width=clamp(o.hp/o.max*100,0,100)+'%';}}$('mapBackdrop').style.transform=`translate3d(${(-state.x*.04).toFixed(1)}px,${(-state.y*.04).toFixed(1)}px,0)`;}
function dronesFrame(now){const host=$('drones');const count=Math.min(state.confs[state.conf].drone||0,8);if(host.children.length!==count){host.replaceChildren();for(let i=0;i<count;i++){const el=document.createElement('img');el.src='./assets/drones/drone_common.webp';host.append(el)}}for(let i=0;i<count;i++){const a=now*.0012+i*2*Math.PI/count;host.children[i].style.transform=`translate3d(${Math.cos(a)*62}px,${Math.sin(a)*55}px,0)`;}}
function travel(dt){if(!dest)return;const dx=dest.x-state.x,dy=dest.y-state.y,d=Math.hypot(dx,dy);if(d<12){state.x=dest.x;state.y=dest.y;if(dest.ore){const o=world.ores.find(x=>x.id===dest.ore);if(o)collect(o)}dest=null;return;}const velocity=(S().speed+(state.confs[state.conf].motor||0)*7)*dt;state.x+=dx/d*Math.min(d,velocity);state.y+=dy/d*Math.min(d,velocity);
 // Front-biased orientation. Smooth limited banking rather than flipping to show the stern.
 const bank=clamp(dx/(Math.abs(dx)+Math.abs(dy)+.01)*38,-38,38);const current=Number($('pilotSprite').dataset.bank||0);const next=current+(bank-current)*clamp(dt*4,0,1);$('pilotSprite').dataset.bank=String(next);$('pilotSprite').style.transform=`translate3d(-50%,-50%,0) rotate(${next.toFixed(1)}deg)`;dirty=true;}
function collect(o){
 if(o.collecting)return;
 o.collecting=true;
 let amount=0;
 transact('coleta:'+o.r.name,s=>{
  const available=capacity(s)-cargoCount(s);
  amount=Math.min(o.qty,available);
  if(amount<1)return false;
  s.resources[o.r.id]=(s.resources[o.r.id]||0)+amount;
  s.loot+=amount;
 }).then(ok=>{
  if(ok){notify(`+${amount} ${o.r.name}`);o.qty-=amount;
   if(o.qty<=0){o.x=rand(-950,950);o.y=rand(-950,950);o.qty=Math.round(rand(4,15));}}
  else notify('Coleta nao salva; o recurso continua no mapa.');
 }).finally(()=>{o.collecting=false});
}
function experience(x,s){
 s.xp+=x;
 while(s.xp>=s.level*2000){s.xp-=s.level*2000;s.level++;
  s.hp=maxHp(s);s.shield=maxShield(s);}
}
function flash(p){const el=document.createElement('div');el.className='blast';el.style.left=(p.x-24)+'px';el.style.top=(p.y-24)+'px';$('effects').append(el);setTimeout(()=>el.remove(),240)}
function destroy(t){
 t.alive=false;flash(worldToScreen(t.x,t.y));
 const e=t.e;const zone=state.map.startsWith('3')?3:state.map.startsWith('2')?2:1;
 transact('recompensa:'+e.name,s=>{
  s.credits+=e.credit;s.stl+=e.stl;s.kills++;experience(240+zone*120,s);
  const res=resources[Math.floor(rand(0,Math.min(resources.length-1,zone+3)))];
  const n=Math.min(Math.round(rand(3,10)),capacity(s)-cargoCount(s));
  if(n>0){s.resources[res.id]+=n;s.loot+=n;}
 },{backup:true}).then(ok=>{
  if(ok){notify(`${e.name} eliminado • +${fmt(e.credit)} CR • +${e.stl} STL`);
   setTimeout(()=>{t.x=rand(-1000,1000);t.y=rand(-1000,1000);t.hp=t.max;t.alive=true},7000);}
  else {t.hp=t.max;t.alive=true;notify('Recompensa nao salva: inimigo restaurado.');}
 });
 if(world.target===t){world.target=null;inCombat=false;updateTargetLabel();}
}
function playerAttack(now){const t=world.target;if(!t||!t.alive){inCombat=false;return;}const dist=Math.hypot(t.x-state.x,t.y-state.y);if(dist>650){if(auto)dest={x:t.x,y:t.y};return;}if(now<nextPlayerAttack)return;nextPlayerAttack=now+480;const p=worldToScreen(t.x,t.y);const el=document.createElement('div');el.className='shot';el.style.left=viewport.w/2+'px';el.style.top=viewport.h/2+'px';const angle=Math.atan2(p.y-viewport.h/2,p.x-viewport.w/2)*180/Math.PI+90;el.style.transform=`rotate(${angle}deg) scaleY(${clamp(dist/50,2,18)})`;$('projectiles').append(el);setTimeout(()=>el.remove(),115);
 t.hp-=power();if(t.hp<=0)destroy(t);updateTargetLabel();}
function npcAttack(now){if(now<nextNpcAttack)return;nextNpcAttack=now+1200;const near=world.npcs.filter(x=>x.alive&&Math.hypot(x.x-state.x,x.y-state.y)<200);if(!near.length)return;const dmg=Math.round(near.reduce((a,n)=>a+n.e.dmg,0)*.32);if(state.shield>0){const take=Math.min(dmg,state.shield);state.shield-=take;state.hp-=dmg-take;}else state.hp-=dmg;
 dirty=true;if(state.hp<=0){state.hp=maxHp();state.shield=maxShield();state.x=0;state.y=0;dest=null;auto=false;inCombat=false;notify('Nave recuperada na base. Nenhum item perdido.');transact('recuperação da nave',s=>{});} }
function nearest(list){let best=null,d=Infinity;for(const x of list){if(x.alive===false)continue;let q=Math.hypot(x.x-state.x,x.y-state.y);if(q<d){d=q;best=x;}}return best;}
function autoStep(){if(!auto||currentPanel)return;if(cargoCount()>=capacity()*.9){dest={x:0,y:0};if(Math.hypot(state.x,state.y)<35){auto=false;show('Porão cheio — nave voltou à base');updateHud();}return;}const ore=nearest(world.ores);const npc=nearest(world.npcs);if(ore&&Math.hypot(ore.x-state.x,ore.y-state.y)<270){dest={x:ore.x,y:ore.y,ore:ore.id};return;}if(npc){world.target=npc;inCombat=true;dest={x:npc.x+125,y:npc.y};}}
function tick(now){const dt=Math.min(.035,(now-last)/1000);last=now;if(state&&!currentPanel&&!inputLocked){viewport.w=$('gameView').clientWidth;viewport.h=$('gameView').clientHeight;travel(dt);if(inCombat)playerAttack(now);npcAttack(now);renderEntities();dronesFrame(now);if(now>nextAi){nextAi=now+550;autoStep()}if(now-lastHud>170){lastHud=now;updateHud()}elapsedSave+=dt;if(elapsedSave>=6){elapsedSave=0;if(dirty&&!inputLocked)transact('posicao:periodico',()=>{}).catch(e=>show('Erro no save local: '+e.message));}}
 fpsFrames++;if(now-fpsTs>=1000){frameFps=Math.round(fpsFrames*1000/(now-fpsTs));fpsFrames=0;fpsTs=now;$('fpsLabel').textContent='FPS '+frameFps+(auto?' • AUTO':'');}requestAnimationFrame(tick);}
function sell(id){const r=resourceById[id];if(!r||r.price<=0){show('Recurso reservado para craft/refinaria');return;}const n=state.resources[id]||0;if(!n){show('Sem recurso para vender');return;}transact('venda:'+r.name,s=>{const q=s.resources[id]||0;if(q<1)return false;s.resources[id]=0;s.credits+=q*r.price;s.sales+=q;},{backup:true}).then(ok=>{if(ok){show(`Venda confirmada localmente: +${fmt(n*r.price)} CR`);panel('market')}});}
function sellAll(){const q=resources.filter(r=>r.price>0).map(r=>({id:r.id,amount:state.resources[r.id]||0,price:r.price}));const total=q.reduce((x,r)=>x+r.amount*r.price,0);if(!total){show('Nada vendável no porão');return;}transact('venda:porão',s=>{let gain=0;for(const r of q){const n=s.resources[r.id]||0;s.resources[r.id]=0;gain+=n*r.price;s.sales+=n;}s.credits+=gain;},{backup:true}).then(ok=>{if(ok){show(`Porão vendido: +${fmt(total)} CR`);panel('market')}});}
function buy(item){const count=state.items[item.id]||0;transact('compra:'+item.name,s=>{if(s[item.currency]<item.price)return false;s[item.currency]-=item.price;s.items[item.id]=(s.items[item.id]||0)+(item.type==='ammo'?item.bonus:1);},{backup:true}).then(ok=>{show(ok?item.name+' adquirido e salvo offline':'Saldo insuficiente');panel('market')});}
function purchaseShip(id){const x=clsShip(id);if(state.ownedShips.includes(id)){transact('troca de nave',s=>{s.ship=id;s.hp=maxHp(s);s.shield=maxShield(s);},{backup:true}).then(ok=>{if(ok){show('Nave selecionada');panel('hangar')}});return;}transact('nova nave:'+x.name,s=>{if(s.credits<x.price)return false;s.credits-=x.price;s.ownedShips.push(id);s.ship=id;s.hp=x.hp;s.shield=x.shield;},{backup:true}).then(ok=>{show(ok?'Nova nave adquirida':'Créditos insuficientes');panel('hangar')});}
const btn=(text,code,extra='')=>`<button type="button" ${extra} data-command="${esc(code)}">${esc(text)}</button>`;
function panel(id){currentPanel=id;$('panelLayer').hidden=false;$('panelTitle').textContent=({hangar:'Hangar e Equipamentos',market:'Mercado e Porão',missions:'Missões e Passe',map:'Mapa Galáctico',relay:'Relés e Eventos Solo',settings:'Configurações e Save'}[id]||id);const out=$('panelContent');
if(id==='market'){out.innerHTML=`<div class="tile"><div class="rowBetween"><b>PORÃO</b><span>${fmt(cargoCount())} / ${fmt(capacity())} unidades</span></div><p>Vendas instantâneas e atômicas no IndexedDB. Sem SQL, sem servidor.</p><div class="buttons">${btn('VENDER TUDO','sellAll','class="gold"')}</div></div><div class="panelGrid">${resources.map(r=>`<div class="tile"><div class="resource"><img src="./assets/ores/${r.icon}" alt=""><div><b>${r.name}</b><div class="muted">${fmt(state.resources[r.id])} un. • ${fmt(r.price)} CR/un.</div></div></div><div class="buttons">${btn(r.price?'Vender':'Material de craft','sell:'+r.id,r.price?'':'disabled')}</div></div>`).join('')}</div><h3>LOJA</h3><div class="panelGrid">${shopItems.map(x=>`<div class="tile"><b>${x.name}</b><p>Possui: ${fmt(state.items[x.id]||0)} · ${fmt(x.price)} ${x.currency==='stl'?'STL':'CR'}</p>${btn('Comprar','buy:'+x.id)}</div>`).join('')}</div>`;}
if(id==='hangar'){const c=state.confs[state.conf];out.innerHTML=`<div class="tile"><b>Configuração global</b><p>Configuração ${state.conf} aplicada à nave, drones e AUX-9.</p><div class="buttons">${btn('CONF1','conf:1',state.conf===1?'class="accent"':'')}${btn('CONF2','conf:2',state.conf===2?'class="accent"':'')}</div><p>Lasers ${c.laser} • Escudos ${c.shield} • Drones ${c.drone} • Motores ${c.motor}</p><div class="buttons">${['laser_arc1','escudo_alfa','drone_halo','motor_pulsar'].map(x=>{const item=shopItems.find(i=>i.id===x);return btn(`Equipar ${item.name}`,'equip:'+item.id)}).join('')}</div></div><h3>Frota • ${state.ownedShips.length}/${ships.length}</h3><div class="panelGrid">${ships.map(x=>`<div class="tile"><div class="shipCard"><img loading="lazy" src="./assets/ships/${x.id}.webp" alt=""><div><b>${x.name}</b><div class="muted">HP ${fmt(x.hp)} • ESC ${fmt(x.shield)}</div></div></div><div class="buttons">${btn(state.ship===x.id?'ATIVA':state.ownedShips.includes(x.id)?'Selecionar':`Comprar ${fmt(x.price)} CR`,'ship:'+x.id,state.ship===x.id?'disabled':'')}</div></div>`).join('')}</div>`;}
if(id==='missions'){out.innerHTML=`<div class="tile"><b>Passe Solo</b><p>Nível ${state.level} • Abates ${fmt(state.kills)} • Recursos coletados ${fmt(state.loot)} • Recursos vendidos ${fmt(state.sales)}</p></div><div class="panelGrid">${state.missions.map(m=>{const cur=(m.kind==='kill'?state.kills:m.kind==='collect'?state.loot:state.sales)-m.start;const names={kill:'Caçada de NPCs',collect:'Exploração e coleta',sell:'Comércio da base'};return `<div class="tile"><b>${names[m.kind]}</b><p>${Math.min(m.need,cur)} / ${m.need} • Recompensa ${fmt(m.need*800)} CR</p>${btn(m.claimed?'Recompensa recebida':cur>=m.need?'RESGATAR':'Em andamento','mission:'+m.id,m.claimed||cur<m.need?'disabled':'')}</div>`}).join('')}</div>`;}
if(id==='map'){out.innerHTML=`<div class="tile"><b>Mapa atual: ${state.map}</b><p>Transitar entre setores não requer servidor. A nave e o progresso permanecem salvos.</p></div><div class="panelGrid">${maps.map(x=>`<div class="tile"><div class="rowBetween"><b>${x}</b><span class="muted">${mapLabel(x)}</span></div>${btn(x===state.map?'ATUAL':'Viajar','map:'+x,x===state.map?'disabled':'')}</div>`).join('')}</div>`;}
if(id==='relay'){const relay=relayInfo();const now=Date.now();const eventPhase=Math.floor(now/3600000)%3;const eventNames=['Caçada Galáctica','Invasão Scavenger','Tempestade de Recursos'];out.innerHTML=`<div class="tile"><div class="caps">Domínio do relé • mundo individual</div><h3>Relé Terra — ${esc(state.relay.owner)}</h3><p>Fase: <b>${relay.protected?'ESCUDO ATIVO':'DISPUTA LIVRE'}</b> • ${relay.remaining}</p><p class="muted">Ao conquistar, o escudo dura 12 horas. Em seguida, o relé fica 12 horas disputável. Rivais são clãs simulados locais; não há multiplayer real.</p><div class="buttons">${btn('DISPUTAR RELÉ','capture',relay.protected?'disabled':'')}</div></div><div class="tile"><b>Seu clã: ${esc(state.clan)}</b><p>Clã individual; conquistas salvas somente neste aparelho.</p><div class="inline"><input id="clanField" aria-label="Nome do clã" maxlength="22" value="${esc(state.clan)}">${btn('Alterar','setClan')}</div></div><div class="tile"><div class="caps">Evento exclusivo do piloto</div><h3>${eventNames[eventPhase]}</h3><p>Seu mundo tem eventos independentes, sem sincronização entre jogadores.</p>${btn('Participar e receber bônus','event:'+eventPhase, state.events.lastClaim===eventPhase+':'+Math.floor(now/3600000)?'disabled':'')}</div>`;}
if(id==='settings'){out.innerHTML=`<div class="tile"><b>Save local único</b><p>IndexedDB • snapshots A/B/C • transação única para compra, venda, progressão e recompensas. Sem login, SQL ou Render.</p><p>Revisão local ${fmt(state.seq)} • Salvo em ${new Date(state.lastActive).toLocaleString('pt-BR')}</p><div class="buttons">${btn('Salvar agora','save')}${btn('Exportar backup','export')}${btn('Importar backup','import')}${btn('Reparar HP/Escudo','repair')}</div><input style="display:none" id="uploadSave" type="file" accept="application/json,.json"><p class="muted">O navegador pode apagar dados ao limpar o armazenamento. Exporte um backup para guardar seu progresso.</p></div><div class="tile"><b>Desempenho</b><p>Última leitura: ${frameFps} FPS. Sprite DOM/CSS, sem desenho de efeitos em Canvas.</p><p class="muted">O navegador pode limitar animações em segundo plano. O Farm Offline calcula o tempo pelo relógio ao reabrir.</p></div>`;}
}
function closePanel(){currentPanel='';$('panelLayer').hidden=true;}
function relayInfo(){const passed=Math.max(0,Date.now()-(state.relay.capturedAt||0));if(!state.relay.capturedAt)return {protected:false,remaining:'Disponível para conquista'};const cycle=passed%(24*3600000),protectedPhase=cycle<12*3600000,remain=(protectedPhase?12*3600000:24*3600000)-cycle;return {protected:protectedPhase,remaining:Math.floor(remain/3600000)+'h '+Math.floor(remain%3600000/60000)+'min'}}
async function commands(c){const [action,...rest]=c.split(':'),id=rest.join(':');if(action==='sell')sell(id);if(action==='sellAll')sellAll();if(action==='buy'){const x=shopItems.find(z=>z.id===id);if(x)buy(x);}if(action==='ship')purchaseShip(id);if(action==='conf'){await transact('configuração '+id,s=>{s.conf=Number(id);s.shield=clamp(s.shield,0,maxShield(s));},{backup:true});show('CONF'+id+' aplicada e salva offline');panel('hangar')}
 if(action==='equip'){const x=shopItems.find(z=>z.id===id);if(!x)return;const attr=x.type==='laser'?'laser':x.type==='shield'?'shield':x.type==='drone'?'drone':'motor';const itemCount=state.items[id]||0;const cfg=state.confs[state.conf];if(cfg[attr]>=itemCount){show('Compre o item antes de equipar');return;}await transact('equipamento:'+x.name,s=>{s.confs[s.conf][attr]++;s.shield=clamp(s.shield,0,maxShield(s));},{backup:true});panel('hangar')}
 if(action==='map'){await transact('mapa:'+id,s=>{s.map=id;s.x=0;s.y=0;s.hp=maxHp(s);s.shield=maxShield(s);},{backup:true});auto=false;inCombat=false;dest=null;makeWorld();closePanel();show('Bem-vindo ao setor '+id);}
 if(action==='mission'){const m=state.missions.find(m=>m.id===id);if(m){const score=m.kind==='kill'?state.kills:m.kind==='collect'?state.loot:state.sales;if(!m.claimed&&score-m.start>=m.need){await transact('missão:'+id,s=>{const m=s.missions.find(x=>x.id===id);m.claimed=true;s.credits+=m.need*800;s.stl+=Math.ceil(m.need/3);},{backup:true});show('Recompensa resgatada!');panel('missions')}}}
 if(action==='capture'){if(relayInfo().protected){show('Relé ainda protegido');return;}await transact('captura relé',s=>{s.relay.owner=s.clan;s.relay.capturedAt=Date.now();s.credits+=50000;s.stl+=20;},{backup:true});show('Relé conquistado — escudo 12 horas');panel('relay')}
 if(action==='setClan'){const name=($('clanField')?.value||'').trim().slice(0,22);if(name){await transact('nome do clã',s=>{s.clan=name},{backup:true});panel('relay')}}
 if(action==='event'){const phase=Number(id),key=phase+':'+Math.floor(Date.now()/3600000);if(state.events.lastClaim===key)return;await transact('evento solo',s=>{s.events.lastClaim=key;s.credits+=25000;s.stl+=15;},{backup:true});panel('relay');show('Evento solo recompensado')}
 if(action==='save'){await transact('save manual',()=>{}, {backup:true});show('Estado e checkpoint salvos')}
 if(action==='repair'){await transact('reparar nave',s=>{if(s.credits<500)return false;s.credits-=500;s.hp=maxHp(s);s.shield=maxShield(s);},{backup:true});panel('settings')}
 if(action==='export'){await operationQueue;const raw=await exportData();if(window.StellarNativeBackup?.exportSave){window.StellarNativeBackup.exportSave(raw);show('Escolha onde salvar seu backup no Android');return;}const url=URL.createObjectURL(new Blob([raw],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=`stellar-offline-save-${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);show('Backup exportado')}
 if(action==='import'){if(window.StellarNativeBackup?.importSave)window.StellarNativeBackup.importSave();else $('uploadSave')?.click()}
}
async function toggleFarm(){if(state.farm.active){const seconds=Math.max(0,(Date.now()-state.farm.startedAt)/1000),mins=Math.min(480,seconds/60),n=Math.floor(mins*2),reward=Math.floor(mins*1600);await transact('resgate farm offline',s=>{if(!s.farm.active)return false;s.farm.active=false;s.farm.startedAt=0;s.credits+=reward;s.stl+=Math.floor(mins/3);s.kills+=Math.floor(mins/2);s.resources.Prometium+=Math.min(n,Math.max(0,capacity(s)-cargoCount(s)));},{backup:true});show(`Farm resgatado: +${fmt(reward)} CR, ${Math.floor(mins)} min`);}else{await transact('início farm',s=>{s.farm.active=true;s.farm.startedAt=Date.now();},{backup:true});show('Farm iniciado: feche o jogo e retorne depois');}updateFarmButton();}
function updateFarmButton(){$('farmBtn').textContent=state.farm.active?'◷ RESGATAR FARM':'◷ FARM OFFLINE';$('farmBtn').classList.toggle('active',state.farm.active)}
function bind(){document.querySelectorAll('[data-panel]').forEach(b=>b.onclick=()=>panel(b.dataset.panel));$('panelContent').onclick=e=>{const el=e.target.closest('[data-command]');if(el)commands(el.dataset.command).catch(err=>show('Erro: '+err.message))};$('closePanel').onclick=closePanel;$('panelLayer').onclick=e=>{if(e.target===$('panelLayer'))closePanel()};$('gameView').addEventListener('pointerdown',e=>{if(e.target.closest('#bottomHud,#selectedTarget,#gameMessages'))return;const rect=$('gameView').getBoundingClientRect();dest={x:state.x+e.clientX-rect.left-rect.width/2,y:state.y+e.clientY-rect.top-rect.height/2};auto=false;updateHud();},{passive:true});$('autopilotBtn').onclick=()=>{auto=!auto;if(!auto)dest=null;updateHud();show(auto?'Autopilot local ativo':'Autopilot desligado')};$('fightBtn').onclick=()=>{if(!world.target||!world.target.alive)world.target=nearest(world.npcs);inCombat=!inCombat;updateTargetLabel();updateHud()};$('baseBtn').onclick=()=>{auto=false;dest={x:0,y:0};show('Voltando à base')};$('farmBtn').onclick=toggleFarm;$('panelContent').addEventListener('change',async e=>{if(e.target?.id==='uploadSave'){const f=e.target.files[0];if(!f)return;try{const n=await importData(await f.text());state=n;world={npcs:[],ores:[],map:'',target:null};auto=false;inCombat=false;makeWorld();panel('settings');show('Save importado com sucesso')}catch(err){show('Importação falhou: '+err.message)}}});document.addEventListener('visibilitychange',()=>{if(document.hidden&&state&&dirty){transact('pausa:snapshot',()=>{}).catch(()=>{});}last=performance.now()});window.addEventListener('pagehide',()=>{if(state&&dirty)transact('sair:snapshot',()=>{}).catch(()=>{});});}
// SAF nativo chama esta funcao ao selecionar um backup JSON.
window.StellarNativeImport=async raw=>{
 try{await operationQueue;const n=await importData(raw);state=n;auto=false;inCombat=false;dest=null;
 makeWorld();updateHud();updateFarmButton();panel('settings');show('Backup importado com sucesso!');}
 catch(e){show('Backup invalido: '+e.message)}
};
window.StellarOfflineFlush=()=>transact('app:pausa',()=>{});
async function boot(){try{const loaded=await retrieve();state=loaded.state||fresh();if(!loaded.state)await commit(state,{checkpoint:true});if(loaded.source!=='primary'&&loaded.source!=='new'){await commit(state,{checkpoint:true});show('Save recuperado do checkpoint '+loaded.source)}
 state.hp=clamp(state.hp||1,0,maxHp());state.shield=clamp(state.shield||0,0,maxShield());$('splash').remove();$('shell').hidden=false;bind();makeWorld();updateFarmButton();updateHud();requestAnimationFrame(tick);if(!window.StellarNativeBackup && 'serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});
 if(state.farm.active)notify('Farm Offline disponível para resgate');else notify('Bem-vindo ao Universo Solo: 100% offline');
}catch(e){$('bootStatus').textContent='Não foi possível abrir seu save local: '+e.message;console.error(e)}}boot();
