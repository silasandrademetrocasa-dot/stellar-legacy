# Stellar Legacy — Correção Target + arte AUX-9 (22/10/2026)

Pacote PATCH para o Instalador Universal existente no repositório.

**Aplicação**: envie este único ZIP para a RAIZ do GitHub (`main`) como de costume e execute o workflow **🚀 Stellar Legacy — Instalador Universal**. O instalador usa `stellar-install.json`, copia as alterações e faz testes antes do deploy.

**Mudanças**:
- Target NPC recolhido: botão de seta de 40 × 40, sem nome ou detalhes.
- Target expandido: painel legível com área suficiente para dados e retrato, inclusive no modo paisagem.
- Nova arte AUX-9 branca/ciano extraída da referência, usada no Hangar. Designer, nível, armas, módulos, protocolos, comportamento no mapa e economia não mudam.
- Mantida integralmente a função de política de revenda no módulo alterado.
- Sem SQL.

A atualização altera apenas `public/modules/sale-policy-v4776.js` e adiciona `public/assets/v4777/aux9-new.webp`. Após deploy, atualize a página sem cache se ainda visualizar as imagens antigas.
