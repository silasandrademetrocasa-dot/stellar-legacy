// TEST-ONLY SYNTHETIC CATALOG (excluded from published ZIP; real repo owns public/data.js)
export const ITEMS={lf1:{type:'laser',damage:65},lf3:{type:'laser',damage:175,alienBonus:.15},lf4:{type:'laser',damage:200},mp1:{type:'laser',damage:70,alienDamage:60}};
export const LASER_AMMO={lcb10:{mult:1},mcb25:{mult:2},mcb50:{mult:3},ucb100:{mult:4}};
export const SHIPS={phoenix:{speed:320,cargo:100},leonov:{speed:360,cargo:500,bonusLowMaps:{laserMult:1.5,cargo:500,speed:20}}};
