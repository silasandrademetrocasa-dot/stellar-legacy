# Stellar Legacy V48.2.6 — PACOTE ÚNICO CORRIGIDO

Patch acumulado **sobre V48.2.2 ou V48.2.3**, mantendo a release base `47.7.6`.

## Inclui (um deploy só)
- V48.2.4: HUD PILOTO/NAVE compacto, PORÃO+VEL lado a lado, somente seta quando recolhido; remove apenas toast técnico de sincronização.
- V48.2.5: mapa de rotas padronizado para Terra/Marte/Júpiter; ADM vê mapa global com filtros. **Não altera conexões, requisitos, portais ou saves**.
- Autopilot: preserva rota X-2 → X-1 (vender/abastecer) → X-2 durante reconexão de até 60 s; não executa ações com autorização vencida; compra pela loja oficial na base e por CPU autorizado fora dela, respeitando saldo/orçamento.
- V48.2.6: elimina a falha **SyntaxError: Identifier AUTOPILOT_V48**. Corrige idempotência da instalação: modificações futuras no controlador não provocam declaração duplicada. Adiciona testes de regressão.

## Instalação
1. Remova o ZIP anterior V48.2.5 (ou outros ZIPs) da raiz do GitHub.
2. Envie só **STELLAR_LEGACY_V48_2_6_ROTAS_HUD_AUTOPILOT_FIX.zip** à raiz.
3. Execute `🚀 Stellar Legacy — Instalador Universal`.
4. Confirme validação **npm run check + npm test** e aguarde a publicação do Render.

**Sem SQL. Sem migração de contas.**

**Atenção**: este pacote não modifica a lógica de reconciliação de XP; a divergência de telemetria ainda requer uma investigação separada antes de mudanças em dados dos jogadores.
