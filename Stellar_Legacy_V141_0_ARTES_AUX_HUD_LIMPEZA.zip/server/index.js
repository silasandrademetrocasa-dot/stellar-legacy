import {createPlayerRewardsV134} from './player-rewards-v134.js';
import {mergePlayerStateV134} from '../public/modules/player-state-merge-v134.js';
import {commitEconomyUnifiedV1332,settleAuctionUnifiedV1332} from './unified-command-v1332.js';
import {claimMissionCommandV1331} from './mission-command-v1331.js';
import {createChristmasService,mountChristmasRoutes} from './christmas-v132.js';
import {operationDigestV125,requestIdValidV125,decodeEconomyReceiptV125,replayValidV125} from './economy-receipts-v125.js';
import {quoteCargoSaleV130} from './cargo-sale-v130.js';
import {validPurchaseIdV123,interpretPurchaseCommitV123} from './live-purchase-v123.js';
/* STELLAR_OFFLINE_FARM_V484 APPLIED */
import {savePromotionReadinessV1195} from './save-promotion-gate-v1195.js';
import {createAuctionSingleFlightV1194,auctionSettlementKeyV1194} from './save-auction-coalesce-v1194.js';
import {syncFleetConfigsAfterDroneSaleV118,pruneOrphanedDroneLayoutsV118} from './unified-fleet-snapshot-v118.js';
import {saveCoreModeV119,commitSaveCoreV119,saveModuleForRequestV119,SAVE_LOG_MODULES_V119} from './save-core-v119.js';
import {createSaveOperationMonitorV1192} from './save-operation-monitor-v1192.js';
import {inspectSaveHealthV1192} from './save-health-v1192.js';
import {createSaveLatencyMonitorV1191} from './save-latency-v1191.js';
import {saleQuoteV4776} from '../public/modules/sale-policy-v4776.js';
import {tradeRequestIdV1164,findTradeReceiptV1164,rememberTradeReceiptV1164} from './autotrade-idempotency-v1164.js';
import {validateEquipmentWriteV1062} from '../public/modules/hangar-write-guard-v1062.js';
import {applyAuxAdvancedActionV110,validateAuxAdvancedSaveV110} from '../public/modules/aux-advanced-protocols-v1131.js';
import {attachFrontierAuditV450} from './frontier-audit-v450.js';
import {attachFrontierAdminV440} from './frontier-admin-v440.js';
import {attachAstralIntegrationsV435} from './astral-integrations-v435.js';
import {attachAstralCombatV431} from './astral-combat-v431.js';
import {attachStageBV426} from './stage-b-v426.js';
import {attachStageAV423} from './stage-a-v423.js';
import {attachSquadObjectivesV421} from './squad-objectives-v421.js';
import {attachFrontierUnifiedV42} from './frontier-unified-v42.js';
import {attachAstralRewardsV381} from './astral-rewards-v381.js';
import {cleanWarbotConfig,WARBOT_MAPS} from './warbot-engine-v477.js';
import express from 'express';
import compression from 'compression';
import http from 'http';
import path from 'path';
import fs from 'fs/promises';
import os from 'os';
import { fileURLToPath } from 'url';
import { createClient } from '@supabase/supabase-js';
import {createReadCoalescerV104} from '../public/modules/read-coalescer-v104.js';
import { randomUUID } from 'crypto';
import {installOfflineFarmV484,offlineFarmEnsureInactiveV484,makeOfflineFarmGuardV484,makeOfflineFarmApiSafetyV103} from './offline-farm-v484.js';
import {installBalanceAuditV90} from './balance-audit-v90.js';
import {installCombatProgressionAuditV113} from './progression-balance-v113.js';
import {installCompetitiveReadinessV98} from './competitive-readiness-v98.js';
import {competitiveQualitySummaryV115} from './competitive-release-monitor-v115.js';
import {installLiveopsSnapshotV99} from './liveops-snapshot-v99.js';
import {installReleaseReadinessV100} from './release-readiness-v100.js';
import { attachSharedUniverse } from './world.js';
import { eliteStatus } from './elite-operations.js';
import { warCampaignState,warRankings,safeWarCampaignInput,safeWarRulesInput } from './war-campaigns.js';
import { createCommandCenterRouter } from './command-center-router.js';
import { createRelayRouter } from './relay-router-v346.js';
import {createDominionRouter} from './dominion-router-v360.js';
import {createFrontierRouter} from './frontier-router-v370.js';
import { validatePlayerSave, invalidShopArguments } from './security-guard.js';
import { missionSaveGuardV108 } from './mission-save-guard-v108.js';
import {grantNpcRewardSafelyV1069} from './npc-reward-delivery-v1069.js';
import { validateRewardClaimContinuity } from './reward-claim-guard.js';
import { createSecurityService } from './security-service.js';

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const RELEASE_VERSION = '47.7.73'; // único identificador de release nos endpoints HTTP

function normalizeSupabaseUrl(value = '') {
  let url = String(value || '').trim();
  if (!url) return '';
  url = url.replace(/\/+$/, '');
  url = url.replace(/\/rest\/v1$/i, '');
  return url;
}

import {quoteBulkPurchase} from '../public/modules/bulk-purchase-v92.js';
import {applyPilotSkillUpgradeV102,applyPilotSkillResetV102,withEconomySaveRetryV102} from './pilot-economy-v102.js';

const SUPABASE_URL = normalizeSupabaseUrl(process.env.SUPABASE_URL || '');
const SUPABASE_KEY = String(process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || '').trim();
// Chave privilegiada SOMENTE no Render. Nunca retorna no /api/config nem no bundle público.
const SUPABASE_SERVICE_KEY=String(process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY || '').trim();
const eliteAdminClient=SUPABASE_URL&&SUPABASE_SERVICE_KEY?createClient(SUPABASE_URL,SUPABASE_SERVICE_KEY,{auth:{persistSession:false,autoRefreshToken:false}}):null;
const securityService=createSecurityService(eliteAdminClient);
async function requireEliteAdmin(){if(!eliteAdminClient)throw new Error('Configure SUPABASE_SERVICE_ROLE_KEY no Render para persistir conquistas.');return eliteAdminClient;}
// O navegador e o token JWT nunca recebem permissao de escrita direta nos saves.
// Todas as gravacoes passam pelo Render depois da validacao de usuario, sessao e regras.
async function writeVerifiedSave(req,state,updated_at){
 const service=await requireEliteAdmin();pruneOrphanedDroneLayoutsV118(state);
 const original=req.saveOperationV133;
 const id=original?.id||randomUUID();
 const hash=original?.hash||operationDigestV125('checkpoint',{state});
 const {data,error}=await SAVE_OPERATIONS_V1192.measure(saveModuleForRequestV119(req),()=>service.rpc('stellar_player_commit',{
  p_user_id:req.user.id,p_command_id:id,p_module:'checkpoint',p_request_hash:hash,
  p_payload:{base:req.playerBaseV134||null,state,receipt:{checkpoint:true}}
 }));
 if(error)return error;
 if(!data?.ok)return {code:data?.code||'SAVE_NOT_CONFIRMED',message:data?.code||'SAVE_NOT_CONFIRMED'};
 req.confirmedTokenV131=data.save_token;req.confirmedStateV134=data.state;req.confirmedAtV134=data.updated_at;
 return null;
}



const PUBLIC_DIR = path.join(__dirname, '../public');
const ASSET_CACHE_MS = 24 * 60 * 60 * 1000;

// V18.1.8 • HTTP BANDWIDTH OPTIMIZATION
// JS/CSS/JSON textuais são comprimidos; imagens já compactadas (PNG/WebP) passam sem custo extra.
app.use(compression({ threshold: 1024 }));
// V21: cabeçalhos seguros que não quebram os handlers legados nem Google OAuth.
app.disable('x-powered-by');
app.use((req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');next();});
app.use(express.json({ limit: '1mb' }));

// V119.1: P95/P99 da leitura e gravação do save, sem registrar dados de jogador.
const SAVE_LATENCY_V1191=createSaveLatencyMonitorV1191();
const SAVE_OPERATIONS_V1192=createSaveOperationMonitorV1192();
app.use((req,res,next)=>{
  if(req.path!=='/api/player/save'||!['GET','PUT'].includes(req.method))return next();
  const start=performance.now();
  res.once('finish',()=>SAVE_LATENCY_V1191.record(req.method,performance.now()-start));
  next();
});

// Assets recebem cache longo. As URLs dos assets já carregam ?asset=<versão>, portanto um novo
// release invalida o cache sem obrigar o jogador a baixar os mesmos arquivos a cada F5.
app.use('/assets', express.static(path.join(PUBLIC_DIR, 'assets'), {
  maxAge: ASSET_CACHE_MS,
  etag: true,
  lastModified: true,
  setHeaders(res){res.setHeader('Cache-Control','public, max-age=86400, stale-while-revalidate=604800');}
}));
app.use(express.static(PUBLIC_DIR, {
  etag: true,
  lastModified: true,
  setHeaders(res, filePath) {
    if (/\.html?$/i.test(filePath)) res.setHeader('Cache-Control', 'no-cache');
    else if (/\.(?:js|css)$/i.test(filePath)) res.setHeader('Cache-Control', 'public, max-age=0, must-revalidate');
  }
}));

function asyncRoute(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

function supabaseBase() {
  if (!SUPABASE_URL || !SUPABASE_KEY) return null;
  return createClient(SUPABASE_URL, SUPABASE_KEY, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

function supabaseForToken(token) {
  if (!SUPABASE_URL || !SUPABASE_KEY || !token) return null;
  return createClient(SUPABASE_URL, SUPABASE_KEY, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

function bearer(req) {
  const value = req.headers.authorization || '';
  return value.startsWith('Bearer ') ? value.slice(7) : '';
}

function configStatus() {
  return {
    urlConfigured: Boolean(SUPABASE_URL),
    keyConfigured: Boolean(SUPABASE_KEY),
    urlHost: SUPABASE_URL ? (() => { try { return new URL(SUPABASE_URL).host; } catch { return 'URL inválida'; } })() : null,
    keyType: SUPABASE_KEY.startsWith('sb_publishable_') ? 'publishable' : SUPABASE_KEY ? 'legacy/anon' : null,
  };
}

const LIVE_OPS_CACHE_MS = 12000;
let liveOpsCache = null;
let liveOpsCacheAt = 0;
const NPC_CONFIG_CACHE_MS = 30000;
// Apenas leituras de runtime concorrentes sao coalescidas; gravacoes ADM permanecem imediatas.
const runtimeReadOnceV104=createReadCoalescerV104();
let npcRuntimeCache = null;
let npcRuntimeCacheAt = 0;

// V18.1.3 — SERVER RUNTIME TOPBAR CACHE
// O Render busca a configuração no Supabase e materializa um snapshot temporário.
// O navegador nunca reorganiza nós por reparenting; apenas lê este snapshot validado.
const TOPBAR_RUNTIME_CACHE_MS = 30000;
const TOPBAR_RUNTIME_DIR = path.join(os.tmpdir(), 'stellar-legacy-runtime');
const TOPBAR_RUNTIME_FILE = path.join(TOPBAR_RUNTIME_DIR, 'topbar.runtime.json');
const NPC_RUNTIME_FILE = path.join(TOPBAR_RUNTIME_DIR, 'npcs.runtime.json');
const TOPBAR_ALLOWED_MODULES = new Set([
  'pilot_menu','hangar','ship','pilot_research','pet',
  'missions_menu','missions','pass',
  'battle_menu','arena','warfront','gates','events','battle_group',
  'clan','map','auction','shops_menu','shop','premium','admin','config'
]);
const TOPBAR_ALLOWED_FLAGS = new Set([
  'missions','battle_pass','arena','warfront','battle_groups','clans','auction',
  'premium_shop','crafting','economy_services','live_events'
]);
let topbarRuntimeCache = null;
let topbarRuntimeCacheAt = 0;

// V18.1.4 — WORLD RUNTIME CACHE
const WORLD_RUNTIME_CACHE_MS = 30000;
const WORLD_RUNTIME_FILE = path.join(TOPBAR_RUNTIME_DIR, 'world.runtime.json');
let worldRuntimeCache = null;
let worldRuntimeCacheAt = 0;


// V18.1.5 — MISSÕES + ECONOMIA + CRAFTING RUNTIME CACHE
const SYSTEMS_RUNTIME_CACHE_MS = 15000;
const SYSTEMS_RUNTIME_FILE = path.join(TOPBAR_RUNTIME_DIR, 'systems.runtime.json');
let systemsRuntimeCache = null;
let systemsRuntimeCacheAt = 0;

// V18.1.7B — BATTLE PASS RUNTIME CACHE
const PASS_RUNTIME_CACHE_MS = 15000;
const PASS_RUNTIME_FILE = path.join(TOPBAR_RUNTIME_DIR, 'pass.runtime.json');
let passRuntimeCache = null;
let passRuntimeCacheAt = 0;

// V18.1.7C — LOJAS COMUM + PREMIUM RUNTIME CACHE
const SHOPS_RUNTIME_CACHE_MS = 30000;
const SHOPS_RUNTIME_FILE = path.join(TOPBAR_RUNTIME_DIR, 'shops.runtime.json');
let shopsRuntimeCache = null;
let shopsRuntimeCacheAt = 0;
const COMMON_SHOP_KINDS = new Set(['ship','laser','generator','drone','pet','pet_gear','extra','ammo','rocket']);
const COMMON_SHOP_TABS = new Set(['ships','lasers','generators','drones','pet','extras','ammo','rockets']);
const SYSTEM_MISSION_CATEGORIES = new Set(['daily','weekly','monthly','special']);
const SYSTEM_SERVICE_IDS = new Set(['weapon','shield','cargo','thruster']);
const SYSTEM_EFFECT_KEYS = new Set(['laser_damage_pct','shield_pct','cargo_flat','speed_flat']);
const SYSTEM_GRANT_KINDS = new Set(['resource','ammo','rocket','repair']);
function safeJsonNumberObject(obj,maxKeys=32,maxValue=1000000000){
  const out={};if(!obj||typeof obj!=='object'||Array.isArray(obj))return out;
  for(const [k,v] of Object.entries(obj).slice(0,maxKeys)){const id=safeWorldId(k),n=Math.max(0,Math.min(maxValue,Math.floor(Number(v)||0)));if(id&&n>0)out[id]=n;}return out;
}
function sanitizeMissionTask(task){
  if(!task||typeof task!=='object')return null;const type=String(task.type||'');const id=String(task.id||'').slice(0,80);const target=Math.max(1,Math.min(1000000,Math.floor(Number(task.target)||1)));
  if(type==='kill'){const npc=safeWorldId(task.npc);return npc?{id:id||`kill_${npc}_${target}`,type,npc,target}:null;}
  if(type==='ore'){const resource=safeWorldId(task.resource);return resource?{id:id||`ore_${resource}_${target}`,type,resource,target}:null;}
  return null;
}
function sanitizeSystemsRuntime(raw){
  const mission_categories=Array.isArray(raw?.mission_categories)?raw.mission_categories.map(x=>({
    category:String(x?.category||''),label:String(x?.label||'').slice(0,48),accent:String(x?.accent||'#58d9ff').slice(0,24),reset_kind:String(x?.reset_kind||'').slice(0,16),
    min_level:Math.round(clampNum(x?.min_level,1,100,1)),reward_factor:clampNum(x?.reward_factor,0,10,1),item_chance:clampNum(x?.item_chance,0,1,0),enabled:x?.enabled!==false,
    config:x?.config&&typeof x.config==='object'&&!Array.isArray(x.config)?x.config:{}
  })).filter(x=>SYSTEM_MISSION_CATEGORIES.has(x.category)):[];
  const custom_missions=Array.isArray(raw?.custom_missions)?raw.custom_missions.map(x=>({
    mission_id:String(x?.mission_id||'').slice(0,80),category:String(x?.category||''),title:String(x?.title||'').slice(0,100),description:String(x?.description||'').slice(0,260),
    tasks:Array.isArray(x?.tasks)?x.tasks.map(sanitizeMissionTask).filter(Boolean).slice(0,8):[],group_key:String(x?.group_key||'mix').slice(0,24),sequence:!!x?.sequence,
    reward_factor:x?.reward_factor==null?null:clampNum(x.reward_factor,0,10,1),tag:x?.tag==null?null:String(x.tag).slice(0,64),
    flat_reward:x?.flat_reward&&typeof x.flat_reward==='object'&&!Array.isArray(x.flat_reward)?x.flat_reward:null,enabled:x?.enabled!==false,sort_order:Math.round(clampNum(x?.sort_order,0,9999,100))
  })).filter(x=>x.mission_id&&SYSTEM_MISSION_CATEGORIES.has(x.category)&&x.tasks.length):[];
  const economy_services=Array.isArray(raw?.economy_services)?raw.economy_services.map(x=>{
    const effect={};if(x?.effect&&typeof x.effect==='object'&&!Array.isArray(x.effect)){for(const [k,v] of Object.entries(x.effect)){if(SYSTEM_EFFECT_KEYS.has(k))effect[k]=clampNum(v,-100000,100000,0);}}
    return {service_id:String(x?.service_id||''),name:String(x?.name||'').slice(0,80),description:String(x?.description||'').slice(0,180),base_cost:Math.max(0,Math.round(Number(x?.base_cost)||0)),duration_ms:Math.round(clampNum(x?.duration_ms,60000,86400000,3600000)),level_band_size:Math.round(clampNum(x?.level_band_size,1,100,5)),level_cost_scale:clampNum(x?.level_cost_scale,0,10,.35),max_stack_ms:Math.round(clampNum(x?.max_stack_ms,60000,604800000,21600000)),effect,enabled:x?.enabled!==false,sort_order:Math.round(clampNum(x?.sort_order,0,9999,100))};
  }).filter(x=>safeWorldId(x.service_id)&&x.name&&Object.keys(x.effect).length):[];
  const crafting_recipes=Array.isArray(raw?.crafting_recipes)?raw.crafting_recipes.map(x=>{
    const g=x?.grant_payload&&typeof x.grant_payload==='object'?x.grant_payload:{};const kind=String(g.kind||'');const grant=SYSTEM_GRANT_KINDS.has(kind)?{kind,id:g.id?safeWorldId(g.id):undefined,qty:Math.max(1,Math.min(10000000,Math.floor(Number(g.qty)||1)))}:{};
    return {recipe_id:String(x?.recipe_id||'').slice(0,64),name:String(x?.name||'').slice(0,80),description:String(x?.description||'').slice(0,180),cost:Math.max(0,Math.round(Number(x?.cost)||0)),currency:String(x?.currency)==='uridium'?'uridium':'credits',ingredients:safeJsonNumberObject(x?.ingredients),grant_payload:grant,output_label:String(x?.output_label||'').slice(0,80),min_level:Math.round(clampNum(x?.min_level,1,100,1)),enabled:x?.enabled!==false,sort_order:Math.round(clampNum(x?.sort_order,0,9999,100))};
  }).filter(x=>x.recipe_id&&x.name&&x.grant_payload.kind):[];
  return {version:Math.max(0,Number(raw?.version)||0),updated_at:raw?.updated_at||null,mission_categories,custom_missions,economy_services,crafting_recipes,generated_at:new Date().toISOString(),source:'render-temp-json'};
}
async function writeSystemsRuntimeFile(payload){await fs.mkdir(TOPBAR_RUNTIME_DIR,{recursive:true});const tmp=`${SYSTEMS_RUNTIME_FILE}.${process.pid}.tmp`;await fs.writeFile(tmp,JSON.stringify(payload),{encoding:'utf8'});await fs.rename(tmp,SYSTEMS_RUNTIME_FILE);}
async function readSystemsRuntimeFile(){try{const text=await fs.readFile(SYSTEMS_RUNTIME_FILE,'utf8');const parsed=JSON.parse(text);return parsed&&Array.isArray(parsed.economy_services)?parsed:null;}catch{return null;}}
async function refreshSystemsRuntimeSnapshot(force=false){
  const now=Date.now();if(!force&&systemsRuntimeCache&&now-systemsRuntimeCacheAt<SYSTEMS_RUNTIME_CACHE_MS)return systemsRuntimeCache;
  const sb=supabaseBase();if(!sb)throw new Error('Supabase indisponível para configuração de sistemas.');const {data,error}=await sb.rpc('get_systems_runtime_config_v1815');if(error)throw new Error(`Falha ao carregar systems runtime: ${error.message}`);
  const payload=sanitizeSystemsRuntime(data||{});if(!payload.mission_categories.length||!payload.economy_services.length||!payload.crafting_recipes.length)throw new Error('Snapshot de sistemas veio incompleto.');
  await writeSystemsRuntimeFile(payload);systemsRuntimeCache=payload;systemsRuntimeCacheAt=now;return payload;
}
async function loadSystemsRuntimeSnapshot(force=false){try{return await refreshSystemsRuntimeSnapshot(force);}catch(err){const disk=await readSystemsRuntimeFile();if(disk){systemsRuntimeCache=disk;systemsRuntimeCacheAt=Date.now();return disk;}throw err;}}


function sanitizePassReward(raw){
  const src=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{};
  const cleanIds=(arr,max=12)=>Array.isArray(arr)?arr.map(safeWorldId).filter(Boolean).slice(0,max):[];
  return {
    credits:Math.max(0,Math.min(1000000000000,Math.floor(Number(src.credits)||0))),
    uridium:Math.max(0,Math.min(1000000000,Math.floor(Number(src.uridium)||0))),
    ammo:safeJsonNumberObject(src.ammo,24,100000000),
    rockets:safeJsonNumberObject(src.rockets,24,100000000),
    items:cleanIds(src.items,12),
    ships:cleanIds(src.ships,8),
    repairBonus:Math.max(0,Math.min(10000,Math.floor(Number(src.repairBonus)||0)))
  };
}
function sanitizePassRuntime(raw){
  const seasons=Array.isArray(raw?.seasons)?raw.seasons.map(x=>({
    season_key:String(x?.season_key||'').slice(0,32),
    name:String(x?.name||'').slice(0,80),
    description:String(x?.description||'').slice(0,240),
    starts_at:x?.starts_at||null,ends_at:x?.ends_at||null,
    tier_count:Math.round(clampNum(x?.tier_count,1,100,30)),
    points_per_tier:Math.round(clampNum(x?.points_per_tier,1,1000000,500)),
    daily_points:Math.round(clampNum(x?.daily_points,1,100000,100)),
    premium_price_brl:clampNum(x?.premium_price_brl,0,99999,19.9),
    enabled:x?.enabled!==false,updated_at:x?.updated_at||null
  })).filter(x=>x.season_key):[];
  let active=null;
  if(raw?.active_season&&typeof raw.active_season==='object'){
    const x=raw.active_season;active={season_key:String(x?.season_key||'').slice(0,32),name:String(x?.name||'').slice(0,80),description:String(x?.description||'').slice(0,240),starts_at:x?.starts_at||null,ends_at:x?.ends_at||null,tier_count:Math.round(clampNum(x?.tier_count,1,100,30)),points_per_tier:Math.round(clampNum(x?.points_per_tier,1,1000000,500)),daily_points:Math.round(clampNum(x?.daily_points,1,100000,100)),premium_price_brl:clampNum(x?.premium_price_brl,0,99999,19.9),enabled:x?.enabled!==false};if(!active.season_key)active=null;
  }
  const maxTier=active?.tier_count||100;
  const tiers=Array.isArray(raw?.tiers)?raw.tiers.map(x=>({season_key:String(x?.season_key||active?.season_key||'').slice(0,32),tier_no:Math.round(clampNum(x?.tier_no,1,100,1)),free_reward:sanitizePassReward(x?.free_reward),premium_reward:sanitizePassReward(x?.premium_reward),enabled:x?.enabled!==false})).filter(x=>x.season_key&&x.tier_no<=maxTier):[];
  return {version:Math.max(0,Number(raw?.version)||0),updated_at:raw?.updated_at||null,active_season:active,seasons,tiers,generated_at:new Date().toISOString(),source:'render-temp-json'};
}
async function writePassRuntimeFile(payload){await fs.mkdir(TOPBAR_RUNTIME_DIR,{recursive:true});const tmp=`${PASS_RUNTIME_FILE}.${process.pid}.tmp`;await fs.writeFile(tmp,JSON.stringify(payload),{encoding:'utf8'});await fs.rename(tmp,PASS_RUNTIME_FILE);}
async function readPassRuntimeFile(){try{const text=await fs.readFile(PASS_RUNTIME_FILE,'utf8');const parsed=JSON.parse(text);return parsed&&Array.isArray(parsed.seasons)&&Array.isArray(parsed.tiers)?parsed:null;}catch{return null;}}
async function refreshPassRuntimeSnapshot(force=false){
  const now=Date.now();if(!force&&passRuntimeCache&&now-passRuntimeCacheAt<PASS_RUNTIME_CACHE_MS)return passRuntimeCache;
  const sb=supabaseBase();if(!sb)throw new Error('Supabase indisponível para configuração do Passe.');const {data,error}=await sb.rpc('get_battle_pass_runtime_config_v1817b');if(error)throw new Error(`Falha ao carregar pass runtime: ${error.message}`);
  const payload=sanitizePassRuntime(data||{});if(!payload.seasons.length)throw new Error('Snapshot do Passe veio sem temporadas.');await writePassRuntimeFile(payload);passRuntimeCache=payload;passRuntimeCacheAt=now;return payload;
}
async function loadPassRuntimeSnapshot(force=false){try{return await refreshPassRuntimeSnapshot(force);}catch(err){const disk=await readPassRuntimeFile();if(disk){passRuntimeCache=disk;passRuntimeCacheAt=Date.now();return disk;}throw err;}}

function sanitizeCommonShopMeta(raw){
  const src=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{};const g=src.grant&&typeof src.grant==='object'&&!Array.isArray(src.grant)?src.grant:{};
  const grant={};if(g.kind)grant.kind=String(g.kind).slice(0,32);if(g.id)grant.id=String(g.id).slice(0,64);if(g.protocol)grant.protocol=String(g.protocol).slice(0,32);
  if(g.qty!=null)grant.qty=Math.max(1,Math.min(10000000,Math.floor(Number(g.qty)||1)));if(g.slots!=null)grant.slots=Math.max(1,Math.min(32,Math.floor(Number(g.slots)||1)));
  return {grant};
}
function sanitizeShopsRuntime(raw){
  const common=Array.isArray(raw?.common)?raw.common.map(x=>({
    catalog_key:String(x?.catalog_key||'').slice(0,120),kind:String(x?.kind||'').slice(0,24),ref_id:String(x?.ref_id||'').slice(0,64),
    display_name:x?.display_name==null?null:String(x.display_name).slice(0,100),description:x?.description==null?null:String(x.description).slice(0,300),
    price:Math.max(0,Math.min(1000000000000,Math.round(Number(x?.price)||0))),currency:String(x?.currency)==='uridium'?'uridium':'credits',
    enabled:x?.enabled!==false,shop_tab:COMMON_SHOP_TABS.has(String(x?.shop_tab||''))?String(x.shop_tab):null,shop_visible:x?.shop_visible!==false,
    min_level:Math.round(clampNum(x?.min_level,1,100,1)),sort_order:Math.round(clampNum(x?.sort_order,0,9999,100)),meta:sanitizeCommonShopMeta(x?.meta),updated_at:x?.updated_at||null
  })).filter(x=>x.catalog_key&&COMMON_SHOP_KINDS.has(x.kind)):[];
  const premium=Array.isArray(raw?.premium)?raw.premium.map(x=>({
    id:String(x?.id||'').slice(0,80),name:String(x?.name||'').slice(0,100),category:String(x?.category||'').slice(0,32),
    price_brl:clampNum(x?.price_brl,0,99999,0),item_id:x?.item_id==null?null:String(x.item_id).slice(0,64),quantity:Math.max(1,Math.min(10000000,Math.floor(Number(x?.quantity)||1))),
    description:String(x?.description||'').slice(0,300),active:x?.active!==false,sort_order:Math.round(clampNum(x?.sort_order,0,9999,100)),min_level:Math.round(clampNum(x?.min_level,1,100,1)),
    meta:{days:Math.max(1,Math.min(3650,Math.floor(Number(x?.meta?.days)||30)))}
  })).filter(x=>x.id):[];
  return {version:Math.max(0,Number(raw?.version)||0),updated_at:raw?.updated_at||null,common,premium,generated_at:new Date().toISOString(),source:'render-temp-json'};
}
async function writeShopsRuntimeFile(payload){await fs.mkdir(TOPBAR_RUNTIME_DIR,{recursive:true});const tmp=`${SHOPS_RUNTIME_FILE}.${process.pid}.tmp`;await fs.writeFile(tmp,JSON.stringify(payload),{encoding:'utf8'});await fs.rename(tmp,SHOPS_RUNTIME_FILE);}
async function readShopsRuntimeFile(){try{const text=await fs.readFile(SHOPS_RUNTIME_FILE,'utf8');const parsed=JSON.parse(text);return parsed&&Array.isArray(parsed.common)&&Array.isArray(parsed.premium)?parsed:null;}catch{return null;}}
async function refreshShopsRuntimeSnapshot(force=false){
  const now=Date.now();if(!force&&shopsRuntimeCache&&now-shopsRuntimeCacheAt<SHOPS_RUNTIME_CACHE_MS)return shopsRuntimeCache;
  const readRuntimeV104=async()=>{
    const sb=supabaseBase();if(!sb)throw new Error('Supabase indisponível para configuração das lojas.');const {data,error}=await sb.rpc('get_shops_runtime_config_v1817c');if(error)throw new Error(`Falha ao carregar shops runtime: ${error.message}`);
  const payload=sanitizeShopsRuntime(data||{});if(!payload.common.length||!payload.premium.length)throw new Error('Snapshot das lojas veio incompleto.');await writeShopsRuntimeFile(payload);shopsRuntimeCache=payload;shopsRuntimeCacheAt=now;return payload;
  };
  return force?readRuntimeV104():runtimeReadOnceV104('shops',readRuntimeV104);
}
async function loadShopsRuntimeSnapshot(force=false){try{return await refreshShopsRuntimeSnapshot(force);}catch(err){const disk=await readShopsRuntimeFile();if(disk){shopsRuntimeCache=disk;shopsRuntimeCacheAt=Date.now();return disk;}throw err;}}

function clampNum(value,min,max,fallback){
  const n=Number(value);return Number.isFinite(n)?Math.max(min,Math.min(max,n)):fallback;
}
function safeWorldId(value){return /^[A-Za-z0-9_-]{1,32}$/.test(String(value||''))?String(value):'';}
function safeSector(value){return /^[A-Za-z0-9_-]{1,24}$/.test(String(value||''))?String(value):'';}
function sanitizeWorldRuntime(raw){
  const resources=Array.isArray(raw?.resources)?raw.resources.map(x=>({
    resource_key:safeWorldId(x?.resource_key),name:String(x?.name||'').slice(0,48),color:String(x?.color||'#ffffff').slice(0,24),
    sell_price:Math.max(0,Math.round(Number(x?.sell_price)||0)),enabled:x?.enabled!==false
  })).filter(x=>x.resource_key):[];
  const maps=Array.isArray(raw?.maps)?raw.maps.map(x=>({
    map_id:safeWorldId(x?.map_id),label:x?.label==null?null:String(x.label).slice(0,24),tier:Math.round(Number(x?.tier)||1),
    name:String(x?.name||'Setor').slice(0,64),risk:String(x?.risk||'Normal').slice(0,32),
    world_w:Math.round(clampNum(x?.world_w,1000,50000,6000)),world_h:Math.round(clampNum(x?.world_h,1000,50000,4500)),
    enemy_multiplier:clampNum(x?.enemy_multiplier,.1,10,1),ore_count:Math.round(clampNum(x?.ore_count,0,1000,0)),
    ore_respawn_min_ms:Math.round(clampNum(x?.ore_respawn_min_ms,1000,600000,5000)),ore_respawn_max_ms:Math.round(clampNum(x?.ore_respawn_max_ms,1000,600000,12000)),
    landmark_count:Math.round(clampNum(x?.landmark_count,0,100,0)),min_level:Math.round(clampNum(x?.min_level,1,100,1)),
    battle:!!x?.battle,gate:!!x?.gate,enabled:x?.enabled!==false,
    palette:x?.palette&&typeof x.palette==='object'?x.palette:{},structures:Array.isArray(x?.structures)?x.structures.slice(0,30).map(v=>String(v).slice(0,64)):[]
  })).filter(x=>x.map_id):[];
  const map_resources=Array.isArray(raw?.map_resources)?raw.map_resources.map(x=>({
    map_id:safeWorldId(x?.map_id),resource_key:safeWorldId(x?.resource_key),weight:clampNum(x?.weight,.01,1000,1),enabled:x?.enabled!==false
  })).filter(x=>x.map_id&&x.resource_key):[];
  const sectors=Array.isArray(raw?.sectors)?raw.sectors.map(x=>({
    sector_label:safeSector(x?.sector_label),map_id:safeWorldId(x?.map_id),territory_faction:x?.territory_faction==null?null:safeWorldId(x.territory_faction),
    graph_x:clampNum(x?.graph_x,0,100,50),graph_y:clampNum(x?.graph_y,0,100,50),min_level:Math.round(clampNum(x?.min_level,1,100,1)),enabled:x?.enabled!==false
  })).filter(x=>x.sector_label&&x.map_id):[];
  const portals=Array.isArray(raw?.portals)?raw.portals.map(x=>({
    portal_key:safeWorldId(x?.portal_key),from_sector:safeSector(x?.from_sector),to_sector:safeSector(x?.to_sector),
    bidirectional:x?.bidirectional!==false,enabled:x?.enabled!==false,sort_order:Math.round(clampNum(x?.sort_order,0,9999,100))
  })).filter(x=>x.portal_key&&x.from_sector&&x.to_sector):[];
  return {version:Math.max(0,Number(raw?.version)||0),updated_at:raw?.updated_at||null,resources,maps,map_resources,sectors,portals,generated_at:new Date().toISOString(),source:'render-temp-json'};
}
async function writeWorldRuntimeFile(payload){
  await fs.mkdir(TOPBAR_RUNTIME_DIR,{recursive:true});
  const tmp=`${WORLD_RUNTIME_FILE}.${process.pid}.tmp`;
  await fs.writeFile(tmp,JSON.stringify(payload),{encoding:'utf8'});
  await fs.rename(tmp,WORLD_RUNTIME_FILE);
}
async function readWorldRuntimeFile(){
  try{const text=await fs.readFile(WORLD_RUNTIME_FILE,'utf8');const parsed=JSON.parse(text);return parsed&&Array.isArray(parsed.maps)?parsed:null;}catch{return null;}
}
async function refreshWorldRuntimeSnapshot(force=false){
  const now=Date.now();
  if(!force&&worldRuntimeCache&&now-worldRuntimeCacheAt<WORLD_RUNTIME_CACHE_MS)return worldRuntimeCache;
  const readRuntimeV104=async()=>{
    const sb=supabaseBase();if(!sb)throw new Error('Supabase indisponível para configuração do mundo.');
  const {data,error}=await sb.rpc('get_world_runtime_config_v1814');
  if(error)throw new Error(`Falha ao carregar world runtime: ${error.message}`);
  const payload=sanitizeWorldRuntime(data||{});
  if(!payload.maps.length||!payload.sectors.length)throw new Error('Snapshot do mundo veio vazio.');
  await writeWorldRuntimeFile(payload);worldRuntimeCache=payload;worldRuntimeCacheAt=now;return payload;
  };
  return force?readRuntimeV104():runtimeReadOnceV104('world',readRuntimeV104);
}
async function loadWorldRuntimeSnapshot(force=false){
  try{return await refreshWorldRuntimeSnapshot(force);}catch(err){const disk=await readWorldRuntimeFile();if(disk){worldRuntimeCache=disk;worldRuntimeCacheAt=Date.now();return disk;}throw err;}
}

function sanitizeTopbarRuntime(raw){
  const modules=Array.isArray(raw?.modules)?raw.modules.filter(x=>x&&TOPBAR_ALLOWED_MODULES.has(String(x.module_key||''))).map(x=>({
    module_key:String(x.module_key),
    parent_key:x.parent_key==null?null:String(x.parent_key),
    label:String(x.label||'').slice(0,40),
    sort_order:Math.max(0,Math.min(999,Number(x.sort_order)||100)),
    min_level:Math.max(1,Math.min(100,Number(x.min_level)||1)),
    enabled:x.enabled!==false,
    hide_until_level:!!x.hide_until_level,
    admin_only:!!x.admin_only,
    config:x.config&&typeof x.config==='object'?x.config:{}
  })):[];
  const flags=Array.isArray(raw?.flags)?raw.flags.filter(x=>x&&TOPBAR_ALLOWED_FLAGS.has(String(x.flag_key||''))).map(x=>({
    flag_key:String(x.flag_key),enabled:x.enabled!==false,description:String(x.description||'').slice(0,180),
    config:x.config&&typeof x.config==='object'?x.config:{}
  })):[];
  return {
    version:Math.max(0,Number(raw?.version)||0),updated_at:raw?.updated_at||null,
    modules,flags,generated_at:new Date().toISOString(),source:'render-temp-json'
  };
}

async function writeTopbarRuntimeFile(payload){
  await fs.mkdir(TOPBAR_RUNTIME_DIR,{recursive:true});
  const tmp=`${TOPBAR_RUNTIME_FILE}.${process.pid}.tmp`;
  await fs.writeFile(tmp,JSON.stringify(payload),{encoding:'utf8'});
  await fs.rename(tmp,TOPBAR_RUNTIME_FILE);
}

async function readTopbarRuntimeFile(){
  try{
    const text=await fs.readFile(TOPBAR_RUNTIME_FILE,'utf8');
    const parsed=JSON.parse(text);
    return parsed&&Array.isArray(parsed.modules)?parsed:null;
  }catch{return null;}
}

async function refreshTopbarRuntimeSnapshot(force=false){
  const now=Date.now();
  if(!force&&topbarRuntimeCache&&now-topbarRuntimeCacheAt<TOPBAR_RUNTIME_CACHE_MS)return topbarRuntimeCache;
  const readRuntimeV104=async()=>{
    const sb=supabaseBase();
  if(!sb)throw new Error('Supabase indisponível para configuração da topbar.');
  const {data,error}=await sb.rpc('get_game_runtime_public_v1813');
  if(error)throw new Error(`Falha ao carregar topbar runtime: ${error.message}`);
  const payload=sanitizeTopbarRuntime(data||{});
  if(!payload.modules.length)throw new Error('Snapshot da topbar veio vazio.');
  await writeTopbarRuntimeFile(payload);
  topbarRuntimeCache=payload;
  topbarRuntimeCacheAt=now;
  return payload;
  };
  return force?readRuntimeV104():runtimeReadOnceV104('topbar',readRuntimeV104);
}

async function loadTopbarRuntimeSnapshot(force=false){
  try{return await refreshTopbarRuntimeSnapshot(force);}catch(err){
    const disk=await readTopbarRuntimeFile();
    if(disk){topbarRuntimeCache=disk;topbarRuntimeCacheAt=Date.now();return disk;}
    throw err;
  }
}

const livePurchaseLocks = new Map();

async function loadLiveOpsSnapshot(force=false) {
  const now=Date.now();
  if(!force&&liveOpsCache&&now-liveOpsCacheAt<LIVE_OPS_CACHE_MS)return liveOpsCache;
  const sb=supabaseBase();
  if(!sb)throw new Error('Supabase indisponível para LIVE OPS.');
  const {data,error}=await sb.rpc('get_live_ops_v16');
  if(error)throw new Error(`Falha ao carregar LIVE OPS: ${error.message}`);
  liveOpsCache=(data&&typeof data==='object')?data:{events:[],catalog:[],server_time:now};
  liveOpsCacheAt=now;
  return liveOpsCache;
}

async function writeNpcRuntimeFile(payload){await fs.mkdir(TOPBAR_RUNTIME_DIR,{recursive:true});const tmp=`${NPC_RUNTIME_FILE}.${process.pid}.tmp`;await fs.writeFile(tmp,JSON.stringify(payload),{encoding:'utf8'});await fs.rename(tmp,NPC_RUNTIME_FILE);}
async function readNpcRuntimeFile(){try{const text=await fs.readFile(NPC_RUNTIME_FILE,'utf8');const parsed=JSON.parse(text);return parsed&&Array.isArray(parsed.npcs)&&Array.isArray(parsed.spawns)?parsed:null;}catch{return null;}}
async function refreshNpcRuntimeSnapshot(force=false){
  const now=Date.now();
  if(!force&&npcRuntimeCache&&now-npcRuntimeCacheAt<NPC_CONFIG_CACHE_MS)return npcRuntimeCache;
  const readRuntimeV104=async()=>{
    const sb=supabaseBase();
  if(!sb)throw new Error('Supabase indisponível para configuração de NPCs.');
  const {data,error}=await sb.rpc('get_npc_runtime_config_v1811');
  if(error)throw new Error(`Falha ao carregar configuração de NPCs: ${error.message}`);
  const payload=(data&&typeof data==='object')?data:{version:0,npcs:[],spawns:[]};
  if(!Array.isArray(payload.npcs)||!payload.npcs.length)throw new Error('Snapshot de NPCs veio incompleto.');
  await writeNpcRuntimeFile(payload);npcRuntimeCache=payload;npcRuntimeCacheAt=now;return payload;
  };
  return force?readRuntimeV104():runtimeReadOnceV104('npc',readRuntimeV104);
}
async function loadNpcRuntimeSnapshot(force=false){try{return await refreshNpcRuntimeSnapshot(force);}catch(err){const disk=await readNpcRuntimeFile();if(disk){npcRuntimeCache=disk;npcRuntimeCacheAt=Date.now();return disk;}throw err;}}

function liveCatalogRow(snapshot,key){
  return (snapshot?.catalog||[]).find(row=>row?.enabled&&String(row.catalog_key||'')===String(key||''))||null;
}
function premiumDiscountEligible(row){
  return row?.currency==='uridium'&&['ship','laser','generator','drone','extra','pet','pet_gear'].includes(String(row?.kind||''));
}
const PET_LASER_CAP_BY_LEVEL=[0,2,2,3,3,4,4,5,5,6,6,7,7,8,9,10,10,11,11,12,12];
const PET_SHIELD_CAP_BY_LEVEL=[0,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22];
function petSlotCapacityServer(kind,level){const lv=Math.max(1,Math.min(20,Number(level)||1));return kind==='shield'?PET_SHIELD_CAP_BY_LEVEL[lv]:PET_LASER_CAP_BY_LEVEL[lv];}
function ensurePetState(state){
  state.pet ||= {owned:false,level:1,xp:0,xpModelV175:true,laserSlotsUnlocked:0,shieldSlotsUnlocked:0,lasers:[],shields:[],gearsOwned:{guard:false,box:false,ore:false,repair:false,kami:false},activeGear:'off',kamikazeReadyAt:0};
  state.pet.gearsOwned ||= {guard:false,box:false,ore:false,repair:false,kami:false};
  state.pet.lasers ||= [];state.pet.shields ||= [];
  return state.pet;
}
function applyLiveGrant(state,row){
  const grant=row?.meta?.grant||{};
  const kind=String(grant.kind||'');
  const id=String(grant.id||row?.ref_id||'');
  const qty=Math.max(1,Math.floor(Number(grant.qty)||1));
  if(kind==='ship'){state.ownedShips ||= [];if(state.ownedShips.includes(id))throw Object.assign(new Error('Nave já obtida.'),{status:409});state.ownedShips.push(id);return;}
  if(kind==='inventory'){state.inventory ||= {};const equippedExtra=(state.shipLoadout?.extras||[]).includes(id);if(row.kind==='extra'&&((state.inventory[id]||0)>0||equippedExtra))throw Object.assign(new Error('Esse EXTRA já pertence à sua conta.'),{status:409});state.inventory[id]=(Number(state.inventory[id])||0)+qty;return;}
  if(kind==='drone'){state.drones ||= [];if(state.drones.length>=8)throw Object.assign(new Error('Limite de 8 drones atingido.'),{status:409});state.drones.push({id:`d_${Date.now()}_${randomUUID().slice(0,6)}`,type:id,slots:Array(Math.max(1,Number(grant.slots)||1)).fill(null)});return;}
  if(kind==='ammo'){state.ammo ||= {};state.ammo[id]=(Number(state.ammo[id])||0)+qty;return;}
  if(kind==='rocket'){state.rockets ||= {};state.rockets[id]=(Number(state.rockets[id])||0)+qty;return;}
  if(kind==='pet_base'){const pet=ensurePetState(state);if(pet.owned)throw Object.assign(new Error('AUX-9 já adquirido.'),{status:409});pet.owned=true;pet.level=Math.max(1,Number(pet.level)||1);pet.laserSlotsUnlocked=Math.max(1,Number(pet.laserSlotsUnlocked)||1);pet.shieldSlotsUnlocked=Math.max(2,Number(pet.shieldSlotsUnlocked)||2);pet.lasers=pet.lasers.length?pet.lasers:[null];pet.shields=pet.shields.length?pet.shields:[null,null];return;}
  if(kind==='pet_gear'){const pet=ensurePetState(state);if(!pet.owned)throw Object.assign(new Error('Adquira o AUX-9 primeiro.'),{status:409});if(pet.gearsOwned[id])throw Object.assign(new Error('Módulo já adquirido.'),{status:409});pet.gearsOwned[id]=true;return;}
  throw Object.assign(new Error('Produto ainda não habilitado para compra autoritativa nesta etapa.'),{status:409});
}

async function withPurchaseLock(userId,fn){
  const prev=livePurchaseLocks.get(userId)||Promise.resolve();
  let release;const current=new Promise(r=>release=r);livePurchaseLocks.set(userId,current);
  await prev.catch(()=>{});
  try{return await fn();}finally{release();if(livePurchaseLocks.get(userId)===current)livePurchaseLocks.delete(userId);}
}


const GATE_SERVER_DEFS={
  alpha:{key:'alpha',label:'AURORA',pieces:34,unlock:null,baseLives:3,maxLives:5},
  beta:{key:'beta',label:'NEXUS',pieces:48,unlock:null,baseLives:3,maxLives:5},
  gamma:{key:'gamma',label:'ECLIPSE',pieces:64,unlock:null,baseLives:3,maxLives:5},
};
const GATE_AMMO={lcb10:{name:'PLS-1',base:300},mcb25:{name:'PLS-2',base:200},mcb50:{name:'PLS-3',base:120},ucb100:{name:'PLS-4',base:70}};
const GATE_ROCKETS={r310:{name:'CMT-1',base:15},plt2026:{name:'CMT-2',base:10},plt2021:{name:'CMT-3',base:7},plt3030:{name:'CMT-4',base:5}};
function randomChoiceServer(list){return list[Math.floor(Math.random()*list.length)];}
function randomIntServer(min,max){return Math.floor(min+Math.random()*(max-min+1));}
function ensureGalaxyGateServer(state){
  state.galaxyGate ||= {jumpBonus:0,lifeBonus:0,repairBonus:0,lastResults:[],selected:'alpha'};
  const g=state.galaxyGate;g.jumpBonus=Math.max(0,Number(g.jumpBonus)||0);g.lifeBonus=Math.max(0,Number(g.lifeBonus)||0);g.repairBonus=Math.max(0,Number(g.repairBonus)||0);g.lastResults=Array.isArray(g.lastResults)?g.lastResults:[];g.selected=GATE_SERVER_DEFS[g.selected]?g.selected:'alpha';
  for(const [key,def] of Object.entries(GATE_SERVER_DEFS)){
    g[key] ||= {pieces:[],built:false,lives:def.baseLives,completed:0,failed:0,run:null,lastCompletion:null};
    const x=g[key];x.pieces=Array.isArray(x.pieces)?[...new Set(x.pieces.map(Number).filter(n=>n>=1&&n<=def.pieces))]:[];x.built=!!x.built||x.pieces.length>=def.pieces;x.lives=Math.max(0,Math.min(def.maxLives,(x.lives===null||x.lives===undefined?def.baseLives:Number(x.lives))));x.completed=Math.max(0,Number(x.completed)||0);
  }
  return g;
}
function gateUnlockedServer(state,key){return !!GATE_SERVER_DEFS[key];}
function pilotLuckServer(state){
  const skills=state?.pilotBio?.skills||{};
  const values={luck1:[2,4],luck2:[2,4,8]};
  let total=0;for(const id of ['luck1','luck2']){const lv=Math.max(0,Math.floor(Number(skills[id])||0));if(lv)total+=Number(values[id][Math.min(lv,values[id].length)-1]||0);}return total/100;
}
function addGatePieceServer(state,key){
  const g=ensureGalaxyGateServer(state),gate=g[key],def=GATE_SERVER_DEFS[key];const missing=Array.from({length:def.pieces},(_,i)=>i+1).filter(n=>!gate.pieces.includes(n));
  if(!missing.length){gate.built=true;return null;}const piece=randomChoiceServer(missing);gate.pieces.push(piece);gate.pieces.sort((a,b)=>a-b);if(gate.pieces.length>=def.pieces)gate.built=true;return piece;
}
function rollGateOnceServer(state,key){
  const g=ensureGalaxyGateServer(state),gate=g[key],def=GATE_SERVER_DEFS[key];state.profile ||= {};state.pilotBio ||= {};state.pilotBio.logDisks=Math.max(0,Number(state.pilotBio.logDisks)||0);state.ammo ||= {};state.rockets ||= {};state.cargo ||= {};
  const luck=pilotLuckServer(state);let r=Math.random()*100;if(luck>0)r=Math.max(0,r-luck*18);if(gate.built&&r<12)r=12+Math.random()*88;
  if(r<12){const piece=addGatePieceServer(state,key);return {kind:'piece',label:`Peça ${def.label} #${piece}`,piece};}
  if(r<20){const qty=randomIntServer(1,5);state.pilotBio.logDisks+=qty;return {kind:'logdisk',label:`Núcleos Quânticos +${qty}`,qty};}
  if(r<45){const id=randomChoiceServer(Object.keys(GATE_AMMO)),qty=GATE_AMMO[id].base*randomIntServer(1,4);state.ammo[id]=(Number(state.ammo[id])||0)+qty;return {kind:'ammo',id,qty,label:`${GATE_AMMO[id].name} +${qty}`};}
  if(r<64){const id=randomChoiceServer(Object.keys(GATE_ROCKETS)),qty=GATE_ROCKETS[id].base*randomIntServer(1,4);state.rockets[id]=(Number(state.rockets[id])||0)+qty;return {kind:'rocket',id,qty,label:`${GATE_ROCKETS[id].name} +${qty}`};}
  if(r<80){const qty=randomIntServer(1500,12000);state.profile.credits=Math.max(0,Number(state.profile.credits)||0)+qty;return {kind:'credits',qty,label:`Créditos +${qty}`};}
  if(r<90){const qty=randomIntServer(4,18);state.cargo.Xenomit=(Number(state.cargo.Xenomit)||0)+qty;return {kind:'xenomit',qty,label:`Voidite +${qty}`};}
  if(r<95){g.jumpBonus++;return {kind:'jump',label:'Bônus de Salto +1'};}
  g.jumpBonus++;return {kind:'jump',label:'Bônus de Salto +1'}; // Vida removida dos giros V19.0.6
}
async function readSaveForWrite(req){
 const service=await requireEliteAdmin();
 const result=await service.rpc('stellar_player_read',{p_user_id:req.user.id,p_token:req.body?.expected_token||null,p_checkpoint_ids:typeof req.query?.checkpoint_receipts==='string'?req.query.checkpoint_receipts.split(',').filter(x=>/^[a-f0-9-]{36}$/i.test(x)).slice(0,16):null});
 if(!result.error)req.playerBaseV134=structuredClone(result.data?.state||null);
 if(req.saveOperationV133&&!result.error){
  const {data:receipt,error}=await service.from('stellar_player_commands_v134').select('request_hash').eq('user_id',req.user.id).eq('command_id',req.saveOperationV133.id).maybeSingle();
  if(error)return {error};
  if(receipt)result.data={...result.data,...(receipt.request_hash===req.saveOperationV133.hash?{replayed:true}:{receipt_error:'SAVE_IDEMPOTENCY_ID_REUSED'})};
 }
 return result;
}
async function readEconomySave(req){
  const {data,error}=await readSaveForWrite(req);
  if(error)throw new Error(error.message);
  if(!data?.state)throw Object.assign(new Error('Save online ainda não foi criado.'),{status:409});
  req.economyBaselineV125=data.updated_at;req.economyBaseV134=structuredClone(data.state);
  req.saveTokenV131=data.save_token;
  const state=structuredClone(data.state);
  if(String(state.accountOwnerId||req.user.id)!==req.user.id)throw Object.assign(new Error('SAVE BLOQUEADO: proprietário inválido.'),{status:409});
  state.profile ||= {};
  return state;
}
async function writeEconomySave(req,state){
  state.serverPurchaseRevision=Math.max(0,Math.floor(Number(state.serverPurchaseRevision)||0))+1;
  state.accountOwnerId=req.user.id;state.accountOwnerEmail=req.user.email||null;const updated_at=new Date().toISOString();
  const profile=state.profile||{};let securedCallsign=normalizeCallsign(profile.callsign||'');if(!securedCallsign)securedCallsign=await ensureProfile(req.sb,req.user);
  state.profile={...profile,callsign:securedCallsign};
  // V102: only publish the profile after the guarded save succeeds. A failed
  // SAVE_NPC_STALE must never update the public profile or charge any resources.
  const saveError=await writeVerifiedSave(req,state,updated_at);
  if(saveError)throw new Error(saveError.message);
  // Perfil atualizado na MESMA transacao do save oficial (V118).
  return updated_at;
}
function debitServer(state,amount,currency){const c=currency==='uridium'?'uridium':'credits',price=Math.max(0,Math.round(Number(amount)||0)),balance=Math.max(0,Number(state.profile?.[c])||0);if(balance<price)throw Object.assign(new Error(`Saldo insuficiente: faltam ${price-balance} ${c==='uridium'?'STL':'CR'}.`),{status:409});state.profile[c]=balance-price;return {currency:c,price,balance:state.profile[c]};}
function creditServer(state,amount,currency){const c=currency==='uridium'?'uridium':'credits',value=Math.max(0,Math.round(Number(amount)||0));state.profile[c]=Math.max(0,Number(state.profile?.[c])||0)+value;return {currency:c,value,balance:state.profile[c]};}
function catalogSellRow(snapshot,itemId){return (snapshot?.catalog||[]).find(r=>r?.enabled&&String(r.ref_id||'')===String(itemId||'')&&['laser','generator','extra'].includes(String(r.kind||'')))||null;}

function gameSessionIdFromRequest(req) {
  return String(req.headers['x-game-session-id'] || '').trim();
}

function deviceLabel(req) {
  const ua = String(req.headers['user-agent'] || 'Dispositivo').replace(/\s+/g, ' ').trim();
  return ua.slice(0, 160) || 'Dispositivo';
}

async function registerGameSession(sb, req) {
  const sessionId = randomUUID();
  const { data, error } = await sb.rpc('register_game_session_v1214', {
    p_session_id: sessionId,
    p_device_label: deviceLabel(req),
  });
  if (error) throw new Error(`Falha ao registrar sessão do jogo: ${error.message}`);
  return { sessionId, replacedPrevious: Boolean(data?.replaced_previous) };
}

async function validateGameSession(sb, req, { touch = true } = {}) {
  const sessionId = gameSessionIdFromRequest(req);
  if (!sessionId) return { valid: false, missing: true, reason: 'missing' };
  const { data, error } = await sb.rpc('validate_game_session_v1214', {
    p_session_id: sessionId,
    p_touch: Boolean(touch),
  });
  if (error) throw new Error(`Falha ao validar sessão do jogo: ${error.message}`);
  return { ...(data || {}), sessionId };
}


async function accountAccessState(sb){
  try{
    const {data,error}=await sb.rpc('get_my_account_access_v1763');
    if(error){
      // Compatibilidade temporária se o deploy do front ocorrer antes da migration.
      if(String(error.code||'')==='42883'||/get_my_account_access_v1763.*does not exist/i.test(String(error.message||'')))return {allowed:true,is_banned:false};
      throw new Error(`Falha ao validar acesso da conta: ${error.message}`);
    }
    return data&&typeof data==='object'?data:{allowed:true,is_banned:false};
  }catch(err){throw err;}
}

function bannedResponse(res,access){
  const until=access?.banned_until?` até ${new Date(access.banned_until).toLocaleString('pt-BR')}`:'';
  const reason=String(access?.reason||'').trim();
  return res.status(403).json({error:`Conta banida${until}.${reason?` Motivo: ${reason}`:''}`,code:'ACCOUNT_BANNED',banned_until:access?.banned_until||null,reason:reason||null});
}

async function requireUser(req, res, next) {
  try {
    // V103: a trava do Farm já autenticou esta requisição. Não consultar
    // token/sessão duas vezes na mesma operação, reduzindo rede ao Render.
    if(req.user?.id && req.gameSessionId && req.accessToken === bearer(req))return next();
    const token = bearer(req);
    if (!token) return res.status(401).json({ error: 'Sessão ausente.' });
    const sb = supabaseBase();
    if (!sb) return res.status(503).json({ error: 'Supabase não configurado no servidor.', diagnostics: configStatus() });
    const { data, error } = await sb.auth.getUser(token);
    if (error || !data?.user) return res.status(401).json({ error: 'Sessão inválida ou expirada.' });
    req.accessToken = token;
    req.user = data.user;
    req.sb = supabaseForToken(token);
    const access=await accountAccessState(req.sb);
    if(access?.is_banned||access?.allowed===false)return bannedResponse(res,access);
    const gameSession = await validateGameSession(req.sb, req, { touch: true });
    if (!gameSession.valid) {
      return res.status(gameSession.missing ? 401 : 409).json({
        error: gameSession.missing
          ? 'Faça login novamente para ativar a proteção de sessão única.'
          : 'Sua conta foi acessada em outro dispositivo.',
        code: gameSession.missing ? 'SESSION_REQUIRED' : 'SESSION_REPLACED',
      });
    }
    req.gameSessionId = gameSession.sessionId;
    next();
  } catch (err) {
    next(err);
  }
}

// V103: fail closed on writes from any gameplay module while Offline Farm
// owns the player's economic snapshot. Consultas/ADM/auth permanecem ativos.
app.use('/api',makeOfflineFarmApiSafetyV103({requireUser,getAdmin:requireEliteAdmin}));

function normalizeCallsign(value = '') {
  return String(value || '').trim().replace(/\s+/g, ' ').slice(0, 24);
}

function fallbackCallsign(user) {
  const suffix = String(user?.id || randomUUID()).replace(/-/g, '').slice(0, 6).toUpperCase();
  return `Pilot-${suffix}`.slice(0, 24);
}

async function callsignAvailable(sb, callsign, excludeUserId = null) {
  const preferred = normalizeCallsign(callsign);
  if (!preferred) return false;
  // V14.1 RPC é SECURITY DEFINER e enxerga todos os perfis sem expor dados privados.
  const { data, error } = await sb.rpc('callsign_available_v141', {
    p_callsign: preferred,
    p_exclude_user: excludeUserId || null,
  });
  if (!error) return Boolean(data);
  // Compatibilidade durante a janela entre deploy e execução da migration.
  const fallback = await sb.from('profiles').select('id').ilike('callsign', preferred).limit(2);
  if (!fallback.error) return !(fallback.data || []).some(row => !excludeUserId || row.id !== excludeUserId);
  return null;
}

async function ensureProfile(sb, user, callsign = '') {
  const { data: existing, error: readError } = await sb.from('profiles').select('id,callsign').eq('id', user.id).maybeSingle();
  if (readError) throw new Error(`Falha ao carregar perfil: ${readError.message}`);
  if (existing?.callsign) return normalizeCallsign(existing.callsign);

  let preferred = normalizeCallsign(callsign || user.user_metadata?.callsign || user.email?.split('@')[0] || 'Pilot');
  if (preferred.length < 3) preferred = fallbackCallsign(user);
  const available = await callsignAvailable(sb, preferred, user.id);
  if (available === false) preferred = fallbackCallsign(user);

  const { data: created, error } = await sb.from('profiles').insert({
    id: user.id,
    callsign: preferred,
    updated_at: new Date().toISOString(),
  }).select('callsign').single();
  if (error) {
    // Em caso de corrida na reserva de nome, cria identidade técnica única para não bloquear o login.
    if (String(error.code) === '23505' || /callsign|duplicate|unique/i.test(String(error.message || ''))) {
      const {data:concurrent,error:lookupError}=await sb.from('profiles').select('callsign').eq('id',user.id).maybeSingle();
      if(lookupError)throw new Error('Falha ao confirmar o perfil.');
      if(concurrent?.callsign)return normalizeCallsign(concurrent.callsign);
      preferred = fallbackCallsign(user);
      const retry = await sb.from('profiles').insert({ id: user.id, callsign: preferred, updated_at: new Date().toISOString() }).select('callsign').single();
      if (retry.error) throw new Error(`Falha ao criar perfil seguro: ${retry.error.message}`);
      return normalizeCallsign(retry.data?.callsign || preferred);
    }
    throw new Error(`Falha ao criar perfil: ${error.message}`);
  }
  return normalizeCallsign(created?.callsign || preferred);
}

async function accountUser(sb, user, preferred = '') {
  const callsign = await ensureProfile(sb, user, preferred);
  return { id: user.id, email: user.email, callsign };
}

app.get('/health', (req, res) => res.json({ ok: true, game: 'Stellar Legacy', version: RELEASE_VERSION, universe: 'shared' }));


app.get('/api/config', (req, res) => {
  if (!SUPABASE_URL || !SUPABASE_KEY) {
    return res.status(503).json({ error: 'Supabase não configurado no Render.', diagnostics: configStatus() });
  }
  res.json({
    supabaseUrl: SUPABASE_URL,
    supabasePublishableKey: SUPABASE_KEY,
    directBrowserMode: true,
  });
});

app.get('/api/meta', (req, res) => res.json({
  name: 'Stellar Legacy',
  version: RELEASE_VERSION,
  authReady: Boolean(SUPABASE_URL && SUPABASE_KEY),
  diagnostics: configStatus(),
  features: ['server_save_guard', 'security_incidents', 'automatic_temporary_suspensions', 'admin_security_review', 'login', 'cloud_save', 'factions', 'safe_zone', 'shop', 'owned_ships', 'equipment_slots', 'inventory', 'drones', 'ammo', 'rockets', 'expanded_expedition_maps', 'cargo_hold', 'ore_trading', 'npc_cargo_boxes', 'npc_respawn', 'minimap_navigation', 'waypoints', 'landmark_discovery', 'combat_fx', 'pet_modules', 'auto_buy_cpu', 'v8_asset_identity', 'mission_control_v93', 'mission_acceptance_tracking', 'expanded_enemy_density', 'online_player_presence', 'real_player_auction', 'rank_nameplates_v12', 'clans_v12', 'clan_vault_v12', 'premium_shop_v12', 'battle_pass_paid_v12', 'premium_subscription_v12', 'clan_daily_economy_v12', 'portal_neutral_zone_v12', 'base_only_equipment_v12', 'single_session_v1214', 'manual_login_v141', 'google_oauth_login_v18216', 'public_privacy_terms_v18217', 'account_bound_save_v141', 'unique_callsign_v141', 'premium_auto_combat_v141', 'shared_universe_v15', 'authoritative_npcs_v15', 'shared_ores_v15', 'shared_events_v15', 'websocket_world_v15', 'npc_contribution_v15', 'realtime_player_socket_v151', 'remote_laser_fx_v151', 'remote_aux9_v151', 'low_latency_world_v151', 'live_ops_v16', 'server_authoritative_shop_v16', 'supabase_event_schedule_v16', 'economy_guard_v161', 'server_auto_buy_v161', 'server_trader_v161', 'server_pet_slots_v161', 'server_materializer_v161', 'server_quantum_cores_v161', 'economy_fast_path_v1767', 'chat_dock_v162', 'drone_designers_v163', 'designer_sets_v163', 'nexus_eclipse_designer_drops_v163', 'global_chat_v162', 'clan_chat_v162', 'private_chat_v162', 'bottom_hud_reflow_v162', 'ship_designers_v165', 'aux_designers_v165', 'designer_ship_abilities_v165', 'event_designer_drops_v165', 'social_minimap_v165', 'realtime_designer_visuals_v165', 'data_driven_core_v1810', 'data_driven_npcs_v1811', 'server_runtime_topbar_cache_v1813', 'data_driven_world_v1814', 'data_driven_systems_v1815', 'admin_runtime_monitor_v1816a', 'admin_interface_editor_v1816b', 'admin_npc_editor_v1816c', 'admin_world_editor_v1816d', 'admin_systems_editor_v1816e', 'event_scheduler_v1817a', 'battle_pass_data_driven_v1817b', 'shops_data_driven_v1817c', 'hangar_refinery_v1829', 'remote_trader_elite_v1829', 'drone_progressive_pricing_v1829', 'pet_cargo_boxes_v1829'],
}));


app.get('/api/runtime/topbar', requireUser, asyncRoute(async (req,res)=>{
  const snapshot=await loadTopbarRuntimeSnapshot(Boolean(req.query?.refresh));
  let isAdmin=false;
  try{
    const {data}=await req.sb.rpc('admin_status_v1763');
    isAdmin=!!data?.is_admin;
  }catch{}
  res.set('Cache-Control','no-store');
  res.json({...snapshot,is_admin:isAdmin});
}));

app.get('/api/runtime/npcs', requireUser, asyncRoute(async (req,res)=>{
  const snapshot=await loadNpcRuntimeSnapshot(Boolean(req.query?.refresh));
  res.set('Cache-Control','no-store');
  res.json(snapshot);
}));

async function runtimeFileStatus(file){
  try{const st=await fs.stat(file);return {exists:true,file:path.basename(file),bytes:st.size,updated_at:st.mtime.toISOString()};}
  catch{return {exists:false,file:path.basename(file),bytes:0,updated_at:null};}
}
app.get('/api/admin/runtime-monitor', requireUser, asyncRoute(async(req,res)=>{
  const {data:adm,error:admErr}=await req.sb.rpc('admin_status_v1763');
  if(admErr||!adm?.is_admin)return res.status(403).json({error:'Acesso administrativo negado.'});
  const force=String(req.query?.refresh||'')==='1';
  const jobs=[
    ['topbar',()=>loadTopbarRuntimeSnapshot(force),TOPBAR_RUNTIME_FILE],
    ['npcs',()=>loadNpcRuntimeSnapshot(force),NPC_RUNTIME_FILE],
    ['world',()=>loadWorldRuntimeSnapshot(force),WORLD_RUNTIME_FILE],
    ['systems',()=>loadSystemsRuntimeSnapshot(force),SYSTEMS_RUNTIME_FILE],
    ['pass',()=>loadPassRuntimeSnapshot(force),PASS_RUNTIME_FILE],
    ['shops',()=>loadShopsRuntimeSnapshot(force),SHOPS_RUNTIME_FILE],
  ];
  const out={};
  for(const [key,loader,file] of jobs){
    try{const cfg=await loader();const f=await runtimeFileStatus(file);out[key]={ok:true,version:Number(cfg?.version)||0,source:String(cfg?.source||'render-temp-json'),config_updated_at:cfg?.updated_at||null,...f};}
    catch(err){const f=await runtimeFileStatus(file);out[key]={ok:false,version:0,source:'unavailable',config_updated_at:null,error:err?.message||'Falha no runtime',...f};}
  }
  res.set('Cache-Control','no-store');
  res.json({ok:true,generated_at:new Date().toISOString(),runtimes:out});
}));

// V18.1.6B — editor isolado da Interface. Somente módulos já conhecidos pelo motor.
app.post('/api/admin/runtime/interface/:moduleKey', requireUser, asyncRoute(async(req,res)=>{
  const key=String(req.params?.moduleKey||'').trim();
  if(!TOPBAR_ALLOWED_MODULES.has(key))return res.status(400).json({error:'Módulo de interface inválido.'});
  const body=req.body&&typeof req.body==='object'?req.body:{};
  const label=String(body.label||'').trim().slice(0,40);
  if(!label)return res.status(400).json({error:'Informe um nome para a aba.'});
  const sortOrder=Math.max(0,Math.min(999,Math.trunc(Number(body.sort_order)||0)));
  let minLevel=Math.max(1,Math.min(100,Math.trunc(Number(body.min_level)||1)));
  let enabled=body.enabled!==false;
  let hideUntilLevel=!!body.hide_until_level;
  // Proteção: o ADM nunca pode se auto-ocultar pelo editor.
  if(key==='admin'){minLevel=1;enabled=true;hideUntilLevel=false;}
  const {data,error}=await req.sb.rpc('admin_update_ui_module_v1810',{
    p_module_key:key,p_label:label,p_sort_order:sortOrder,p_min_level:minLevel,
    p_enabled:enabled,p_hide_until_level:hideUntilLevel,p_config:null
  });
  if(error){const msg=String(error.message||'Falha ao salvar módulo.');const denied=/administrativ|permiss|negado/i.test(msg);return res.status(denied?403:400).json({error:msg});}
  // Materializa imediatamente o novo JSON no Render.
  const runtime=await refreshTopbarRuntimeSnapshot(true);
  res.set('Cache-Control','no-store');
  res.json({ok:true,module_key:key,runtime:{...runtime,is_admin:true},saved:data||null});
}));

// V82 • Inventário de drop editável, com chaves existentes e limites conservadores.
// Ninguém pode inventar novo recurso, negativo, fração ou chave que não exista na economia.
export function validateNpcDropResourcesV82(proposed,previous){
  const original=previous&&typeof previous==='object'&&!Array.isArray(previous)?previous:{};
  if(proposed===undefined)return {...original};
  if(!proposed||typeof proposed!=='object'||Array.isArray(proposed))throw Error('Drops do NPC devem ser um objeto.');
  const keys=Object.keys(proposed),known=Object.keys(original);
  if(keys.length>40||keys.some(k=>!known.includes(k)))throw Error('Recurso não cadastrado para este NPC.');
  const result={...original};
  for(const key of known){
    if(!(key in proposed))throw Error('Envie todos os recursos já vinculados ao NPC.');
    const n=Number(proposed[key]);
    if(!Number.isSafeInteger(n)||n<0||n>100000)throw Error('Quantidade inválida para '+key);
    result[key]=n;
  }
  return result;
}

// V18.1.6C — editor isolado de NPCs. Só atributos e spawns já existentes.
app.post('/api/admin/runtime/npcs/:npcKey', requireUser, asyncRoute(async(req,res)=>{
  const key=String(req.params?.npcKey||'').trim();
  const current=await loadNpcRuntimeSnapshot(false);
  const currentRow=current?.npcs?.find(x=>String(x.npc_key)===key);
  if(!currentRow)return res.status(400).json({error:'NPC inválido.'});
  const body=req.body&&typeof req.body==='object'?req.body:{};
  const name=String(body.name||'').trim().slice(0,48);
  if(!name)return res.status(400).json({error:'Informe o nome do NPC.'});
  const respawnMin=Math.round(clampNum(body.respawn_min_ms,1000,600000,6000));
  const respawnMax=Math.round(clampNum(body.respawn_max_ms,1000,600000,13000));
  if(respawnMax<respawnMin)return res.status(400).json({error:'Respawn máximo deve ser maior ou igual ao mínimo.'});
  let validatedNpcDrops;try{validatedNpcDrops=validateNpcDropResourcesV82(body.resources,currentRow.resources);}catch(e){return res.status(400).json({error:String(e.message||'Drops inválidos')});}
  const args={
    p_npc_key:key,p_name:name,
    p_hp:Math.round(clampNum(body.hp,1,1000000000,1)),
    p_shield:Math.round(clampNum(body.shield,0,1000000000,0)),
    p_credits:Math.round(clampNum(body.credits,0,1000000000000,0)),
    p_stl:Math.round(clampNum(body.stl,0,1000000000,0)),
    p_xp:Math.round(clampNum(body.xp,0,1000000000000,0)),
    p_speed:clampNum(body.speed,1,1000,30),
    p_damage:Math.round(clampNum(body.damage,0,1000000000,0)),
    p_color:String(currentRow.color||'#ff755d'),p_size:clampNum(currentRow.size,4,250,18),p_resources:validatedNpcDrops,
    p_respawn_min_ms:respawnMin,p_respawn_max_ms:respawnMax,
    p_enabled:body.enabled!==false
  };
  const {data,error}=await req.sb.rpc('admin_update_npc_v1811',args);
  if(error){const msg=String(error.message||'Falha ao salvar NPC.');const denied=/administrativ|permiss|negado/i.test(msg);return res.status(denied?403:400).json({error:msg});}
  const runtime=await refreshNpcRuntimeSnapshot(true);
  res.set('Cache-Control','no-store');res.json({ok:true,npc_key:key,runtime,saved:data||null});
}));

app.post('/api/admin/runtime/npcs/:npcKey/spawns/:mapId', requireUser, asyncRoute(async(req,res)=>{
  const key=String(req.params?.npcKey||'').trim(),mapId=String(req.params?.mapId||'').trim();
  const current=await loadNpcRuntimeSnapshot(false);
  if(!current?.spawns?.some(x=>String(x.npc_key)===key&&String(x.map_id)===mapId))return res.status(400).json({error:'Vínculo NPC/mapa inválido nesta etapa.'});
  const body=req.body&&typeof req.body==='object'?req.body:{};
  const count=Math.round(clampNum(body.spawn_count,0,500,0));
  const {data,error}=await req.sb.rpc('admin_update_map_npc_spawn_v1811',{p_map_id:mapId,p_npc_key:key,p_spawn_count:count,p_enabled:body.enabled!==false});
  if(error){const msg=String(error.message||'Falha ao salvar população.');const denied=/administrativ|permiss|negado/i.test(msg);return res.status(denied?403:400).json({error:msg});}
  const runtime=await refreshNpcRuntimeSnapshot(true);
  res.set('Cache-Control','no-store');res.json({ok:true,npc_key:key,map_id:mapId,runtime,saved:data||null});
}));


// V18.1.6D — editor isolado do Mundo. Não toca em Missões/Economia/Crafting.
app.post('/api/admin/runtime/world/maps/:mapId', requireUser, asyncRoute(async(req,res)=>{
  const mapId=safeWorldId(req.params?.mapId);const current=await loadWorldRuntimeSnapshot(false);const row=current?.maps?.find(x=>String(x.map_id)===mapId);if(!mapId||!row)return res.status(400).json({error:'Mapa inválido.'});
  const body=req.body&&typeof req.body==='object'?req.body:{};const name=String(body.name||'').trim().slice(0,64),risk=String(body.risk||'').trim().slice(0,32);if(!name||!risk)return res.status(400).json({error:'Nome e risco do mapa são obrigatórios.'});
  const respawnMin=Math.round(clampNum(body.ore_respawn_min_ms,1000,600000,row.ore_respawn_min_ms||5000)),respawnMax=Math.round(clampNum(body.ore_respawn_max_ms,1000,600000,row.ore_respawn_max_ms||12000));if(respawnMax<respawnMin)return res.status(400).json({error:'Respawn máximo deve ser maior ou igual ao mínimo.'});
  // V82: valida estrutura antes de passar JSON para a função ADM.
  let palette=null,structures=null;
  if(body.palette!==undefined){
    const pal=body.palette;
    if(!pal||typeof pal!=='object'||Array.isArray(pal)||!['nebula','accent','deep'].every(k=>/^#[0-9a-f]{6}$/i.test(String(pal[k]||''))))return res.status(400).json({error:'Paleta inválida.'});
    palette={...row.palette,nebula:pal.nebula,accent:pal.accent,deep:pal.deep};
  }
  if(body.structures!==undefined){
    if(!Array.isArray(body.structures)||body.structures.length>40||!body.structures.every(x=>typeof x==='string'&&x.length>0&&x.length<=64))return res.status(400).json({error:'Estruturas inválidas.'});
    structures=body.structures;
  }
  const {data,error}=await req.sb.rpc('admin_update_map_v1814',{p_map_id:mapId,p_name:name,p_risk:risk,p_world_w:Math.round(clampNum(body.world_w,1000,50000,row.world_w||6000)),p_world_h:Math.round(clampNum(body.world_h,1000,50000,row.world_h||4500)),p_enemy_multiplier:clampNum(body.enemy_multiplier,0.1,10,row.enemy_multiplier||1),p_ore_count:Math.round(clampNum(body.ore_count,0,1000,row.ore_count||0)),p_ore_respawn_min_ms:respawnMin,p_ore_respawn_max_ms:respawnMax,p_landmark_count:Math.round(clampNum(body.landmark_count,0,100,row.landmark_count||0)),p_min_level:Math.round(clampNum(body.min_level,1,100,row.min_level||1)),p_enabled:body.enabled!==false,p_palette:palette,p_structures:structures});
  if(error){const msg=String(error.message||'Falha ao salvar mapa.');return res.status(/administrativ|permiss|negado/i.test(msg)?403:400).json({error:msg});}
  const runtime=await refreshWorldRuntimeSnapshot(true);res.set('Cache-Control','no-store');res.json({ok:true,map_id:mapId,runtime,saved:data||null});
}));
app.post('/api/admin/runtime/world/resources/:resourceKey', requireUser, asyncRoute(async(req,res)=>{
  const key=safeWorldId(req.params?.resourceKey);const current=await loadWorldRuntimeSnapshot(false);const row=current?.resources?.find(x=>String(x.resource_key)===key);if(!key||!row)return res.status(400).json({error:'Recurso inválido.'});
  const body=req.body&&typeof req.body==='object'?req.body:{};const name=String(body.name||'').trim().slice(0,48),color=String(body.color||'').trim();if(!name)return res.status(400).json({error:'Informe o nome do recurso.'});if(!/^#[0-9a-f]{6}$/i.test(color))return res.status(400).json({error:'Cor inválida. Use #RRGGBB.'});
  const {data,error}=await req.sb.rpc('admin_update_resource_v1814',{p_resource_key:key,p_name:name,p_color:color,p_sell_price:Math.max(0,Math.round(Number(body.sell_price)||0)),p_enabled:body.enabled!==false});if(error){const msg=String(error.message||'Falha ao salvar recurso.');return res.status(/administrativ|permiss|negado/i.test(msg)?403:400).json({error:msg});}
  const runtime=await refreshWorldRuntimeSnapshot(true);res.set('Cache-Control','no-store');res.json({ok:true,resource_key:key,runtime,saved:data||null});
}));
app.post('/api/admin/runtime/world/sectors/:sectorLabel', requireUser, asyncRoute(async(req,res)=>{
  const key=safeSector(req.params?.sectorLabel);const current=await loadWorldRuntimeSnapshot(false);const row=current?.sectors?.find(x=>String(x.sector_label)===key);if(!key||!row)return res.status(400).json({error:'Setor inválido.'});const body=req.body&&typeof req.body==='object'?req.body:{};
  const {data,error}=await req.sb.rpc('admin_update_sector_v1814',{p_sector_label:key,p_graph_x:clampNum(body.graph_x,0,100,row.graph_x||0),p_graph_y:clampNum(body.graph_y,0,100,row.graph_y||0),p_min_level:Math.round(clampNum(body.min_level,1,100,row.min_level||1)),p_enabled:body.enabled!==false});if(error){const msg=String(error.message||'Falha ao salvar setor.');return res.status(/administrativ|permiss|negado/i.test(msg)?403:400).json({error:msg});}
  const runtime=await refreshWorldRuntimeSnapshot(true);res.set('Cache-Control','no-store');res.json({ok:true,sector_label:key,runtime,saved:data||null});
}));
app.post('/api/admin/runtime/world/portals/:portalKey', requireUser, asyncRoute(async(req,res)=>{
  const key=safeWorldId(req.params?.portalKey);const current=await loadWorldRuntimeSnapshot(false);const row=current?.portals?.find(x=>String(x.portal_key)===key);if(!key||!row)return res.status(400).json({error:'Portal inválido.'});const body=req.body&&typeof req.body==='object'?req.body:{};
  const {data,error}=await req.sb.rpc('admin_update_portal_link_v1814',{p_portal_key:key,p_enabled:body.enabled!==false,p_bidirectional:body.bidirectional!==false,p_sort_order:Math.round(clampNum(body.sort_order,0,9999,row.sort_order||100))});if(error){const msg=String(error.message||'Falha ao salvar portal.');return res.status(/administrativ|permiss|negado/i.test(msg)?403:400).json({error:msg});}
  const runtime=await refreshWorldRuntimeSnapshot(true);res.set('Cache-Control','no-store');res.json({ok:true,portal_key:key,runtime,saved:data||null});
}));
app.post('/api/admin/runtime/world/maps/:mapId/resources/:resourceKey', requireUser, asyncRoute(async(req,res)=>{
  const mapId=safeWorldId(req.params?.mapId),resourceKey=safeWorldId(req.params?.resourceKey);const current=await loadWorldRuntimeSnapshot(false);if(!current?.map_resources?.some(x=>String(x.map_id)===mapId&&String(x.resource_key)===resourceKey))return res.status(400).json({error:'Vínculo mapa/recurso inválido nesta etapa.'});const body=req.body&&typeof req.body==='object'?req.body:{};
  const {data,error}=await req.sb.rpc('admin_update_map_resource_pool_v1816',{p_map_id:mapId,p_resource_key:resourceKey,p_weight:clampNum(body.weight,.01,1000,1),p_enabled:body.enabled!==false});if(error){const msg=String(error.message||'Falha ao salvar pool de minério.');return res.status(/administrativ|permiss|negado/i.test(msg)?403:400).json({error:msg});}
  const runtime=await refreshWorldRuntimeSnapshot(true);res.set('Cache-Control','no-store');res.json({ok:true,map_id:mapId,resource_key:resourceKey,runtime,saved:data||null});
}));

app.get('/api/runtime/world', requireUser, asyncRoute(async (req,res)=>{
  const snapshot=await loadWorldRuntimeSnapshot(Boolean(req.query?.refresh));
  res.set('Cache-Control','no-store');
  res.json(snapshot);
}));


// V18.1.6E — editor isolado de Sistemas. Não toca em Interface/NPCs/Mundo.
app.post('/api/admin/runtime/systems/missions/:category', requireUser, asyncRoute(async(req,res)=>{
  const key=safeWorldId(req.params?.category);const current=await loadSystemsRuntimeSnapshot(false);const row=current?.mission_categories?.find(x=>String(x.category)===key);if(!key||!row)return res.status(400).json({error:'Categoria de missão inválida.'});
  const body=req.body&&typeof req.body==='object'?req.body:{};const config=body.config&&typeof body.config==='object'&&!Array.isArray(body.config)?body.config:null;if(!config)return res.status(400).json({error:'Configuração da missão precisa ser um objeto JSON.'});if(JSON.stringify(config).length>12000)return res.status(400).json({error:'Configuração da missão muito grande.'});
  const {data,error}=await req.sb.rpc('admin_update_mission_category_v1815',{p_category:key,p_min_level:Math.round(clampNum(body.min_level,1,100,row.min_level||1)),p_reward_factor:clampNum(body.reward_factor,0,10,row.reward_factor||0),p_item_chance:clampNum(body.item_chance,0,1,row.item_chance||0),p_enabled:body.enabled!==false,p_config:config});if(error){const msg=String(error.message||'Falha ao salvar missão.');return res.status(/administrativ|permiss|negado/i.test(msg)?403:400).json({error:msg});}
  const runtime=await refreshSystemsRuntimeSnapshot(true);res.set('Cache-Control','no-store');res.json({ok:true,category:key,runtime,saved:data||null});
}));
app.post('/api/admin/runtime/systems/economy/:serviceId', requireUser, asyncRoute(async(req,res)=>{
  const key=safeWorldId(req.params?.serviceId);const current=await loadSystemsRuntimeSnapshot(false);const row=current?.economy_services?.find(x=>String(x.service_id)===key);if(!key||!row)return res.status(400).json({error:'Serviço econômico inválido.'});
  const body=req.body&&typeof req.body==='object'?req.body:{};const effect=body.effect&&typeof body.effect==='object'&&!Array.isArray(body.effect)?body.effect:null;if(!effect)return res.status(400).json({error:'Efeito precisa ser um objeto JSON.'});if(JSON.stringify(effect).length>6000)return res.status(400).json({error:'Efeito muito grande.'});
  const duration=Math.round(clampNum(body.duration_ms,60000,86400000,row.duration_ms||3600000)),maxStack=Math.round(clampNum(body.max_stack_ms,60000,604800000,row.max_stack_ms||21600000));
  const {data,error}=await req.sb.rpc('admin_update_economy_service_v1815',{p_service_id:key,p_base_cost:Math.round(clampNum(body.base_cost,0,1000000000000,row.base_cost||0)),p_duration_ms:duration,p_level_cost_scale:clampNum(body.level_cost_scale,0,10,row.level_cost_scale||0),p_max_stack_ms:maxStack,p_effect:effect,p_enabled:body.enabled!==false});if(error){const msg=String(error.message||'Falha ao salvar serviço econômico.');return res.status(/administrativ|permiss|negado/i.test(msg)?403:400).json({error:msg});}
  const runtime=await refreshSystemsRuntimeSnapshot(true);res.set('Cache-Control','no-store');res.json({ok:true,service_id:key,runtime,saved:data||null});
}));
app.post('/api/admin/runtime/systems/crafting/:recipeId', requireUser, asyncRoute(async(req,res)=>{
  const key=safeWorldId(req.params?.recipeId);const current=await loadSystemsRuntimeSnapshot(false);const row=current?.crafting_recipes?.find(x=>String(x.recipe_id)===key);if(!key||!row)return res.status(400).json({error:'Receita inválida.'});
  const body=req.body&&typeof req.body==='object'?req.body:{},ingredients=body.ingredients&&typeof body.ingredients==='object'&&!Array.isArray(body.ingredients)?body.ingredients:null,grantPayload=body.grant_payload&&typeof body.grant_payload==='object'&&!Array.isArray(body.grant_payload)?body.grant_payload:null;if(!ingredients||!grantPayload)return res.status(400).json({error:'Ingredientes e recompensa precisam ser objetos JSON.'});if(JSON.stringify(ingredients).length>8000||JSON.stringify(grantPayload).length>8000)return res.status(400).json({error:'JSON da receita muito grande.'});
  const currency=String(body.currency||row.currency||'credits')==='uridium'?'uridium':'credits',output=String(body.output_label||'').trim().slice(0,72);if(!output)return res.status(400).json({error:'Informe a saída da receita.'});
  const {data,error}=await req.sb.rpc('admin_update_crafting_recipe_v1815',{p_recipe_id:key,p_cost:Math.round(clampNum(body.cost,0,1000000000000,row.cost||0)),p_currency:currency,p_ingredients:ingredients,p_grant_payload:grantPayload,p_output_label:output,p_min_level:Math.round(clampNum(body.min_level,1,100,row.min_level||1)),p_enabled:body.enabled!==false});if(error){const msg=String(error.message||'Falha ao salvar receita.');return res.status(/administrativ|permiss|negado/i.test(msg)?403:400).json({error:msg});}
  const runtime=await refreshSystemsRuntimeSnapshot(true);res.set('Cache-Control','no-store');res.json({ok:true,recipe_id:key,runtime,saved:data||null});
}));

// V19.0.8 — Criar/editar missões usando a RPC existente com RLS administrativo.
app.post('/api/admin/runtime/systems/custom-missions',requireUser,asyncRoute(async(req,res)=>{
 const b=req.body&&typeof req.body==='object'?req.body:{};
 const id=safeWorldId(b.mission_id),category=String(b.category||'');
 if(!id||!SYSTEM_MISSION_CATEGORIES.has(category))return res.status(400).json({error:'ID ou categoria de missão inválidos.'});
 const title=String(b.title||'').trim().slice(0,100),description=String(b.description||'').trim().slice(0,260);
 const tasks=Array.isArray(b.tasks)?b.tasks.map(sanitizeMissionTask).filter(Boolean):[];
 if(!title||tasks.length<1||tasks.length>8||tasks.length!==b.tasks.length)return res.status(400).json({error:'Informe título e de 1 a 8 objetivos válidos.'});
 const flat=b.flat_reward&&typeof b.flat_reward==='object'&&!Array.isArray(b.flat_reward)?b.flat_reward:{};
 const reward={credits:Math.round(clampNum(flat.credits,0,100000000,0)),uridium:Math.round(clampNum(flat.uridium,0,100000,0)),xp:Math.round(clampNum(flat.xp,0,10000000,0))};
 const {data,error}=await req.sb.rpc('admin_upsert_custom_mission_v1815',{
  p_mission_id:id,p_category:category,p_title:title,p_description:description,p_tasks:tasks,
  p_group_key:String(b.group_key||'mix').slice(0,24),p_sequence:!!b.sequence,
  p_reward_factor:clampNum(b.reward_factor,0,10,1),p_tag:String(b.tag||'').slice(0,64),
  p_flat_reward:reward,p_enabled:b.enabled!==false,p_sort_order:Math.round(clampNum(b.sort_order,0,9999,100))
 });
 if(error)return res.status(/administrativ|permiss|negad/i.test(error.message)?403:400).json({error:error.message});
 const runtime=await refreshSystemsRuntimeSnapshot(true);res.json({ok:true,mission_id:id,runtime});
}));
app.delete('/api/admin/runtime/systems/custom-missions/:missionId',requireUser,asyncRoute(async(req,res)=>{
 const id=safeWorldId(req.params.missionId);if(!id)return res.status(400).json({error:'ID inválido.'});
 const {error}=await req.sb.rpc('admin_delete_custom_mission_v1815',{p_mission_id:id});
 if(error)return res.status(/administrativ|permiss|negad/i.test(error.message)?403:400).json({error:error.message});
 const runtime=await refreshSystemsRuntimeSnapshot(true);res.json({ok:true,mission_id:id,runtime});
}));
// Novos serviços/receitas usam RPCs exclusivamente administrativas (SQL V19.0.8).
app.post('/api/admin/runtime/systems/new/economy',requireUser,asyncRoute(async(req,res)=>{
 const b=req.body||{},id=safeWorldId(b.service_id),effect={};
 if(!id||!String(b.name||'').trim())return res.status(400).json({error:'ID e nome são obrigatórios.'});
 if(!b.effect||typeof b.effect!=='object'||Array.isArray(b.effect))return res.status(400).json({error:'Escolha um efeito válido.'});
 for(const [k,v] of Object.entries(b.effect)){if(!SYSTEM_EFFECT_KEYS.has(k))return res.status(400).json({error:'Efeito não permitido.'});effect[k]=clampNum(v,0,10000,0);}
 if(Object.keys(effect).length!==1)return res.status(400).json({error:'Escolha exatamente um efeito.'});
 const payload={service_id:id,name:String(b.name).trim().slice(0,80),description:String(b.description||'').slice(0,180),base_cost:Math.round(clampNum(b.base_cost,0,1000000000000,0)),duration_ms:Math.round(clampNum(b.duration_ms,60000,86400000,3600000)),max_stack_ms:Math.round(clampNum(b.max_stack_ms,60000,604800000,21600000)),level_cost_scale:clampNum(b.level_cost_scale,0,10,.35),effect,enabled:b.enabled!==false};
 const {error}=await req.sb.rpc('admin_create_economy_service_v1908',{p_content:payload});if(error)return res.status(/administrativ|permiss|negad/i.test(error.message)?403:400).json({error:error.message});
 const runtime=await refreshSystemsRuntimeSnapshot(true);res.json({ok:true,service_id:id,runtime});
}));
app.post('/api/admin/runtime/systems/new/crafting',requireUser,asyncRoute(async(req,res)=>{
 const b=req.body||{},id=safeWorldId(b.recipe_id),ingredients=safeJsonNumberObject(b.ingredients,12,1000000);
 const g=b.grant_payload||{},kind=String(g.kind||''),grant={kind,id:safeWorldId(g.id),qty:Math.round(clampNum(g.qty,1,10000000,1))};
 if(!id||!String(b.name||'').trim()||!Object.keys(ingredients).length||!SYSTEM_GRANT_KINDS.has(kind)||!grant.id)return res.status(400).json({error:'Informe ID, nome, ingredientes e produto válidos.'});
 const payload={recipe_id:id,name:String(b.name).trim().slice(0,80),description:String(b.description||'').slice(0,180),cost:Math.round(clampNum(b.cost,0,1000000000000,0)),currency:b.currency==='uridium'?'uridium':'credits',ingredients,grant_payload:grant,output_label:String(b.output_label||b.name).trim().slice(0,80),min_level:Math.round(clampNum(b.min_level,1,100,1)),enabled:b.enabled!==false};
 const {error}=await req.sb.rpc('admin_create_crafting_recipe_v1908',{p_content:payload});if(error)return res.status(/administrativ|permiss|negad/i.test(error.message)?403:400).json({error:error.message});
 const runtime=await refreshSystemsRuntimeSnapshot(true);res.json({ok:true,recipe_id:id,runtime});
}));
app.get('/api/runtime/systems', requireUser, asyncRoute(async (req,res)=>{
  const snapshot=await loadSystemsRuntimeSnapshot(Boolean(req.query?.refresh));
  res.set('Cache-Control','no-store');
  res.json(snapshot);
}));

app.get('/api/runtime/pass', requireUser, asyncRoute(async (req,res)=>{
  const snapshot=await loadPassRuntimeSnapshot(Boolean(req.query?.refresh));
  res.set('Cache-Control','no-store');res.json(snapshot);
}));
app.post('/api/admin/runtime/pass/seasons/new',requireUser,asyncRoute(async(req,res)=>{
 const b=req.body||{},key=String(b.season_key||'').trim();
 if(!/^[a-z0-9_-]{3,32}$/i.test(key)||!String(b.name||'').trim())return res.status(400).json({error:'ID e nome da temporada inválidos.'});
 const start=new Date(b.starts_at),end=new Date(b.ends_at);
 if(!Number.isFinite(start.getTime())||!Number.isFinite(end.getTime())||end<=start)return res.status(400).json({error:'Datas da temporada inválidas.'});
 const payload={season_key:key,name:String(b.name).trim().slice(0,80),description:String(b.description||'').slice(0,240),starts_at:start.toISOString(),ends_at:end.toISOString(),tier_count:Math.round(clampNum(b.tier_count,1,100,30)),points_per_tier:Math.round(clampNum(b.points_per_tier,1,1000000,500)),daily_points:Math.round(clampNum(b.daily_points,1,100000,100)),premium_price_brl:clampNum(b.premium_price_brl,0,99999,19.9)};
 const {error}=await req.sb.rpc('admin_create_pass_season_v1908',{p_content:payload});if(error)return res.status(/administrativ|permiss|negad/i.test(error.message)?403:400).json({error:error.message});
 const runtime=await refreshPassRuntimeSnapshot(true);res.json({ok:true,season_key:key,runtime});
}));
app.post('/api/admin/runtime/pass/seasons/:seasonKey', requireUser, asyncRoute(async(req,res)=>{
  const key=String(req.params?.seasonKey||'').trim().slice(0,32),current=await loadPassRuntimeSnapshot(false),row=current?.seasons?.find(x=>String(x.season_key)===key);if(!key||!row)return res.status(400).json({error:'Temporada inválida.'});
  const body=req.body&&typeof req.body==='object'?req.body:{},startsAt=body.starts_at?new Date(body.starts_at):null,endsAt=body.ends_at?new Date(body.ends_at):null;if(startsAt&&Number.isNaN(startsAt.getTime()))return res.status(400).json({error:'Início da temporada inválido.'});if(endsAt&&Number.isNaN(endsAt.getTime()))return res.status(400).json({error:'Fim da temporada inválido.'});
  const {data,error}=await req.sb.rpc('admin_update_battle_pass_season_v1817b',{p_season_key:key,p_name:String(body.name||row.name||'').trim().slice(0,80),p_description:String(body.description??row.description??'').trim().slice(0,240),p_starts_at:startsAt?startsAt.toISOString():null,p_ends_at:endsAt?endsAt.toISOString():null,p_tier_count:Math.round(clampNum(body.tier_count,1,100,row.tier_count||30)),p_points_per_tier:Math.round(clampNum(body.points_per_tier,1,1000000,row.points_per_tier||500)),p_daily_points:Math.round(clampNum(body.daily_points,1,100000,row.daily_points||100)),p_premium_price_brl:clampNum(body.premium_price_brl,0,99999,row.premium_price_brl||19.9),p_enabled:body.enabled!==false});if(error){const msg=String(error.message||'Falha ao salvar temporada.');return res.status(/administrativ|permiss|negado/i.test(msg)?403:400).json({error:msg});}
  const runtime=await refreshPassRuntimeSnapshot(true);res.set('Cache-Control','no-store');res.json({ok:true,season_key:key,runtime,saved:data||null});
}));
app.post('/api/admin/runtime/pass/seasons/:seasonKey/tiers/:tierNo', requireUser, asyncRoute(async(req,res)=>{
  const key=String(req.params?.seasonKey||'').trim().slice(0,32),tierNo=Math.round(clampNum(req.params?.tierNo,1,100,0)),current=await loadPassRuntimeSnapshot(false),season=current?.seasons?.find(x=>String(x.season_key)===key);if(!key||!tierNo||!season||tierNo>Number(season.tier_count||100))return res.status(400).json({error:'Tier inválido.'});
  const body=req.body&&typeof req.body==='object'?req.body:{};if(!body.free_reward||typeof body.free_reward!=='object'||Array.isArray(body.free_reward))return res.status(400).json({error:'Recompensa Free precisa ser um objeto JSON.'});if(!body.premium_reward||typeof body.premium_reward!=='object'||Array.isArray(body.premium_reward))return res.status(400).json({error:'Recompensa Premium precisa ser um objeto JSON.'});
  const {data,error}=await req.sb.rpc('admin_update_battle_pass_tier_v1817b',{p_season_key:key,p_tier_no:tierNo,p_free_reward:sanitizePassReward(body.free_reward),p_premium_reward:sanitizePassReward(body.premium_reward),p_enabled:body.enabled!==false});if(error){const msg=String(error.message||'Falha ao salvar tier.');return res.status(/administrativ|permiss|negado/i.test(msg)?403:400).json({error:msg});}
  const runtime=await refreshPassRuntimeSnapshot(true);res.set('Cache-Control','no-store');res.json({ok:true,season_key:key,tier_no:tierNo,runtime,saved:data||null});
}));

// V18.1.7C — Lojas Comum + Premium Data Driven
app.get('/api/runtime/shops', requireUser, asyncRoute(async(req,res)=>{
  const snapshot=await loadShopsRuntimeSnapshot(Boolean(req.query?.refresh));
  res.set('Cache-Control','no-store');res.json(snapshot);
}));
app.post('/api/admin/runtime/shops/common/:catalogKey', requireUser, asyncRoute(async(req,res)=>{
  const key=String(req.params?.catalogKey||'').trim().slice(0,120),current=await loadShopsRuntimeSnapshot(false),row=current?.common?.find(x=>String(x.catalog_key)===key);if(!key||!row)return res.status(400).json({error:'Produto da Loja Comum inválido.'});
  const body=req.body&&typeof req.body==='object'?req.body:{},currency=String(body.currency||row.currency||'credits')==='uridium'?'uridium':'credits',tab=COMMON_SHOP_TABS.has(String(body.shop_tab||''))?String(body.shop_tab):String(row.shop_tab||'');if(!COMMON_SHOP_TABS.has(tab))return res.status(400).json({error:'Aba da Loja inválida.'});
  const {data,error}=await req.sb.rpc('admin_update_common_shop_item_v1817c',{
    p_catalog_key:key,p_display_name:String(body.display_name??row.display_name??'').trim().slice(0,100),p_description:String(body.description??row.description??'').trim().slice(0,300),
    p_price:Math.round(clampNum(body.price,0,1000000000000,row.price||0)),p_currency:currency,p_quantity:Math.round(clampNum(body.quantity,1,10000000,row?.meta?.grant?.qty||1)),
    p_min_level:Math.round(clampNum(body.min_level,1,100,row.min_level||1)),p_sort_order:Math.round(clampNum(body.sort_order,0,9999,row.sort_order||100)),p_shop_tab:tab,
    p_shop_visible:body.shop_visible!==false,p_enabled:body.enabled!==false
  });
  if(error){const msg=String(error.message||'Falha ao salvar produto da Loja Comum.');return res.status(/administrativ|permiss|negado/i.test(msg)?403:400).json({error:msg});}
  if(row.kind==='drone'&&body.drone_price_multiplier!=null){
    const {error:multError}=await req.sb.rpc('admin_update_drone_multiplier_v1829',{p_type:String(row.ref_id),p_multiplier:clampNum(body.drone_price_multiplier,1,4,2)});
    if(multError)return res.status(/administrativ|permiss|negado/i.test(multError.message)?403:400).json({error:multError.message});
  }
  const runtime=await refreshShopsRuntimeSnapshot(true);await loadLiveOpsSnapshot(true).catch(()=>null);res.set('Cache-Control','no-store');res.json({ok:true,catalog_key:key,runtime,saved:data||null});
}));
app.post('/api/admin/runtime/shops/premium/:productId', requireUser, asyncRoute(async(req,res)=>{
  const key=String(req.params?.productId||'').trim().slice(0,80),current=await loadShopsRuntimeSnapshot(false),row=current?.premium?.find(x=>String(x.id)===key);if(!key||!row)return res.status(400).json({error:'Produto Premium inválido.'});
  const body=req.body&&typeof req.body==='object'?req.body:{};
  const {data,error}=await req.sb.rpc('admin_update_premium_shop_item_v1817c',{
    p_product_id:key,p_name:String(body.name??row.name??'').trim().slice(0,100),p_description:String(body.description??row.description??'').trim().slice(0,300),
    p_price_brl:row.category==='battle_pass'?null:clampNum(body.price_brl,0,99999,row.price_brl||0),p_quantity:Math.round(clampNum(body.quantity,1,10000000,row.quantity||1)),
    p_min_level:Math.round(clampNum(body.min_level,1,100,row.min_level||1)),p_sort_order:Math.round(clampNum(body.sort_order,0,9999,row.sort_order||100)),p_active:body.active!==false,
    p_days:row.category==='premium'?Math.round(clampNum(body.days,1,3650,row?.meta?.days||30)):null
  });
  if(error){const msg=String(error.message||'Falha ao salvar produto Premium.');return res.status(/administrativ|permiss|negado/i.test(msg)?403:400).json({error:msg});}
  const runtime=await refreshShopsRuntimeSnapshot(true);res.set('Cache-Control','no-store');res.json({ok:true,product_id:key,runtime,saved:data||null});
}));


// V19.0.8 • Leilão: valores fixados pelo banco e editáveis exclusivamente por ADM.
// V111 • preços de protocolos e slots AUX: somente ADM; leitura pública usa LIVE OPS cache.
app.get('/api/admin/runtime/aux-economy',requireUser,asyncRoute(async(req,res)=>{
  const {data:isAdmin,error:adminError}=await req.sb.rpc('is_game_admin_v1763',{p_uid:req.user.id});
  if(adminError||isAdmin!==true)return res.status(403).json({error:'Somente ADM.'});
  const {data,error}=await (await requireEliteAdmin()).from('live_shop_prices_v16')
    .select('catalog_key,kind,ref_id,price,currency,enabled,shop_visible,meta')
    .in('kind',['pet_slot','aux_protocol']).order('catalog_key');
  if(error)throw new Error(error.message);
  // Taxas de fragmento para APEX e UNIVERSO, restritas ao painel ADM.
  const {data:dropRules,error:dropError}=await (await requireEliteAdmin()).from('stellar_aux_protocol_drop_rules_v1131')
    .select('source,chance,enabled').order('source');
  if(dropError)throw new Error(dropError.message);
  res.set('Cache-Control','no-store');res.json({items:data||[],drop_rules:dropRules||[]});
}));
app.post('/api/admin/runtime/aux-economy',requireUser,asyncRoute(async(req,res)=>{
  const {data:isAdmin,error:adminError}=await req.sb.rpc('is_game_admin_v1763',{p_uid:req.user.id});
  if(adminError||isAdmin!==true)return res.status(403).json({error:'Somente ADM.'});
  const body=req.body||{},key=String(body.catalog_key||'');
  // Fragmentos (chance 0–25%) editáveis sem permitir conceder itens manualmente.
  if(!key&&['apex','universo'].includes(String(body.drop_source||''))){
    const chance=Number(body.chance);
    if(!Number.isFinite(chance)||chance<0||chance>0.25)return res.status(400).json({error:'Chance deve estar entre 0% e 25%.'});
    const source=String(body.drop_source);
    const {error}=await (await requireEliteAdmin()).from('stellar_aux_protocol_drop_rules_v1131')
      .update({chance:Math.round(chance*10000)/10000,enabled:body.enabled===true,updated_at:new Date().toISOString()})
      .eq('source',source);
    if(error)throw new Error(error.message);
    res.set('Cache-Control','no-store');return res.json({ok:true,drop_source:source,chance});
  }
  const validProtocol=/^aux_protocol:(dano|hp|escudo|loot|porao)$/.test(key);
  const validSlot=/^pet_slot:(?:[2-9]|1[0-9]|2[0-2])$/.test(key);
  if(!validProtocol&&!validSlot)return res.status(400).json({error:'Preço de AUX inválido.'});
  const price=Number(body.price);
  if(!Number.isSafeInteger(price)||price>1000000000000)return res.status(400).json({error:'Preço inválido.'});
  const id=key.split(':')[1],elite=['dano','hp','escudo'].includes(id);
  const floor=validSlot?1000:(elite?50000:100000000);
  if(price<floor)return res.status(400).json({error:`Preço mínimo: ${floor}.`});
  const sb=await requireEliteAdmin();
  const {data:row,error:readError}=await sb.from('live_shop_prices_v16').select('catalog_key,kind,ref_id,currency,meta').eq('catalog_key',key).maybeSingle();
  if(readError)throw new Error(readError.message);
  if(!row||row.kind!==(validSlot?'pet_slot':'aux_protocol')||row.ref_id!==id)return res.status(404).json({error:'Catálogo AUX ausente.'});
  const expectedCurrency=validSlot||elite?'uridium':'credits';
  if(row.currency!==expectedCurrency)return res.status(409).json({error:'Moeda de catálogo inválida. Não foi alterada.'});
  const updates={price,updated_at:new Date().toISOString()};
  if(validProtocol){
    const factor=Number(body.auction_factor);
    if(!Number.isFinite(factor)||factor<(elite?0.1:1)||factor>2)return res.status(400).json({error:elite?'Fator do leilão deve ser 0,1 a 2.':'BOX e PORÃO exigem fator de leilão 1 a 2 (piso de 100 milhões CR).'});
    updates.enabled=body.enabled!==false;updates.shop_visible=body.shop_visible!==false;
    const recipeValues=[['craft_n2_stl',250000],['craft_n3_stl',500000],['craft_n3_credits',180000000]];
    const recipes={};
    for(const [field,min] of recipeValues){
      const value=Number(body[field]??row.meta?.[field]??min);
      if(!Number.isSafeInteger(value)||value<min||value>1000000000000)
        return res.status(400).json({error:`Custo ${field} inválido (mínimo ${min}).`});
      recipes[field]=value;
    }
    updates.meta={...(row.meta||{}),...recipes,auction_enabled:body.auction_enabled===true,auction_factor:Math.round(factor*100)/100};
  }
  const {error}=await sb.from('live_shop_prices_v16').update(updates).eq('catalog_key',key);
  if(error)throw new Error(error.message);
  await loadLiveOpsSnapshot(true);
  res.set('Cache-Control','no-store');res.json({ok:true,catalog_key:key,price});
}));
app.get('/api/runtime/auction-rules',requireUser,asyncRoute(async(req,res)=>{
 const {data,error}=await req.sb.rpc('get_auction_rules_v1908');
 if(error)return res.status(503).json({error:'Regras do leilão indisponíveis; execute SQL V19.0.8.'});
 res.set('Cache-Control','no-store');res.json(data);
}));
app.post('/api/admin/runtime/auction-rules',requireUser,asyncRoute(async(req,res)=>{
 const b=req.body||{},nova_floor=Number(b.nova_floor),common_floor=Number(b.common_floor),stl_to_credits=Number(b.stl_to_credits);
 if(!Number.isInteger(nova_floor)||nova_floor<100000000||nova_floor>1000000000||nova_floor%100000!==0||!Number.isInteger(common_floor)||common_floor<100000||common_floor>10000000||common_floor%100000!==0||!Number.isInteger(stl_to_credits)||stl_to_credits<100||stl_to_credits>100000||!b.category_multipliers||typeof b.category_multipliers!=='object'||Array.isArray(b.category_multipliers)||!b.item_multipliers||typeof b.item_multipliers!=='object'||Array.isArray(b.item_multipliers))return res.status(400).json({error:'Conversão, pisos ou multiplicadores inválidos.'});
 const cats=['ammo','rocket','ship','laser','generator','drone','extra','petGear'];
 if(Object.keys(b.category_multipliers).length!==cats.length||!cats.every(k=>Number.isFinite(Number(b.category_multipliers[k]))&&Number(b.category_multipliers[k])>=.01&&Number(b.category_multipliers[k])<=15)||Object.keys(b.item_multipliers).length>200||!Object.entries(b.item_multipliers).every(([k,v])=>/^(ammo|rocket|ship|item|petGear):[a-zA-Z0-9_]+$/.test(k)&&Number.isFinite(Number(v))&&Number(v)>=.01&&Number(v)<=15))return res.status(400).json({error:'Multiplicadores fora do limite.'});
 const {data,error}=await req.sb.rpc('admin_update_auction_rules_v1916',{p_payload:{...b,version:Math.round(Number(b.version)||0)}});
 if(error)return res.status(/administra|permiss|negad/i.test(error.message)?403:400).json({error:error.message});
 res.set('Cache-Control','no-store');res.json(data);
}));

app.get('/api/diagnostics', asyncRoute(async (req, res) => {
  const base = configStatus();
  if (!SUPABASE_URL || !SUPABASE_KEY) {
    return res.status(503).json({ ok: false, ...base, error: 'Variáveis do Supabase ausentes no Render.' });
  }
  let parsed;
  try {
    parsed = new URL(SUPABASE_URL);
  } catch {
    return res.status(503).json({ ok: false, ...base, error: 'SUPABASE_URL inválida.' });
  }
  if (!parsed.hostname.endsWith('.supabase.co')) {
    return res.status(503).json({ ok: false, ...base, error: 'SUPABASE_URL não parece ser uma Project URL válida.' });
  }

  const response = await fetch(`${SUPABASE_URL}/auth/v1/settings`, {
    headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` },
    signal: AbortSignal.timeout(10000),
  });
  const text = await response.text();
  return res.status(response.ok ? 200 : 502).json({
    ok: response.ok,
    ...base,
    supabaseStatus: response.status,
    message: response.ok ? 'Render conseguiu falar com o Supabase.' : `Supabase respondeu HTTP ${response.status}.`,
    detail: response.ok ? undefined : text.slice(0, 240),
  });
}));

app.post('/api/auth/signup', asyncRoute(async (req, res) => {
  const { email, password, callsign } = req.body || {};
  if (!email || !password || !callsign) return res.status(400).json({ error: 'Informe callsign, e-mail e senha.' });
  const preferredCallsign = normalizeCallsign(callsign);
  if (preferredCallsign.length < 3) return res.status(400).json({ error: 'O callsign precisa ter pelo menos 3 caracteres.' });
  if (password.length < 6) return res.status(400).json({ error: 'A senha precisa ter pelo menos 6 caracteres.' });
  const sb = supabaseBase();
  if (!sb) return res.status(503).json({ error: 'Supabase não configurado no Render.', diagnostics: configStatus() });
  const available = await callsignAvailable(sb, preferredCallsign);
  if (available === false) return res.status(409).json({ error: 'Esse nome de piloto já está em uso. Escolha outro.', code: 'CALLSIGN_TAKEN' });

  const { data, error } = await sb.auth.signUp({
    email: String(email).trim().toLowerCase(),
    password,
    options: { data: { callsign: preferredCallsign } },
  });
  if (error) return res.status(400).json({ error: error.message });

  let gameSession = null;
  if (data.session && data.user) {
    const authed = supabaseForToken(data.session.access_token);
    const securedCallsign = await ensureProfile(authed, data.user, preferredCallsign);
    data.user.user_metadata = { ...(data.user.user_metadata || {}), callsign: securedCallsign };
    gameSession = await registerGameSession(authed, req);
  }

  res.json({
    user: data.user ? { id: data.user.id, email: data.user.email, callsign: data.user.user_metadata?.callsign || preferredCallsign } : null,
    session: data.session ? {
      access_token: data.session.access_token,
      refresh_token: data.session.refresh_token,
      expires_at: data.session.expires_at,
      game_session_id: gameSession?.sessionId || null,
    } : null,
    requires_confirmation: !data.session,
  });
}));

app.post('/api/auth/login', asyncRoute(async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Informe e-mail e senha.' });
  const sb = supabaseBase();
  if (!sb) return res.status(503).json({ error: 'Supabase não configurado no Render.', diagnostics: configStatus() });
  const { data, error } = await sb.auth.signInWithPassword({ email: String(email).trim().toLowerCase(), password });
  if (error || !data.session) return res.status(401).json({ error: error?.message || 'Login inválido.' });
  const authed = supabaseForToken(data.session.access_token);
  const access=await accountAccessState(authed);
  if(access?.is_banned||access?.allowed===false)return bannedResponse(res,access);
  const securedUser = await accountUser(authed, data.user);
  const gameSession = await registerGameSession(authed, req);
  res.json({
    user: securedUser,
    session: {
      access_token: data.session.access_token,
      refresh_token: data.session.refresh_token,
      expires_at: data.session.expires_at,
      game_session_id: gameSession.sessionId,
    },
    replaced_previous: gameSession.replacedPrevious,
  });
}));

// V18.2.16 — OAuth Google: valida o token emitido pelo Supabase antes de
// registrar a mesma sessão única usada no login com senha. Não altera game_saves.
app.post('/api/auth/google/session', asyncRoute(async (req, res) => {
  const token = bearer(req);
  if (!token) return res.status(401).json({ error: 'Token de autenticação ausente.' });
  const sb = supabaseBase();
  if (!sb) return res.status(503).json({ error: 'Supabase não configurado no servidor.' });
  const { data, error } = await sb.auth.getUser(token);
  if (error || !data?.user?.id) return res.status(401).json({ error: 'Sessão Google inválida ou expirada.' });
  const providers = data.user.app_metadata?.providers || [];
  if (!Array.isArray(providers) || !providers.includes('google')) {
    return res.status(403).json({ error: 'Esta sessão não possui uma identidade Google vinculada.' });
  }
  const authed = supabaseForToken(token);
  const access = await accountAccessState(authed);
  if (access?.is_banned || access?.allowed === false) return bannedResponse(res, access);
  const securedUser = await accountUser(authed, data.user);
  const gameSession = await registerGameSession(authed, req);
  res.set('Cache-Control', 'no-store');
  res.json({ user: securedUser, game_session_id: gameSession.sessionId, replaced_previous: gameSession.replacedPrevious });
}));

app.post('/api/auth/refresh', asyncRoute(async (req, res) => {
  const { refresh_token, game_session_id } = req.body || {};
  if (!refresh_token) return res.status(400).json({ error: 'Refresh token ausente.' });
  if (!game_session_id) return res.status(401).json({ error: 'Faça login novamente para ativar a proteção de sessão única.', code: 'SESSION_REQUIRED' });
  const sb = supabaseBase();
  if (!sb) return res.status(503).json({ error: 'Supabase não configurado.', diagnostics: configStatus() });
  const { data, error } = await sb.auth.refreshSession({ refresh_token });
  if (error || !data.session) return res.status(401).json({ error: error?.message || 'Não foi possível renovar a sessão.' });
  const authed = supabaseForToken(data.session.access_token);
  const access=await accountAccessState(authed);
  if(access?.is_banned||access?.allowed===false)return bannedResponse(res,access);
  const { data: sessionState, error: sessionError } = await authed.rpc('validate_game_session_v1214', {
    p_session_id: String(game_session_id),
    p_touch: true,
  });
  if (sessionError) return res.status(503).json({ error: `Falha ao validar sessão do jogo: ${sessionError.message}` });
  if (!sessionState?.valid) return res.status(409).json({ error: 'Sua conta foi acessada em outro dispositivo.', code: 'SESSION_REPLACED' });
  const securedUser = await accountUser(authed, data.user);
  res.json({
    user: securedUser,
    session: {
      access_token: data.session.access_token,
      refresh_token: data.session.refresh_token,
      expires_at: data.session.expires_at,
      game_session_id: String(game_session_id),
    },
  });
}));

app.get('/api/auth/session-status', requireUser, asyncRoute(async (req, res) => {
  res.json({ ok: true, active: true, game_session_id: req.gameSessionId });
}));

app.post('/api/auth/logout', requireUser, asyncRoute(async (req, res) => {
  const { data, error } = await req.sb.rpc('clear_game_session_v1214', { p_session_id: req.gameSessionId });
  if (error) return res.status(400).json({ error: error.message });
  res.json(data || { ok: true });
}));

app.get('/api/auth/me', requireUser, asyncRoute(async (req, res) => {
  const user = await accountUser(req.sb, req.user);
  res.json({ user });
}));

app.put('/api/account/callsign', requireUser, asyncRoute(async (req, res) => {
  const preferred = normalizeCallsign(req.body?.callsign);
  if (preferred.length < 3) return res.status(400).json({ error: 'O nome precisa ter pelo menos 3 caracteres.' });
  const available = await callsignAvailable(req.sb, preferred, req.user.id);
  if (available === false) return res.status(409).json({ error: 'Esse nome de piloto já está em uso. Escolha outro.', code: 'CALLSIGN_TAKEN' });

  const { error: profileError } = await req.sb.from('profiles').update({
    callsign: preferred,
    updated_at: new Date().toISOString(),
  }).eq('id', req.user.id);
  if (profileError) {
    if (String(profileError.code) === '23505' || /callsign|duplicate|unique/i.test(String(profileError.message || ''))) {
      return res.status(409).json({ error: 'Esse nome de piloto já está em uso. Escolha outro.', code: 'CALLSIGN_TAKEN' });
    }
    return res.status(400).json({ error: profileError.message });
  }

  // Mantém o metadata sincronizado, mas o perfil é a fonte de verdade da identidade pública.
  const { error: authError } = await req.sb.auth.updateUser({ data: { callsign: preferred } });
  if (authError) console.warn('callsign auth metadata:', authError.message);
  res.json({ user: { id: req.user.id, email: req.user.email, callsign: preferred } });
}));

app.get('/api/live-ops', requireUser, asyncRoute(async (req,res)=>{
  const data=await loadLiveOpsSnapshot(Boolean(req.query?.refresh));
  res.json(data);
}));


// V18.1.7A — calendário de eventos administrável. Não altera Passe/Lojas nesta etapa.
app.post('/api/admin/runtime/events/:eventKey', requireUser, asyncRoute(async(req,res)=>{
  const key=safeWorldId(req.params?.eventKey),current=await loadLiveOpsSnapshot(false),row=current?.events?.find(x=>String(x.event_key)===key);
  if(!key||!row)return res.status(400).json({error:'Evento inválido.'});
  const body=req.body&&typeof req.body==='object'?req.body:{},mode=['interval','weekly','once'].includes(String(body.schedule_mode))?String(body.schedule_mode):String(row.schedule_mode||'interval');
  if(row.rules?.weekend_rotation===true&&(mode!=='interval'||Number(body.duration_minutes)!==120))return res.status(409).json({error:'Agenda WEEKEND: a duração fixa de 120 min e a rotação são gerenciadas pelo calendário galáctico. É possível ativar/desativar este evento.'});
  const weekdays=[...new Set((Array.isArray(body.weekdays)?body.weekdays:[]).map(Number).filter(n=>Number.isInteger(n)&&n>=0&&n<=6))].sort((a,b)=>a-b);
  const localTime=String(body.start_local_time||'').trim();
  if(mode==='weekly'&&(!weekdays.length||!/^([01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/.test(localTime)))return res.status(400).json({error:'Agenda semanal precisa de pelo menos um dia e horário HH:MM.'});
  const parseIso=(value)=>{if(value==null||value==='')return null;const d=new Date(value);return Number.isNaN(d.getTime())?null:d.toISOString();};
  const startsAt=parseIso(body.starts_at)||row.starts_at||null,endsAt=parseIso(body.ends_at),clearEnds=body.ends_at===''||body.clear_ends_at===true;
  if((mode==='interval'||mode==='once')&&!startsAt)return res.status(400).json({error:'Informe a data/hora inicial do evento.'});
  const {data,error}=await req.sb.rpc('admin_update_live_event_schedule_v1817a',{
    p_event_key:key,p_enabled:body.enabled!==false,p_schedule_mode:mode,p_starts_at:startsAt,
    p_duration_minutes:Math.round(clampNum(body.duration_minutes,1,10080,row.duration_minutes||15)),
    p_repeat_minutes:Math.round(clampNum(body.repeat_minutes,1,10080,row.repeat_minutes||75)),
    p_weekdays:mode==='weekly'?weekdays:(Array.isArray(row.weekdays)?row.weekdays:[]),
    p_start_local_time:mode==='weekly'?localTime:(row.start_local_time||null),p_ends_at:endsAt,p_clear_ends_at:clearEnds
  });
  if(error){const msg=String(error.message||'Falha ao salvar agenda do evento.');return res.status(/administrativ|permiss|negado/i.test(msg)?403:400).json({error:msg});}
  const runtime=await loadLiveOpsSnapshot(true);try{await sharedUniverse.refreshLiveOps(true);}catch{}
  res.set('Cache-Control','no-store');res.json({ok:true,event_key:key,runtime,saved:data||null});
}));

// V34.5.0 — controle total dos eventos: somente RPCs com checagem de ADM no banco.
async function saveEventCenter(req,res,procedure,args){
  const {data,error}=await req.sb.rpc(procedure,args);
  if(error){const message=String(error.message||'Falha ao salvar eventos.');return res.status(/administrativ|negado|permiss/i.test(message)?403:400).json({error:message});}
  const runtime=await loadLiveOpsSnapshot(true);
  try{await sharedUniverse.refreshLiveOps(true);}catch{}
  res.set('Cache-Control','no-store');return res.json({ok:true,runtime,saved:data||null});
}
app.post('/api/admin/runtime/events/central/settings',requireUser,asyncRoute(async(req,res)=>{
  const raw=req.body||{};
  if(typeof raw.enabled!=='boolean'||!Array.isArray(raw.slots))return res.status(400).json({error:'Agenda inválida.'});
  return saveEventCenter(req,res,'admin_set_weekend_settings_v3411',{p_enabled:raw.enabled,p_slots:raw.slots});
}));
app.post('/api/admin/runtime/events/central/event/:eventKey',requireUser,asyncRoute(async(req,res)=>{
  const key=safeWorldId(req.params.eventKey),body=req.body||{};
  if(!key||typeof body.enabled!=='boolean')return res.status(400).json({error:'Evento inválido.'});
  return saveEventCenter(req,res,'admin_set_weekend_event_v3411',{
    p_event_key:key,p_enabled:body.enabled,p_priority:body.priority,
    p_target:body.target,p_reward:body.reward,p_controls:body.controls||{}
  });
}));
app.post('/api/admin/runtime/events/central/manual',requireUser,asyncRoute(async(req,res)=>{
  const body=req.body||{},stop=body.stop===true;
  if(!stop&&!safeWorldId(body.event_key))return res.status(400).json({error:'Evento inválido.'});
  return saveEventCenter(req,res,'admin_set_manual_event_v3411',{
    p_event_key:stop?null:safeWorldId(body.event_key),p_duration_minutes:stop?null:body.duration_minutes,p_stop:stop
  });
}));

// V18.2.1 — cupons cadastrados exclusivamente no Supabase.
// A autenticação do jogo é obrigatória e os prêmios são transacionados pelo PostgreSQL.
app.post('/api/player/coupons/redeem', requireUser, asyncRoute(async (req,res)=>{
  const code=String(req.body?.code||'').trim().toUpperCase();
  if(code==='NATALESTELAR'){const result=await natalServiceV132.action(req.user.id,'coupon:NATALESTELAR','coupon');return res.json({...result,handled:true,message:'Natal Estelar resgatado'});}
  if(!/^[A-Z0-9][A-Z0-9_-]{3,63}$/.test(code))return res.status(400).json({error:'Formato de cupom inválido.'});
  const result=await withPurchaseLock(req.user.id,async()=>{
    const {data,error}=await req.sb.rpc('stellar_player_redeem_game_coupon',{p_code:code});
    if(error)throw Object.assign(new Error(String(error.message||'Cupom recusado pelo servidor.')),{status:409,code:error.code});
    return data;
  });
  res.set('Cache-Control','no-store');
  return res.json(result);
}));

app.post('/api/player/purchase', requireUser, asyncRoute(async (req,res)=>{
  const tamper=invalidShopArguments(req.body,['catalog_key','request_id']);
  if(tamper){const result=await securityService.report(req.user.id,tamper,'live_purchase');if(result?.auto_suspended)return res.status(403).json({error:'Conta temporariamente suspensa por violação de integridade.',code:'ACCOUNT_BANNED'});return res.status(400).json({error:'Parâmetros de compra inválidos.',code:tamper.code});}
  const catalogKey=String(req.body?.catalog_key||'').trim().slice(0,120);
  if(!catalogKey)return res.status(400).json({error:'Produto inválido.'});
  const requestId=req.body?.request_id==null?randomUUID():String(req.body.request_id);
  if(requestId!==null&&!validPurchaseIdV123(requestId))
    return res.status(400).json({error:'Identificador de compra inválido.',code:'PURCHASE_ID_INVALID'});
  const result=await withPurchaseLock(req.user.id,async()=>{
    const earlyDb=await requireEliteAdmin();
    const oldReceipt=await earlyDb.from('stellar_live_purchase_receipts_v123').select('catalog_key,receipt').eq('user_id',req.user.id).eq('request_id',requestId).maybeSingle();
    if(oldReceipt.error)throw Object.assign(Error('Recibo indisponível'),{status:503});
    if(oldReceipt.data){
      if(oldReceipt.data.catalog_key!==catalogKey)throw Object.assign(Error('Identificador reutilizado'),{status:409,code:'COMMAND_ID_REUSED'});
      const readback=await readSaveForWrite(req);if(readback.error)throw Object.assign(Error('Recuperação indisponível'),{status:503});
      return {state:readback.data.state,save_token:readback.data.save_token,updated_at:readback.data.updated_at,purchase:oldReceipt.data.receipt,replayed:true};
    }
    const snapshot=await loadLiveOpsSnapshot(true);
    const row=liveCatalogRow(snapshot,catalogKey);
    if(!row||row.shop_visible===false)throw Object.assign(new Error('Produto indisponível na Loja.'),{status:404});
    if(row.kind==='aux_protocol')throw Object.assign(new Error('Protocolos AUX são comprados exclusivamente pela economia de protocolos validada pelo servidor.'),{status:409});
    const service=requestId?await requireEliteAdmin():null;
    // Fetch both concurrently: no extra sequential SQL round trip for purchases.
    const [saveRead,receiptRead]=await Promise.all([
      readSaveForWrite(req),
      requestId?service.from('stellar_live_purchase_receipts_v123').select('catalog_key,receipt').eq('user_id',req.user.id).eq('request_id',requestId).maybeSingle():Promise.resolve({data:null,error:null})
    ]);
    const {data:saveRow,error:saveError}=saveRead;
    if(saveError)throw new Error(saveError.message);
    if(receiptRead.error)throw Object.assign(new Error('Recibos de compras indisponíveis. Aplique a migração V123.'),{status:503});
    if(!saveRow?.state)throw Object.assign(new Error('Save online ainda não foi criado.'),{status:409});
    if(receiptRead.data){
      if(receiptRead.data.catalog_key!==catalogKey)throw Object.assign(new Error('Identificador reutilizado para outro item.'),{status:409,code:'PURCHASE_ID_REUSED'});
      return {state:saveRow.state,updated_at:saveRow.updated_at,purchase:receiptRead.data.receipt,replayed:true};
    }
    const playerLevel=Math.max(1,Math.floor(Number(saveRow.state?.profile?.level)||1));
    const minLevel=Math.max(1,Math.floor(Number(row.min_level)||1));
    if(playerLevel<minLevel)throw Object.assign(new Error(`Requer nível ${minLevel}.`),{status:409});
    const state=structuredClone(saveRow.state);
    if(String(state.accountOwnerId||req.user.id)!==req.user.id)throw Object.assign(new Error('SAVE BLOQUEADO: proprietário inválido.'),{status:409});
    state.profile ||= {};
    const {data:premiumState}=await req.sb.rpc('get_premium_shop_v12');
    const premium=!!premiumState?.premium_active;
    // V18.2.9: cada tipo de drone dobra de preço a cada aquisição efetiva.
    // O histórico não recua ao vender um drone; evita recomprar 1ª unidade indefinidamente.
    const listedBase=Math.max(0,Math.round(Number(row.price)||0));
    let droneTier=0;
    if(row.kind==='drone'){
      const type=String(row.ref_id||'');
      state.dronePurchasesV1829 ||= {};
      const owned=(Array.isArray(state.drones)?state.drones:[]).filter(d=>d.type===type).length;
      droneTier=Math.max(owned,Math.max(0,Math.floor(Number(state.dronePurchasesV1829[type])||0)));
      state.dronePurchasesV1829[type]=droneTier;
    }
    const droneMultiplier=row.kind==='drone'?Math.max(1,Math.min(4,Number(row?.meta?.drone_price_multiplier)||2)):1;
    const basePrice=row.kind==='drone'?Math.round(listedBase*Math.pow(droneMultiplier,Math.min(droneTier,12))):listedBase;
    if(!Number.isSafeInteger(basePrice)||basePrice<=0)throw Object.assign(new Error('Preço de drone fora do limite seguro.'),{status:409});
    const price=premium&&premiumDiscountEligible(row)?Math.max(1,Math.floor(basePrice*.95)):basePrice;
    const currency=String(row.currency||'credits')==='uridium'?'uridium':'credits';
    const balance=Math.max(0,Number(state.profile[currency])||0);
    if(balance<price)throw Object.assign(new Error(`Saldo insuficiente para ${catalogKey}.`),{status:409});
    applyLiveGrant(state,row);
    if(row.kind==='drone')state.dronePurchasesV1829[String(row.ref_id||'')]=droneTier+1;
    state.profile[currency]=balance-price;
    // Uma compra confirmada so pode ser sobreposta por um save com a mesma revisao.
    state.serverPurchaseRevision=Math.max(0,Math.floor(Number(state.serverPurchaseRevision)||0))+1;
    // Não avance clientSavedAt em mutações econômicas: esse timestamp pertence ao snapshot do cliente.
    state.accountOwnerId=req.user.id;state.accountOwnerEmail=req.user.email||null;
    const updated_at=new Date().toISOString();
    const purchase={catalog_key:catalogKey,base_price:basePrice,price,currency,drone_tier:row.kind==='drone'?droneTier+1:null,premium_discount:price<basePrice};
    if(requestId){
      // Atomic DB commit: compare current save timestamp, debit, grant and receipt
      // under the same SQL transaction. Old clients keep the V118 compatibility path.
      const response=await service.rpc('stellar_player_commit',{p_user_id:req.user.id,p_command_id:requestId,p_module:'purchase',p_request_hash:operationDigestV125('purchase',{catalogKey}),p_payload:{base:saveRow.state,state,receipt:purchase,catalog_key:catalogKey}});
      const confirmed=interpretPurchaseCommitV123(response.data,response.error);
      if(!confirmed.ok)throw Object.assign(new Error(confirmed.message),{status:confirmed.code==='ECONOMY_STALE'?409:503,code:confirmed.code});
      return {state:confirmed.state,save_token:response.data?.save_token,updated_at:confirmed.updatedAt,purchase:confirmed.receipt,replayed:confirmed.replayed};
    }
    req.saveTokenV131=saveRow.save_token;
    const writeError=await writeVerifiedSave(req,state,updated_at);
    if(writeError)throw new Error(writeError.message);
    return {state,updated_at,purchase};
  });
  res.json({ok:true,...result});
}));



const BASE_SERVICES_V1783={
  weapon:{name:'Calibração de Armamento',description:'+3% dano laser por 60 minutos.',base_cost:1500000,duration_ms:3600000,level_band_size:5,level_cost_scale:.35,max_stack_ms:21600000,effect:{laser_damage_pct:3},enabled:true},
  shield:{name:'Harmonização de Escudo',description:'+5% escudo máximo por 60 minutos.',base_cost:1000000,duration_ms:3600000,level_band_size:5,level_cost_scale:.35,max_stack_ms:21600000,effect:{shield_pct:5},enabled:true},
  cargo:{name:'Otimização de Porão',description:'+750 capacidade de carga por 60 minutos.',base_cost:750000,duration_ms:3600000,level_band_size:5,level_cost_scale:.35,max_stack_ms:21600000,effect:{cargo_flat:750},enabled:true},
  thruster:{name:'Ajuste de Propulsão',description:'+5 velocidade por 60 minutos.',base_cost:1000000,duration_ms:3600000,level_band_size:5,level_cost_scale:.35,max_stack_ms:21600000,effect:{speed_flat:5},enabled:true}
};
const CRAFT_RECIPES_V1782={
  prometid_batch:{name:'Ferrite Refinada',description:'Comprime minérios básicos em Ferrite.',cost:200000,currency:'credits',ingredients:{Prometium:220,Endurium:120,Terbium:80},grant_payload:{kind:'resource',id:'Prometid',qty:30},output_label:'30 Ferrite',min_level:1,enabled:true},
  duranium_batch:{name:'Duracite Refinada',description:'Liga estrutural de média densidade.',cost:400000,currency:'credits',ingredients:{Endurium:140,Terbium:140,Prometid:20},grant_payload:{kind:'resource',id:'Duranium',qty:20},output_label:'20 Duracite',min_level:1,enabled:true},
  promerium_batch:{name:'Solarium Refinado',description:'Material raro para receitas avançadas.',cost:1500000,currency:'credits',ingredients:{Prometid:35,Duranium:35,Xenomit:3},grant_payload:{kind:'resource',id:'Promerium',qty:5},output_label:'5 Solarium',min_level:1,enabled:true},
  ammo_pls2:{name:'Lote PLS-2',description:'Produção de munição usando ligas refinadas.',cost:750000,currency:'credits',ingredients:{Prometid:25,Duranium:25,Promerium:1},grant_payload:{kind:'ammo',id:'mcb25',qty:1500},output_label:'1.500 PLS-2',min_level:1,enabled:true},
  rocket_pack:{name:'Lote R-2026',description:'Mísseis intermediários produzidos na base.',cost:500000,currency:'credits',ingredients:{Duranium:20,Promerium:1},grant_payload:{kind:'rocket',id:'plt2026',qty:100},output_label:'100 R-2026',min_level:1,enabled:true},
  repair_bonus:{name:'Carga de Nanorreparo',description:'Converte recursos em 1 Bônus de Reparo.',cost:1000000,currency:'credits',ingredients:{Prometium:40,Endurium:40,Duranium:20},grant_payload:{kind:'repair',qty:1},output_label:'1 Bônus de Reparo',min_level:1,enabled:true}
};
function runtimeServiceDef(runtime,id){const rows=Array.isArray(runtime?.economy_services)?runtime.economy_services:null;if(rows){const hit=rows.find(x=>x.service_id===id);return hit?(hit.enabled===false?null:hit):null;}return BASE_SERVICES_V1783[id]||null;}
function runtimeCraftDef(runtime,id){const rows=Array.isArray(runtime?.crafting_recipes)?runtime.crafting_recipes:null;if(rows){const hit=rows.find(x=>x.recipe_id===id);return hit?(hit.enabled===false?null:hit):null;}return CRAFT_RECIPES_V1782[id]||null;}
function activateBaseServiceServer(state,id,runtime){
  const def=runtimeServiceDef(runtime,id);if(!def)throw Object.assign(new Error('Serviço inexistente ou desativado.'),{status:404});const mapOk=['x1','x8'].includes(String(state.mapId||''))&&String(state.territoryFaction||state.profile?.faction||'')===String(state.profile?.faction||'');if(!mapOk)throw Object.assign(new Error('Serviço disponível somente nas bases X-1 e X-8.'),{status:409});
  const lv=Math.max(1,Number(state.profile?.level)||1),bandSize=Math.max(1,Number(def.level_band_size)||5),band=Math.floor((lv-1)/bandSize),scale=Math.max(0,Number(def.level_cost_scale)||0),base=Math.max(0,Number(def.base_cost??def.baseCost)||0),cost=Math.round(base*(1+band*scale));debitServer(state,cost,'credits');
  state.economyBoosts ||= {};const now=Date.now(),current=Math.max(now,Number(state.economyBoosts[id])||0),duration=Math.max(60000,Number(def.duration_ms??def.duration)||3600000),cap=now+Math.max(duration,Number(def.max_stack_ms)||21600000);state.economyBoosts[id]=Math.min(cap,current+duration);return {cost,expires_at:state.economyBoosts[id],duration_ms:duration};
}
function applyCraftRecipeServer(state,recipeId,runtime){
  const recipe=runtimeCraftDef(runtime,recipeId);if(!recipe)throw Object.assign(new Error('Receita inexistente ou desativada.'),{status:404});// V18.2.9: refino/crafting é uma função do Hangar e pode ser feito em qualquer mapa.
  const level=Math.max(1,Number(state.profile?.level)||1),minLevel=Math.max(1,Number(recipe.min_level)||1);if(level<minLevel)throw Object.assign(new Error(`Receita libera no nível ${minLevel}.`),{status:409});state.cargo ||= {};for(const [id,qty] of Object.entries(recipe.ingredients||{})){const have=Math.max(0,Math.floor(Number(state.cargo[id])||0));if(have<qty)throw Object.assign(new Error(`Recursos insuficientes: ${id}.`),{status:409});}
  const currency=String(recipe.currency)==='uridium'?'uridium':'credits',cost=Math.max(0,Number(recipe.cost)||0);debitServer(state,cost,currency);for(const [id,qty] of Object.entries(recipe.ingredients||{})){state.cargo[id]=Math.max(0,Math.floor(Number(state.cargo[id])||0)-qty);if(state.cargo[id]<=0)delete state.cargo[id];}
  const g=recipe.grant_payload||recipe.grant||{};if(g.kind==='resource')state.cargo[g.id]=(Number(state.cargo[g.id])||0)+g.qty;else if(g.kind==='ammo'){state.ammo ||= {};state.ammo[g.id]=(Number(state.ammo[g.id])||0)+g.qty;}else if(g.kind==='rocket'){state.rockets ||= {};state.rockets[g.id]=(Number(state.rockets[g.id])||0)+g.qty;}else if(g.kind==='repair'){state.galaxyGate ||= {};state.galaxyGate.repairBonus=Math.max(0,Number(state.galaxyGate.repairBonus)||0)+g.qty;}return {...recipe,currency,cost,output_label:recipe.output_label||recipe.label};
}

// Offline routes and live-economy guards installed BEFORE normal economy/save routes.
installOfflineFarmV484(app,{requireUser,asyncRoute,requireEliteAdmin,operationMonitor:SAVE_OPERATIONS_V1192});
installBalanceAuditV90(app,{requireUser,asyncRoute,requireEliteAdmin});
installCombatProgressionAuditV113(app,{requireUser,asyncRoute,requireEliteAdmin});
installCompetitiveReadinessV98(app,{requireUser,asyncRoute,requireEliteAdmin});
installLiveopsSnapshotV99(app,{requireUser,asyncRoute,requireEliteAdmin});
installReleaseReadinessV100(app,{requireUser,asyncRoute,requireEliteAdmin,publicRoot:path.join(__dirname,'../public'),releaseVersion:RELEASE_VERSION});
const OFFLINE_FARM_GUARD_V484=makeOfflineFarmGuardV484(requireEliteAdmin);
const AUCTION_SINGLE_FLIGHT_V1194=createAuctionSingleFlightV1194();
const playerRewardsV134=createPlayerRewardsV134({db:eliteAdminClient,readPass:()=>loadPassRuntimeSnapshot(false),readPremium:async req=>{const r=await req.sb.rpc('get_premium_shop_v12');if(r.error)throw Error(r.error.message);return r.data;},readBonus:async()=>{const r=await eliteAdminClient.rpc('get_bonus_box_config_v1825');if(r.error)throw Error(r.error.message);return r.data;},readSystems:()=>loadSystemsRuntimeSnapshot(false),world:()=>sharedUniverse,secret:SUPABASE_SERVICE_KEY});
app.post('/api/player/warfront/action',requireUser,OFFLINE_FARM_GUARD_V484,asyncRoute(async(req,res)=>res.json(await withPurchaseLock(req.user.id,()=>playerRewardsV134.warfront(req.user.id,req.body)))));
app.post('/api/player/rewards/claim',requireUser,OFFLINE_FARM_GUARD_V484,asyncRoute(async(req,res)=>res.json(await withPurchaseLock(req.user.id,()=>playerRewardsV134.claim(req.user.id,req.body,req)))));
app.post('/api/player/collections/ensure',requireUser,asyncRoute(async(req,res)=>res.json(await playerRewardsV134.ensure(req.user.id))));
app.post('/api/player/collections/claim',requireUser,asyncRoute(async(req,res)=>res.json(await playerRewardsV134.collect(req.user.id,req.body,req.gameSessionId))));
app.post('/api/player/auction/bid',requireUser,asyncRoute(async(req,res)=>{
 const b=req.body||{};
 if(Object.keys(b).some(k=>!['request_id','hour_key','lot_ref','user_bid','lot'].includes(k)))return res.status(400).json({ok:false,code:'BID_ARGUMENTS_INVALID'});
 const {data,error}=await req.sb.rpc('stellar_player_bid',{p_request_id:b.request_id,p_hour_key:b.hour_key,p_lot_ref:b.lot_ref,p_user_bid:b.user_bid,p_lot:b.lot});
 if(error){const raw=String(error.message||''),minimum=raw.match(/AUCTION_MINIMUM_CHANGED:(\d+)/);const message=minimum?'Lance mínimo atualizado: '+Number(minimum[1]).toLocaleString('pt-BR')+' CR.':raw.includes('AUCTION_ROUND_CLOSED')?'A rodada virou. Atualize o leilão.':raw.includes('Créditos insuficientes')?'Créditos insuficientes considerando os lances em garantia.':raw.includes('liderando')?'Você já está liderando este lote.':raw.includes('AUCTION_BID_STEP')?'Use lances em passos de 100.000 CR.':'O lance não foi aceito. Atualize o lote e tente novamente.';return res.status(409).json({ok:false,code:'AUCTION_BID_REJECTED',error:message});}
 res.set('Cache-Control','no-store').json(data);
}));

// V92–V97 • Uma requisição, uma compra autoritativa de munição/mísseis.
// O cliente escolhe unidades; servidor cobra PACOTES completos e entrega todos eles.
// request_id persiste no SAVE: repetir por timeout não cobra duas vezes.
// V118.2: server-only settlement. Auction rows, wallet, prize and A/B/C commit atomically.
app.post('/api/player/auction/settle',requireUser,OFFLINE_FARM_GUARD_V484,asyncRoute(async(req,res)=>{
  const body=req.body||{};
  if(Object.keys(body).some(key=>!['hour_key','lot_ref'].includes(key))||
     !/^20[0-9]{2}-[0-9]{2}-[0-9]{2}-[0-9]{2}$/.test(String(body.hour_key||''))||
     !/^(item|ship|ammo|rocket|petGear):[A-Za-z0-9_]+$/.test(String(body.lot_ref||'')))
    return res.status(400).json({ok:false,code:'AUCTION_REQUEST_INVALID',message:'Dados do leilão inválidos. Nenhuma cobrança feita.'});
  const result=await AUCTION_SINGLE_FLIGHT_V1194.run(
    auctionSettlementKeyV1194(req.user.id,body.hour_key,body.lot_ref),()=>withPurchaseLock(req.user.id,async()=>{
    const db=await requireEliteAdmin();
    const {data,error}=await SAVE_OPERATIONS_V1192.measure('leilao',()=>settleAuctionUnifiedV1332(db,{
      p_user_id:req.user.id,p_hour_key:body.hour_key,p_lot_ref:body.lot_ref
    }));
    if(error){
      console.error('[auction-v1182] settlement rejected',String(error.code||''),String(error.message||'').slice(0,180));
      const missing=['PGRST202','42883'].includes(String(error.code||''));
      return {ok:false,code:missing?'AUCTION_MIGRATION_REQUIRED':'AUCTION_SERVER_REVIEW',
        message:missing?'Atualização de segurança do leilão ainda não instalada.':
          'O servidor não confirmou a entrega do prêmio. Lance preservado; nenhuma nova cobrança foi concluída.'};
    }
    return data||{ok:false,code:'AUCTION_NO_RESPONSE',message:'O servidor não confirmou o leilão. Verifique novamente.'};
  }));
  res.set('Cache-Control','no-store');res.json(result);
}));

app.post('/api/player/missions/claim',requireUser,OFFLINE_FARM_GUARD_V484,asyncRoute(async(req,res)=>{
 const category=String(req.body?.category||''),key=String(req.body?.key||'');
 if(!['daily','weekly','monthly','special'].includes(category)||key.length>240||!key.startsWith(category+':'))return res.status(400).json({error:'Missão inválida'});
 const result=await withPurchaseLock(req.user.id,async()=>claimMissionCommandV1331({db:await requireEliteAdmin(),userId:req.user.id,category,key,loadRules:()=>loadSystemsRuntimeSnapshot(false),readDesigns:async()=>{const {data,error}=await req.sb.rpc('get_my_designers_v16');if(error)throw Error(error.message);return data;}}));
 res.set('Cache-Control','no-store').json(result);
}));

app.post('/api/player/purchase/bulk', requireUser, OFFLINE_FARM_GUARD_V484, asyncRoute(async (req,res)=>{
  const tamper=invalidShopArguments(req.body,['catalog_key','quantity','request_id','expected_price','expected_currency','expected_pack_size']);
  if(tamper)return res.status(400).json({error:'Parâmetros de lote inválidos.',code:'INVALID_BULK_ARGUMENTS'});
  const key=String(req.body?.catalog_key||'').trim(),quantity=Number(req.body?.quantity);
  const requestId=String(req.body?.request_id||'').trim();
  if(!/^(?:ammo|rocket):[A-Za-z0-9_-]{2,50}$/.test(key)||
     !/^[a-f0-9-]{20,70}$/i.test(requestId)||!Number.isSafeInteger(quantity))
    return res.status(400).json({error:'Produto, quantidade ou ID de pedido inválidos.'});
  const result=await withPurchaseLock(req.user.id,async()=>{
    // Recovery must precede catalog/price validation: a successful purchase must
    // remain replayable even if the ADM changes the price or disables the item.
    const operation=`bulk:${key}`,intentHash=operationDigestV125(operation,{quantity});
    const service=await requireEliteAdmin();
    const receiptRead=await service.from('stellar_economy_receipts_v125')
      .select('operation,request_hash,receipt').eq('user_id',req.user.id).eq('request_id',requestId).maybeSingle();
    if(receiptRead.error)throw Object.assign(new Error('Recibos V125 indisponíveis: falta SQL.'),{status:503});
    if(receiptRead.data){
      if(!replayValidV125(receiptRead.data,operation,intentHash))throw Object.assign(new Error('ID reutilizado para pedido diferente.'),{status:409});
      const {data:confirmed,error:readError}=await req.sb.from('game_saves').select('state').eq('user_id',req.user.id).maybeSingle();
      if(readError||!confirmed?.state)throw Object.assign(new Error('Save de compra confirmada indisponível.'),{status:503});
      return {state:confirmed.state,purchase:{...receiptRead.data.receipt?.purchase,replayed:true}};
    }
    const snapshot=await loadLiveOpsSnapshot(true),row=liveCatalogRow(snapshot,key);
    if(!row||!['ammo','rocket'].includes(row.kind)||row.shop_visible===false||row.enabled===false)
      throw Object.assign(new Error('Produto indisponível para compra em lote.'),{status:404});
    const grant=row.meta?.grant||{};
    if(String(grant.kind)!==row.kind||!String(grant.id||row.ref_id||''))
      throw Object.assign(new Error('Catálogo de munições inconsistente.'),{status:409});
    const packSize=Number(grant.qty),packPrice=Number(row.price);
    let quote;try{quote=quoteBulkPurchase({requested:quantity,packSize,packPrice});}
    catch(e){throw Object.assign(e,{status:400});}
    // Client confirms the exact current catalog quote, so ADM changes never charge silently.
    if(Number(req.body.expected_price)!==quote.price||
       String(req.body.expected_currency)!==(row.currency==='uridium'?'uridium':'credits')||
       Number(req.body.expected_pack_size)!==packSize)
      throw Object.assign(new Error('Preço do catálogo mudou. Abra a compra novamente para confirmar o novo valor.'),{status:409});
    const {data:saveRow,error:saveError}=await req.sb.from('game_saves')
      .select('state,updated_at').eq('user_id',req.user.id).maybeSingle();
    if(saveError)throw Error(saveError.message);
    if(!saveRow?.state)throw Object.assign(new Error('Save não encontrado.'),{status:409});
    const state=structuredClone(saveRow.state);
    if(String(state.accountOwnerId||req.user.id)!==req.user.id)
      throw Object.assign(new Error('Proprietário de save inválido.'),{status:403});
    // Idempotência com recibo persistido, inclusive após reiniciar o Render.
    const receipts=Array.isArray(state.bulkPurchaseReceiptsV92)?state.bulkPurchaseReceiptsV92:[];
    const previous=receipts.find(r=>r.requestId===requestId);
    if(previous){
      if(previous.catalogKey!==key||previous.quantity!==quantity)
        throw Object.assign(new Error('ID já usado para outro pedido.'),{status:409});
      return {state,purchase:{...previous,replayed:true}};
    }
    const minLevel=Math.max(1,Math.floor(Number(row.min_level)||1));
    if((Number(state.profile?.level)||1)<minLevel)
      throw Object.assign(new Error(`Requer nível ${minLevel}.`),{status:409});
    const currency=String(row.currency)==='uridium'?'uridium':'credits';
    const balance=Number(state.profile?.[currency]);
    if(!Number.isFinite(balance)||balance<quote.price)
      throw Object.assign(new Error('Saldo insuficiente para o lote.'),{status:409});
    const oldQuantity=Number((row.kind==='ammo'?state.ammo:state.rockets)?.[grant.id]||0);
    if(!Number.isSafeInteger(oldQuantity)||oldQuantity<0||oldQuantity+quote.delivered>1000000000)
      throw Object.assign(new Error('Estoque ultrapassaria o limite seguro.'),{status:409});
    // Usa o concedente oficial, apenas com a quantidade calculada a partir da tabela de preços.
    applyLiveGrant(state,{...row,meta:{...row.meta,grant:{...grant,qty:quote.delivered}}});
    state.profile[currency]=balance-quote.price;
    state.serverPurchaseRevision=Math.max(0,Math.floor(Number(state.serverPurchaseRevision)||0))+1;
    state.accountOwnerId=req.user.id;state.accountOwnerEmail=req.user.email||null;
    const receipt={requestId,catalogKey:key,quantity,delivered:quote.delivered,packages:quote.packages,price:quote.price,currency,at:Date.now()};
    state.bulkPurchaseReceiptsV92=[...receipts.slice(-23),receipt];
    const response=await commitEconomyUnifiedV1332(service,{
      p_user_id:req.user.id,p_request_id:requestId,p_operation:operation,p_request_hash:intentHash,
      p_base_state:saveRow.state,p_expected_updated_at:saveRow.updated_at,p_state:state,
      p_callsign:String(state.profile?.callsign||''),p_receipt:{purchase:receipt}
    });
    const result=decodeEconomyReceiptV125(response.data,response.error);
    if(!result.ok)throw Object.assign(new Error('Compra em lote sem confirmação: '+result.code),{status:result.code==='ECONOMY_STALE'?409:503,code:result.code});
    return {state:result.state,save_token:response.data?.save_token,purchase:{...(result.receipt?.purchase||receipt),...(result.replayed?{replayed:true}:{})}};
  });
  res.set('Cache-Control','no-store');res.json({ok:true,...result});
}));





app.post('/api/player/economy', requireUser, OFFLINE_FARM_GUARD_V484, asyncRoute(async (req,res)=>{
  const routeStarted=Date.now();
  const action=String(req.body?.action||'').trim();
  const payload=(req.body?.payload&&typeof req.body.payload==='object')?req.body.payload:{};
  const tamper=invalidShopArguments(req.body,['action','payload','request_id'])||invalidShopArguments(payload,['catalog_key','kind','qty','drone_id','item_id','resource_id','id','recipe_id','service_id','protocol','amount','level','request_id']);
  if(tamper){const outcome=await securityService.report(req.user.id,tamper,'economy_action');
    if(outcome?.auto_suspended)return res.status(403).json({error:'Conta temporariamente suspensa.',code:'ACCOUNT_BANNED'});
    return res.status(400).json({error:'Parâmetros econômicos não autorizados.',code:tamper.code});}
  if(!action)return res.status(400).json({error:'Ação econômica ausente.'});
  const requestId=req.body?.request_id==null?randomUUID():String(req.body.request_id);
  if(requestId!==null&&!requestIdValidV125(requestId))return res.status(400).json({error:'ID de transação inválido.',code:'ECONOMY_REQUEST_INVALID'});
  const op=`economy:${action}`;
  const intentHash=requestId?operationDigestV125(op,payload):null;
  const service=requestId?await requireEliteAdmin():null;
  const result=await withPurchaseLock(req.user.id,()=>withEconomySaveRetryV102(async()=>{
    const catalogActions=new Set(['auto_buy','unlock_pet_slot','buy_quantum_cores','sell_inventory','sell_drone','gate_spin','aux_protocol_buy','aux_protocol_craft']);
    const premiumActions=new Set(['auto_buy','gate_spin']);
    const systemsActions=new Set(['base_service','craft_recipe']);
    const [snapshot,state,premiumResult,systemsSnapshot,receiptResult]=await Promise.all([
      catalogActions.has(action)?loadLiveOpsSnapshot(false):Promise.resolve(null),
      readEconomySave(req),
      premiumActions.has(action)?req.sb.rpc('get_premium_shop_v12'):Promise.resolve({data:null,error:null}),
      systemsActions.has(action)?loadSystemsRuntimeSnapshot(false).catch(()=>null):Promise.resolve(null),
      requestId?service.from('stellar_economy_receipts_v125').select('operation,request_hash,receipt').eq('user_id',req.user.id).eq('request_id',requestId).maybeSingle():Promise.resolve({data:null,error:null})
    ]);
    if(receiptResult.error)throw Object.assign(new Error('Recibos V125 indisponíveis: falta aplicar SQL.'),{status:503,code:'ECONOMY_RECEIPTS_UNAVAILABLE'});
    if(receiptResult.data){
      if(!replayValidV125(receiptResult.data,op,intentHash))throw Object.assign(new Error('Identificador reutilizado com parâmetros diferentes.'),{status:409,code:'ECONOMY_ID_REUSED'});
      const replay=await commitEconomyUnifiedV1332(service,{p_user_id:req.user.id,p_request_id:requestId,p_operation:op,p_request_hash:intentHash,p_base_state:req.economyBaseV134,p_expected_updated_at:req.economyBaselineV125,p_state:state,p_callsign:state.profile?.callsign,p_receipt:receiptResult.data.receipt});
      const recovered=decodeEconomyReceiptV125(replay.data,replay.error);
      if(!recovered.ok)throw Object.assign(new Error('Recuperação não confirmada: '+recovered.code),{status:503,code:recovered.code});
      return {state:recovered.state,updated_at:recovered.updatedAt,info:recovered.receipt?.info||{},deduplicated:true};
    }
    if(premiumResult?.error)throw new Error(premiumResult.error.message);
    const premium=!!premiumResult?.data?.premium_active;
    const tradeAction=action==='auto_buy'||action==='sell_cargo';
    if(!tradeAction&&payload.request_id)throw Object.assign(new Error('Identificador exclusivo do comércio automático.'),{status:400});
    const legacyTradeId=tradeAction?tradeRequestIdV1164(payload.request_id):null;
    const previous=legacyTradeId?findTradeReceiptV1164(state,legacyTradeId,action,payload):null;
    // Replay is read-only. It never writes a new purchase, shipment or save.
    if(previous)return {state,updated_at:null,info:previous,deduplicated:true};
    let info={action};

    if(action==='auto_buy'){
      const extras=Array.isArray(state?.shipLoadout?.extras)?state.shipLoadout.extras:[];
      const buyAtBase=['x1','x8'].includes(String(state.mapId||''))&&
        String(state.territoryFaction||state.profile?.faction||'')===String(state.profile?.faction||'');
      if(!extras.includes('ammoAutoBuyCpu')&&!buyAtBase)throw Object.assign(new Error('Compra remota exige CPU AUTO BUY equipado; sem CPU, visite sua base.'),{status:403});
      const key=String(payload.catalog_key||'').slice(0,120),row=liveCatalogRow(snapshot,key);
      if(!row||!['ammo','rocket'].includes(String(row.kind||'')))throw Object.assign(new Error('AUTO BUY indisponível para esse produto.'),{status:404});
      const base=Math.max(0,Math.round(Number(row.price)||0)),price=premium&&premiumDiscountEligible(row)?Math.max(1,Math.floor(base*.95)):base,currency=String(row.currency||'credits')==='uridium'?'uridium':'credits';
      const before=currency==='uridium'?Number(state.profile.uridium||0):Number(state.profile.credits||0);debitServer(state,price,currency);const grant=row?.meta?.grant||{},id=String(grant.id||row.ref_id||''),qty=Math.max(1,Math.floor(Number(grant.qty)||1));applyLiveGrant(state,row);
      info={action,catalog_key:key,kind:String(row.kind),id,qty,price,currency,balance_before:before,balance_after:Number(state.profile[currency]||0)};
    }
    else if(action==='unlock_pet_slot'){
      const kind=String(payload.kind)==='shield'?'shield':'laser',pet=ensurePetState(state);if(!pet.owned)throw Object.assign(new Error('Adquira o AUX-9 primeiro.'),{status:409});
      const key=kind==='laser'?'laserSlotsUnlocked':'shieldSlotsUnlocked',listKey=kind==='laser'?'lasers':'shields',current=Math.max(kind==='shield'?2:1,Number(pet[key])||(kind==='shield'?2:1)),next=current+1,level=Math.max(1,Math.min(20,Number(pet.level)||1)),capacity=petSlotCapacityServer(kind,level);if(next>capacity)throw Object.assign(new Error(`Nível ${level}: limite atual de ${capacity} slots de ${kind==='laser'?'laser':'escudo'}.`),{status:409});
      const row=liveCatalogRow(snapshot,`pet_slot:${next}`);if(!row)throw Object.assign(new Error('Preço do slot não está publicado no LIVE OPS.'),{status:404});const cost=Math.max(0,Math.round(Number(row.price)||0));debitServer(state,cost,'uridium');pet[key]=next;pet[listKey]=Array.isArray(pet[listKey])?pet[listKey]:[];while(pet[listKey].length<next)pet[listKey].push(null);info={action,kind,slot:next,cost,currency:'uridium'};
    }
    else if(action==='buy_quantum_cores'){
      const qty=Math.max(1,Math.min(500,Math.floor(Number(payload.qty)||1))),row=liveCatalogRow(snapshot,'quantum_core:unit');if(!row)throw Object.assign(new Error('Núcleos Quânticos indisponíveis no LIVE OPS.'),{status:404});const unit=Math.max(0,Math.round(Number(row.price)||0)),cost=unit*qty;debitServer(state,cost,'uridium');state.pilotBio ||= {};state.pilotBio.logDisks=Math.max(0,Number(state.pilotBio.logDisks)||0)+qty;info={action,qty,unit_price:unit,cost,currency:'uridium'};
    }
    else if(action==='pilot_skill_upgrade'){
      info=applyPilotSkillUpgradeV102(state,String(payload.id||''));
    }
    else if(action==='pilot_skill_reset'){
      info=applyPilotSkillResetV102(state);
    }
    else if(action==='convert_pilot_point'){
      state.pilotBio ||= {};const p=state.pilotBio;p.logDisks=Math.max(0,Math.floor(Number(p.logDisks)||0));p.totalPoints=Math.max(0,Math.floor(Number(p.totalPoints)||0));if(p.totalPoints>=50)throw Object.assign(new Error('Limite de 50 Pontos de Pesquisa atingido.'),{status:409});const next=p.totalPoints+1,cost=Math.max(30,Math.round(30*Math.pow(1.1,Math.max(0,next-1))));if(p.logDisks<cost)throw Object.assign(new Error(`Faltam ${cost-p.logDisks} Núcleos Quânticos.`),{status:409});p.logDisks-=cost;p.totalPoints=next;info={action,point:next,cost,remaining_cores:p.logDisks};
    }
    else if(action==='base_service'){
      const serviceId=String(payload.service_id||'').slice(0,40),svc=activateBaseServiceServer(state,serviceId,systemsSnapshot);info={action,service_id:serviceId,cost:svc.cost,currency:'credits',expires_at:svc.expires_at,duration_ms:svc.duration_ms};
    }
    else if(['aux_protocol_buy','aux_protocol_craft','aux_protocol_equip'].includes(action)){
      info=applyAuxAdvancedActionV110(state,action,payload,{catalog:liveCatalogRow(snapshot,`aux_protocol:${String(payload.id||'')}`)});
    }
    else if(action==='craft_recipe'){
      const recipeId=String(payload.recipe_id||'').slice(0,64),recipe=applyCraftRecipeServer(state,recipeId,systemsSnapshot);info={action,recipe_id:recipeId,cost:recipe.cost,currency:recipe.currency,ingredients:recipe.ingredients,output:recipe.output_label};
    }
    else if(action==='sell_cargo'){
      const id=String(payload.resource_id||'all'),atBase=['x1','x8'].includes(String(state.mapId||''))&&String(state.territoryFaction||state.profile?.faction||'')===String(state.profile?.faction||'');
      const remoteEnabled=Array.isArray(state.shipLoadout?.extras)&&state.shipLoadout.extras.includes('remoteTraderCpuElite');
      if(!atBase&&!remoteEnabled)throw Object.assign(new Error('Venda remota requer Terminal Mercante Remoto Elite EQUIPADO na nave.'),{status:403});
      state.cargo ||= {};const ids=id==='all'?Object.keys(state.cargo):[id];
      const worldCfg=await loadWorldRuntimeSnapshot(false).catch(()=>null);
      const resourceRows=new Map((worldCfg?.resources||[]).map(r=>[String(r.resource_key||''),r]));
      // Only fetch the shop snapshot if the world resource configuration is absent
      // or does not cover a non-empty cargo item. Avoid blocking every sale on LiveOps.
      const needFallback=!worldCfg||ids.some(rid=>Number(state.cargo[rid])>0&&rid!=='Xenomit'&&!resourceRows.has(rid));
      const catalogForSale=needFallback?(await loadLiveOpsSnapshot(false).catch(()=>null)):null;
      const quote=quoteCargoSaleV130(state.cargo,{resourceId:id,worldResources:worldCfg?.resources||[],catalog:catalogForSale?.catalog||[]});
      if(quote.total<=0)throw Object.assign(new Error('Sem recursos vendáveis confirmados no servidor. Aguarde o crédito da mineração/coleta e tente novamente.'),{status:409,code:'CARGO_NOT_CONFIRMED'});
      for(const rid of Object.keys(quote.sold))delete state.cargo[rid];
      creditServer(state,quote.total,'credits');info={action,sold:quote.sold,total:quote.total,currency:'credits',remote:!atBase,price_source:worldCfg?'world_runtime':'live_ops_fallback'};
    }
    else if(action==='sell_inventory'){
      const itemId=String(payload.item_id||''),qty=Math.max(1,Math.min(999,Math.floor(Number(payload.qty)||1)));state.inventory ||= {};const have=Math.max(0,Math.floor(Number(state.inventory[itemId])||0));if(!itemId||have<qty)throw Object.assign(new Error('Item não disponível no inventário online.'),{status:409});const row=catalogSellRow(snapshot,itemId);if(!row)throw Object.assign(new Error('Esse item não possui preço online para venda.'),{status:404});const quote=saleQuoteV4776(row);if(!quote.available)throw Object.assign(new Error('Item sem cotação de revenda no catálogo.'),{status:409});const unit=quote.unit,total=unit*qty,currency=quote.currency;state.inventory[itemId]=have-qty;if(state.inventory[itemId]<=0)delete state.inventory[itemId];creditServer(state,total,currency);info={action,item_id:itemId,qty,unit,total,currency};
    }
    else if(action==='sell_drone'){
      const droneId=String(payload.drone_id||''),drones=Array.isArray(state.drones)?state.drones:[],idx=drones.findIndex(d=>String(d?.id||'')===droneId);if(idx<0)throw Object.assign(new Error('Drone não encontrado no save online.'),{status:404});const drone=drones[idx],row=liveCatalogRow(snapshot,`drone:${String(drone.type||'')}`);if(!row)throw Object.assign(new Error('Drone sem preço online para venda.'),{status:404});state.inventory ||= {};for(const itemId of (Array.isArray(drone.slots)?drone.slots:[]).filter(Boolean))state.inventory[itemId]=(Number(state.inventory[itemId])||0)+1;drones.splice(idx,1);state.drones=drones;syncFleetConfigsAfterDroneSaleV118(state,droneId);const quote=saleQuoteV4776(row);if(!quote.available)throw Object.assign(new Error('Drone sem cotação de revenda.'),{status:409});const refund=quote.unit,currency=quote.currency;creditServer(state,refund,currency);info={action,drone_id:droneId,drone_type:String(drone.type||''),refund,currency};
    }
    else if(action==='gate_life'){
      const key=String(payload.protocol||'alpha'),def=GATE_SERVER_DEFS[key];
      if(!def)throw Object.assign(new Error('Portal invalido.'),{status:400});
      const g=ensureGalaxyGateServer(state),gate=g[key];
      const mapOk=String(state.mapId||'')==='x1'&&String(state.territoryFaction||state.profile?.faction||'')===String(state.profile?.faction||'');
      if(!mapOk)throw Object.assign(new Error('Compre vidas do Portal somente na sua base X-1.'),{status:409});
      if(gate.lives>=def.maxLives)throw Object.assign(new Error('Limite de vidas atingido.'),{status:409});
      const cost=10000;debitServer(state,cost,'uridium');gate.lives=Math.min(def.maxLives,gate.lives+1);
      info={action,protocol:key,lives:gate.lives,max_lives:def.maxLives,cost,currency:'uridium'};
    }
    else if(action==='gate_life_bonus'){
      const key=String(payload.protocol||'alpha'),def=GATE_SERVER_DEFS[key];if(!def)throw Object.assign(new Error('Portal inválido.'),{status:400});const g=ensureGalaxyGateServer(state),gate=g[key];const mapOk=String(state.mapId||'')==='x1'&&String(state.territoryFaction||state.profile?.faction||'')===String(state.profile?.faction||'');if(!mapOk)throw Object.assign(new Error('Use vidas reserva somente na sua base X-1.'),{status:409});if(gate.lives>=def.maxLives)throw Object.assign(new Error(`${def.label} já está no máximo de ${def.maxLives} vidas.`),{status:409});if((g.lifeBonus||0)<=0)throw Object.assign(new Error('Nenhuma Vida Astral disponível na reserva.'),{status:409});g.lifeBonus--;gate.lives=Math.min(def.maxLives,gate.lives+1);info={action,protocol:key,lives:gate.lives,max_lives:def.maxLives,life_bonus:g.lifeBonus};
    }
    else if(action==='gate_spin'){
      const key=String(payload.protocol||'alpha'),amount=Math.max(1,Math.min(100,Math.floor(Number(payload.amount)||1)));if(!GATE_SERVER_DEFS[key]||![1,5,10,50,100].includes(amount))throw Object.assign(new Error('Sorteio de portal inválido.'),{status:400});if(!gateUnlockedServer(state,key))throw Object.assign(new Error(`${GATE_SERVER_DEFS[key].label} ainda está bloqueado.`),{status:409});const row=liveCatalogRow(snapshot,`gate_spin:${key}`);if(!row)throw Object.assign(new Error('Materializador sem preço publicado no LIVE OPS.'),{status:404});const payment=String(payload.payment||'uridium');
      if(!['uridium','dust'].includes(payment))throw Object.assign(new Error('Forma de pagamento inválida.'),{status:400});
      const bonusCfg=(await loadBonusRuntimeForUser(req)).config;
      const gatePrice=bonusCfg.gate_prices?.[key];if(!gatePrice)throw Object.assign(new Error('Preço do portal não configurado.'),{status:409});
      const baseUnit=Math.max(1,Math.floor(Number(gatePrice.stl)||100));
      const discount=Math.max(0,Math.min(50,Number(bonusCfg.premium_discount_pct)||0));
      const unit=payment==='dust'?Math.max(1,Math.floor(Number(gatePrice.dust)||1)):(premium?Math.max(1,Math.floor(baseUnit*(1-discount/100))):baseUnit);
      const cost=unit*amount;
      if(payment==='dust'){
        const balance=Math.max(0,Math.floor(Number(state.stellarDust)||0));
        if(balance<cost)throw Object.assign(new Error(`Poeira Stellar insuficiente: faltam ${cost-balance}.`),{status:409});
        state.stellarDust=balance-cost;
      }else debitServer(state,cost,'uridium');
      const results=[];for(let i=0;i<amount;i++)results.push(rollGateOnceServer(state,key));state.galaxyGate.lastResults=results.slice(-12);info={action,protocol:key,amount,base_unit_price:baseUnit,unit_price:unit,cost,currency:payment==='dust'?'stellarDust':'uridium',results,premium_discount:payment==='uridium'&&unit<baseUnit};
    }
    else throw Object.assign(new Error('Ação econômica não reconhecida pelo servidor.'),{status:400});

    if(legacyTradeId)rememberTradeReceiptV1164(state,legacyTradeId,action,payload,info);
    if(!requestId){const updated_at=await writeEconomySave(req,state);return {state,updated_at,info};}
    // Preserve old route semantics but commit receipt + save atomically across Render instances.
    state.serverPurchaseRevision=Math.max(0,Math.floor(Number(state.serverPurchaseRevision)||0))+1;
    state.accountOwnerId=req.user.id;state.accountOwnerEmail=req.user.email||null;
    const callsign=normalizeCallsign(state.profile?.callsign||'')||await ensureProfile(req.sb,req.user);
    state.profile={...state.profile,callsign};
    const commit=await commitEconomyUnifiedV1332(service,{
      p_user_id:req.user.id,p_request_id:requestId,p_operation:op,p_request_hash:intentHash,
      p_base_state:req.economyBaseV134,p_expected_updated_at:req.economyBaselineV125,p_state:state,p_callsign:callsign,
      p_receipt:{info}
    });
    const result=decodeEconomyReceiptV125(commit.data,commit.error);
    if(!result.ok)throw Object.assign(new Error('Operação sem confirmação econômica: '+result.code),{code:result.code,status:result.code==='ECONOMY_STALE'?409:503});
    return {state:result.state,save_token:commit.data?.save_token,updated_at:result.updatedAt,info:result.receipt?.info||info,deduplicated:result.replayed};
  },{maxAttempts:3,delay:attempt=>{console.warn('[economy-v102] save em conflito; relendo saldo e recompensas, tentativa',attempt+1);return new Promise(resolve=>setTimeout(resolve,40*attempt));}}));
  res.json({ok:true,...result,server_ms:Date.now()-routeStarted});
}));

app.all('/api/save',(req,res)=>res.status(410).json({ok:false,code:'CLIENT_UPDATE_REQUIRED',current_route:'/api/player/save',error:'Atualize o jogo para usar a rota atual.'}));
app.all('/api/economy/action',(req,res)=>res.status(410).json({ok:false,code:'CLIENT_UPDATE_REQUIRED',current_route:'/api/player/economy',error:'Atualize o jogo para usar a rota atual.'}));
app.all('/api/auction/settle',(req,res)=>res.status(410).json({ok:false,code:'CLIENT_UPDATE_REQUIRED',current_route:'/api/player/auction/settle',error:'Atualize o jogo para usar a rota atual.'}));
app.all('/api/missions/claim',(req,res)=>res.status(410).json({ok:false,code:'CLIENT_UPDATE_REQUIRED',current_route:'/api/player/missions/claim',error:'Atualize o jogo para usar a rota atual.'}));
app.all('/api/live/purchase/bulk',(req,res)=>res.status(410).json({ok:false,code:'CLIENT_UPDATE_REQUIRED',current_route:'/api/player/purchase/bulk',error:'Atualize o jogo para usar a rota atual.'}));
app.all('/api/live/purchase',(req,res)=>res.status(410).json({ok:false,code:'CLIENT_UPDATE_REQUIRED',current_route:'/api/player/purchase',error:'Atualize o jogo para usar a rota atual.'}));

app.all(['/api/coupons/redeem','/api/natal','/api/natal/claim'],(req,res)=>res.status(410).json({ok:false,code:'CLIENT_UPDATE_REQUIRED',error:'Atualize o jogo para a rota atual.'}));
// V18.2.5: fonte única dos preços de giros. Busca autenticada; falha bloqueia cobrança desatualizada.
async function loadBonusRuntimeForUser(req){
  const {data,error}=await req.sb.rpc('get_bonus_box_config_v1825');
  if(error||!data?.config)throw Object.assign(new Error('Configuração de BOX BÔNUS indisponível; tente novamente.'),{status:503});
  return data;
}
app.get('/api/runtime/bonus',requireUser,asyncRoute(async(req,res)=>res.json(await loadBonusRuntimeForUser(req))));
app.post('/api/admin/runtime/bonus',requireUser,asyncRoute(async(req,res)=>{
  const config=req.body?.config;
  if(!config||typeof config!=='object'||Array.isArray(config))return res.status(400).json({error:'Configuração JSON inválida.'});
  const {data,error}=await req.sb.rpc('admin_update_bonus_box_config_v1825',{p_config:config});
  if(error){const message=String(error.message||'Falha ao atualizar bônus.');return res.status(/administrativ|permiss|negado/i.test(message)?403:400).json({error:message});}
  res.json(data);
}));


// V19.0.6 — Fonte assinada e validada no banco para ondas e recompensas dos Portais.
app.get('/api/runtime/gates',requireUser,asyncRoute(async(req,res)=>{
 const {data,error}=await req.sb.rpc('get_galaxy_gate_config_v1906');
 if(error||!data?.config)return res.status(503).json({error:'Configuracao dos Portais indisponivel; confirme a migracao SQL V19.0.6.'});
 res.json(data);
}));
app.post('/api/admin/runtime/gates',requireUser,asyncRoute(async(req,res)=>{
 const key=String(req.body?.key||''),config=req.body?.config;
 if(!['alpha','beta','gamma'].includes(key)||!config||typeof config!=='object'||Array.isArray(config))return res.status(400).json({error:'Protocolo ou configuracao invalidos.'});
 const {data,error}=await req.sb.rpc('admin_update_galaxy_gate_config_v1906',{p_key:key,p_gate:config});
 if(error){const message=String(error.message||'Erro ao salvar Portal.');return res.status(/permiss|negad|administrativ/i.test(message)?403:400).json({error:message});}
 res.json(data);
}));


// V38.1 — endpoints de prêmios e ADM (Supabase como fonte única).
attachAstralRewardsV381(app,{requireUser,asyncRoute,requireEliteAdmin});

// V39–42: extensoes incrementais autenticadas.
attachFrontierUnifiedV42(app,{requireUser,asyncRoute});

// V42.1: objetivo semanal de esquadrão baseado em abates confirmados.
attachSquadObjectivesV421(app,{requireUser,asyncRoute});

// V42.2+42.3: loadouts e operacoes, sem afetar o loop Canvas.
attachStageAV423(app,{requireUser,asyncRoute});

// V42.4-42.6: instâncias de investigação, mercado com custódia e clãs.
attachStageBV426(app,{requireUser,asyncRoute});

attachAstralIntegrationsV435(app,{requireUser,asyncRoute});
attachFrontierAdminV440(app,{requireUser,asyncRoute});
attachFrontierAuditV450(app,{requireUser,asyncRoute});
attachAstralCombatV431(app,{requireUser,asyncRoute});

// V19.0.9 • Catálogo único de balanceamento validado pelo Supabase.
// Não altera preço, compra, save ou catálogo de recompensas.
app.get('/api/runtime/balance',requireUser,asyncRoute(async(req,res)=>{
 const {data,error}=await req.sb.rpc('get_balance_runtime_v1909');
 if(error||!Array.isArray(data?.entries))return res.status(503).json({error:'Balanceamento indisponível. Confirme a migração SQL V19.0.9.'});
 res.set('Cache-Control','no-store');res.json(data);
}));
app.post('/api/admin/runtime/balance',requireUser,asyncRoute(async(req,res)=>{
 const b=req.body&&typeof req.body==='object'?req.body:{};
 if(!['ship','item'].includes(b.kind)||typeof b.item_id!=='string'||b.item_id.length>64||
   !b.fields||Array.isArray(b.fields)||typeof b.fields!=='object'||JSON.stringify(b.fields).length>3500){
   return res.status(400).json({error:'Dados do balanceamento inválidos.'});
 }
 const {data,error}=await req.sb.rpc('admin_set_balance_v1909',{
   p_kind:b.kind,p_item_id:b.item_id,p_fields:b.fields,
   p_expected_version:Number.isInteger(b.expected_version)?b.expected_version:null
 });
 if(error){const message=String(error.message||'Servidor recusou o balanceamento.');
  return res.status(/acesso|permiss|admin|negado/i.test(message)?403:/recarregue|mudou/i.test(message)?409:400).json({error:message});}
 res.set('Cache-Control','no-store');res.json(data);
}));

// ===================== PLAYER TELEMETRY =====================
app.post('/api/telemetry', requireUser, asyncRoute(async(req,res)=>{
  const batch=(req.body&&typeof req.body==='object')?req.body:{};
  const {data,error}=await req.sb.rpc('record_player_telemetry_v1771',{p_batch:batch});
  if(error)return res.status(400).json({error:String(error.message||'Falha ao registrar telemetria.')});
  res.json(data&&typeof data==='object'?data:{ok:true});
}));

// ====== V48 • AUTOPILOT ENTITLEMENT / ADMIN GRANTS ======
// Admin RPC is authoritative. Entitlements are never sourced from Premium or JWT metadata.
async function autopilotAdminV48(req,res){
  const {data,error}=await req.sb.rpc('admin_status_v1763');
  if(error||data?.is_admin!==true){res.status(403).json({error:'Somente ADM autenticado.'});return false;}
  return true;
}
app.get('/api/autopilot/v48/access',requireUser,asyncRoute(async(req,res)=>{
  res.set('Cache-Control','no-store');
  const {data:admin,error:err}=await req.sb.rpc('admin_status_v1763');
  if(err)return res.status(503).json({error:'Autorização indisponível.'});
  const isAdmin=admin?.is_admin===true;
  if(isAdmin)return res.json({allowed:true,is_admin:true,source:'admin'});
  const service=await requireEliteAdmin();
  const {data,error}=await service.from('stellar_autopilot_access_v48').select('enabled,source,expires_at').eq('user_id',req.user.id).maybeSingle();
  if(error)return res.status(503).json({error:'Permissão do Autopilot indisponível.'});
  const active=data?.enabled===true&&(!data.expires_at||new Date(data.expires_at).getTime()>Date.now());
  return res.json({allowed:active,is_admin:false,source:active?data.source:null});
}));
// V116.1: telemetria minima de parada/rota/comercio, autenticada e limitada por piloto.
const autopilotDiagThrottleV116=new Map();
app.post('/api/autopilot/v116/diagnostics',requireUser,(req,res)=>{
  const event=String(req.body?.event||'');
  if(!['stopped','route_unavailable','route_watchdog','trade_timeout','trade_uncertain'].includes(event))
    return res.status(400).json({error:'Evento invalido'});
  const stamp=Date.now(),uid=String(req.user.id),last=autopilotDiagThrottleV116.get(uid)||0;
  if(stamp-last<20000)return res.status(202).json({ok:true,rateLimited:true});
  if(autopilotDiagThrottleV116.size>5000)autopilotDiagThrottleV116.clear();
  autopilotDiagThrottleV116.set(uid,stamp);
  const map=String(req.body?.map||'').slice(0,10),goal=String(req.body?.goal||'').slice(0,10);
  const reason=String(req.body?.reason||'').replace(/[^a-zA-Z0-9À-ÿ _•:.,→-]/g,'').slice(0,100);
  console.info('[autopilot-v116]',JSON.stringify({pilot:uid.slice(0,8),event,map,goal,base:req.body?.atBase===true,routeMisses:Math.min(1000,Math.max(0,Number(req.body?.routeMisses)||0)),tradeBusy:req.body?.tradeBusy===true,holdBuy:req.body?.tradeHoldBuy===true,holdSell:req.body?.tradeHoldSell===true,reason}));
  return res.json({ok:true});
});
app.get('/api/admin/autopilot/v48/grants',requireUser,asyncRoute(async(req,res)=>{
  if(!await autopilotAdminV48(req,res))return;
  const service=await requireEliteAdmin();
  const {data,error}=await service.from('stellar_autopilot_access_v48').select('user_id,enabled,source,expires_at,updated_at').limit(1000);
  if(error)return res.status(503).json({error:'Lista de permissões indisponível.'});
  res.set('Cache-Control','no-store');res.json({grants:data||[]});
}));
app.put('/api/admin/autopilot/v48/grants/:userId',requireUser,asyncRoute(async(req,res)=>{
  if(!await autopilotAdminV48(req,res))return;
  const userId=String(req.params.userId||'');
  if(!/^[a-f0-9-]{36}$/i.test(userId)||typeof req.body?.enabled!=='boolean')return res.status(400).json({error:'Dados inválidos.'});
  const service=await requireEliteAdmin();
  const {data:user,error:userError}=await service.from('profiles').select('id').eq('id',userId).maybeSingle();
  if(userError||!user)return res.status(404).json({error:'Jogador não encontrado.'});
  const {data:isProtected,error:protectedError}=await req.sb.rpc('is_game_admin_v1763',{p_uid:userId});
  if(protectedError)return res.status(503).json({error:'Não foi possível validar a conta.'});
  if(isProtected===true)return res.status(403).json({error:'Administradores já têm acesso.'});
  // Origem de acesso sempre ADM. Verificação de pagamento futuro exige fluxo próprio.
  const {data,error}=await service.from('stellar_autopilot_access_v48').upsert({user_id:userId,enabled:req.body.enabled,source:'admin',granted_by:req.user.id,expires_at:null,updated_at:new Date().toISOString()},{onConflict:'user_id'}).select('user_id,enabled').single();
  if(error)return res.status(503).json({error:'Permissão não pôde ser salva.'});
  res.set('Cache-Control','no-store');res.json({ok:true,grant:data});
}));
// ====== END AUTOPILOT V48 ======

// ===================== ADMIN CONTROL PANEL =====================
async function adminRpc(req,res,name,args={}){
  const {data,error}=await req.sb.rpc(name,args);
  if(error){const msg=String(error.message||'Operação administrativa recusada.');const denied=/administrativ|permiss|negado/i.test(msg);return res.status(denied?403:400).json({error:msg});}
  return res.json(data&&typeof data==='object'?data:{ok:true,data});
}
// V19.0.3 — CRUD seguro de cupons. O banco confere auth.uid e game_admins.
app.get('/api/admin/coupons',requireUser,asyncRoute(async(req,res)=>adminRpc(req,res,'admin_coupon_dashboard_v193')));
app.post('/api/admin/coupons',requireUser,asyncRoute(async(req,res)=>{
  const b=req.body&&typeof req.body==='object'?req.body:{};
  if(!Array.isArray(b.rewards)||b.rewards.length<1||b.rewards.length>12)return res.status(400).json({error:'Selecione de 1 a 12 prêmios.'});
  const started=b.starts_at?new Date(b.starts_at):null,expires=b.expires_at?new Date(b.expires_at):null;
  if((started&&!Number.isFinite(started.getTime()))||(expires&&!Number.isFinite(expires.getTime())))return res.status(400).json({error:'Datas inválidas.'});
  return adminRpc(req,res,'admin_create_coupon_v193',{
    p_code:String(b.code||'').trim().toUpperCase().slice(0,64),p_title:String(b.title||'').trim().slice(0,100),
    p_rewards:b.rewards,p_max_uses:Math.trunc(Number(b.max_uses)||1),p_min_level:Math.trunc(Number(b.min_level)||1),
    p_starts_at:started?.toISOString()||null,p_expires_at:expires?.toISOString()||null
  });
}));
app.post('/api/admin/coupons/:code/active',requireUser,asyncRoute(async(req,res)=>adminRpc(req,res,'admin_set_coupon_active_v193',{
  p_code:String(req.params.code||'').slice(0,64),p_active:req.body?.active===true
})));

// V47.7: controlled, expiring Warbot sessions; ADMIN check from authenticated RPC.
async function requireWarbotAdministrator(req,res){
  const {data,error}=await req.sb.rpc('admin_status_v1763');
  if(error||data?.is_admin!==true){res.status(403).json({error:'Apenas administradores podem controlar bots.'});return false;}
  return true;
}
app.get('/api/admin/warbots',requireUser,asyncRoute(async(req,res)=>{
  if(!await requireWarbotAdministrator(req,res))return;
  const sb=await requireEliteAdmin();
  const {data,error}=await sb.from('stellar_warbot_events_v477').select('map_id,enabled,mode,bots_per_faction,tier,attack_players,ends_at,updated_at').order('map_id');
  if(error)return res.status(503).json({error:'Execute primeiro o SQL V47.7 no Supabase.'});
  res.set('Cache-Control','no-store');res.json({ok:true,maps:data||[]});
}));
app.post('/api/admin/warbots',requireUser,asyncRoute(async(req,res)=>{
  if(!await requireWarbotAdministrator(req,res))return;
  const raw=req.body||{},map_id=String(raw.map_id||'');
  if(!WARBOT_MAPS.includes(map_id)||typeof raw.enabled!=='boolean')return res.status(400).json({error:'Mapa ou ativação inválida.'});
  if(raw.enabled&&(!['conquest','training'].includes(raw.mode)||!Number.isInteger(raw.bots_per_faction)||raw.bots_per_faction<1||raw.bots_per_faction>4||!Number.isInteger(raw.tier)||raw.tier<1||raw.tier>3))return res.status(400).json({error:'Modo, quantidade ou dificuldade inválida.'});
  const duration=Number(raw.duration_minutes);
  if(raw.enabled&&(!Number.isInteger(duration)||duration<5||duration>120))return res.status(400).json({error:'Duração deve ser de 5 a 120 minutos.'});
  const cleaned=cleanWarbotConfig({enabled:raw.enabled,mode:raw.mode,bots_per_faction:raw.bots_per_faction,tier:raw.tier,attack_players:raw.attack_players===true,ends_at:raw.enabled?new Date(Date.now()+duration*60000).toISOString():null});
  const sb=await requireEliteAdmin();
  const values={map_id,...cleaned,updated_at:new Date().toISOString(),updated_by:req.user.id};
  const {error}=await sb.from('stellar_warbot_events_v477').upsert(values,{onConflict:'map_id'});
  if(error)return res.status(503).json({error:'Não foi possível persistir Warbots. Confira a migração V47.7.'});
  await sharedUniverse.refreshWarbotSettings(true);
  res.set('Cache-Control','no-store');res.json({ok:true,map_id,configuration:cleaned});
}));

// V47.7.4: U-X preflight uses the same Supabase role authority as /ws join_map.
app.get('/api/frontier/admin-entry',requireUser,asyncRoute(async(req,res)=>{
  const mapId=String(req.query.mapId||'');
  if(!/^u[1-3]$/.test(mapId))return res.status(400).json({allowed:false,error:'Setor inválido'});
  const {data,error}=await req.sb.rpc('is_game_admin_v1763',{p_uid:req.user.id});
  if(error)return res.status(503).json({allowed:false,error:'Não foi possível verificar ADM'});
  res.set('Cache-Control','no-store');return res.json({allowed:data===true,mapId});
}));
app.get('/api/admin/status', requireUser, asyncRoute(async(req,res)=>adminRpc(req,res,'admin_status_v1763')));
app.get('/api/admin/users', requireUser, asyncRoute(async(req,res)=>adminRpc(req,res,'admin_search_accounts_v1763',{p_query:String(req.query?.q||'').slice(0,120)})));
app.get('/api/admin/actions', requireUser, asyncRoute(async(req,res)=>adminRpc(req,res,'admin_recent_actions_v1763')));
app.get('/api/admin/telemetry', requireUser, asyncRoute(async(req,res)=>adminRpc(req,res,'admin_telemetry_overview_v1771')));
// Histórico antifraude acessível somente ao ADM autenticado, com direito à revisão.
app.get('/api/admin/security/incidents',requireUser,asyncRoute(async(req,res)=>{
 const {data:adm,error:admErr}=await req.sb.rpc('admin_status_v1763');if(admErr||!adm?.is_admin)return res.status(403).json({error:'Acesso administrativo negado.'});
 if(!eliteAdminClient)return res.status(503).json({error:'Servidor de auditoria não configurado.'});
 const {data,error}=await eliteAdminClient.from('stellar_security_events').select('id,user_id,code,severity,context,created_at,auto_suspended,reviewed_at,review_note').order('created_at',{ascending:false}).limit(80);
 if(error)return res.status(503).json({error:'Não foi possível carregar o histórico antifraude.'});res.set('Cache-Control','no-store');res.json({incidents:data||[]});
}));
app.post('/api/admin/security/incidents/:id/review',requireUser,asyncRoute(async(req,res)=>{
 const {data:adm,error:admErr}=await req.sb.rpc('admin_status_v1763');if(admErr||!adm?.is_admin)return res.status(403).json({error:'Acesso administrativo negado.'});
 const note=String(req.body?.note||'').trim().slice(0,200);if(!note)return res.status(400).json({error:'Informe o motivo da revisão.'});
 const {data,error}=await req.sb.rpc('stellar_security_review_incident',{p_event_id:Number(req.params.id),p_note:note});
 if(error)return res.status(400).json({error:'Revisão recusada.'});res.json(data);
}));
app.get('/api/admin/telemetry/:userId', requireUser, asyncRoute(async(req,res)=>adminRpc(req,res,'admin_player_telemetry_v1771',{p_target_user_id:req.params.userId})));
app.post('/api/admin/users/:userId/ban', requireUser, asyncRoute(async(req,res)=>{
  const minutes=Math.max(0,Math.min(525600,Math.trunc(Number(req.body?.minutes)||0)));
  return adminRpc(req,res,'admin_set_ban_v1763',{p_target_user_id:req.params.userId,p_minutes:minutes,p_reason:String(req.body?.reason||'').slice(0,240)});
}));
app.post('/api/admin/users/:userId/unban', requireUser, asyncRoute(async(req,res)=>adminRpc(req,res,'admin_unban_user_v1763',{p_target_user_id:req.params.userId})));
app.post('/api/admin/users/:userId/reset', requireUser, asyncRoute(async(req,res)=>adminRpc(req,res,'stellar_player_admin_reset_account',{p_target_user_id:req.params.userId})));
app.delete('/api/admin/users/:userId', requireUser, asyncRoute(async(req,res)=>adminRpc(req,res,'admin_delete_account_v1763',{p_target_user_id:req.params.userId})));

// Dados de progresso e resgates lidos da base autenticada, nunca do navegador.
// Status: somente tabelas autenticadas. Metricas observadas sao do servidor.
app.get('/api/elite',requireUser,asyncRoute(async(req,res)=>{
 const [counters,claims,objectives,adminCheck]=await Promise.all([
  req.sb.from('stellar_elite_counters').select('npc_kills,sector_captures').eq('user_id',req.user.id).maybeSingle(),
  req.sb.from('stellar_elite_claims').select('objective_id,title,claimed_at').eq('user_id',req.user.id),
  req.sb.from('stellar_elite_objectives').select('objective_id,label,title,metric,target,credits,stl,enabled,sort_order').eq('enabled',true).order('sort_order'),
  req.sb.rpc('is_game_admin_v1763',{p_uid:req.user.id})
 ]);
 if(counters.error||claims.error||objectives.error)return res.status(503).json({error:'Operações de Elite indisponíveis. Execute o SQL de instalação.',detail:String(counters.error?.message||claims.error?.message||objectives.error?.message||'')});
 res.json({ok:true,objectives:eliteStatus(counters.data||{},claims.data||[],objectives.data||[]),titles:(claims.data||[]).map(x=>({name:x.title,objective_id:x.objective_id,earned_at:x.claimed_at})),isAdmin:adminCheck.data===true&&!adminCheck.error});
}));
app.post('/api/elite/claim',requireUser,asyncRoute(async(req,res)=>{
 const objectiveId=String(req.body?.objectiveId||'');
 if(!/^[a-z][a-z0-9_]{2,39}$/.test(objectiveId))return res.status(400).json({error:'Objetivo inválido.'});
 const {data,error}=await req.sb.rpc('stellar_player_claim_elite_objective',{p_objective_id:objectiveId});
 if(error)return res.status(409).json({error:error.message||'Resgate não autorizado.'});
 res.json(data);
}));
app.get('/api/admin/elite/objectives',requireUser,asyncRoute(async(req,res)=>{
 const {data:admin,error:adminError}=await req.sb.rpc('is_game_admin_v1763',{p_uid:req.user.id});
 if(adminError||admin!==true)return res.status(403).json({error:'Acesso reservado ao ADM.'});
 const sb=await requireEliteAdmin();const {data,error}=await sb.from('stellar_elite_objectives').select('*').order('sort_order');
 if(error)return res.status(503).json({error:error.message});res.json({items:data||[]});
}));
app.post('/api/admin/elite/objectives',requireUser,asyncRoute(async(req,res)=>{
 const {data:admin,error:adminError}=await req.sb.rpc('is_game_admin_v1763',{p_uid:req.user.id});
 if(adminError||admin!==true)return res.status(403).json({error:'Acesso reservado ao ADM.'});
 const b=req.body||{},id=String(b.objective_id||'').trim(),metric=String(b.metric||'');
 const label=String(b.label||'').trim(),title=String(b.title||'').trim();
 const target=Number(b.target),credits=Number(b.credits),stl=Number(b.stl),sortOrder=Number(b.sort_order);
 if(!/^[a-z][a-z0-9_]{2,39}$/.test(id)||!['npc_kills','sector_captures'].includes(metric)||label.length<3||label.length>70||title.length<3||title.length>70||!Number.isSafeInteger(target)||target<1||target>1000000||!Number.isSafeInteger(credits)||credits<0||credits>500000||!Number.isSafeInteger(stl)||stl<0||stl>1000)return res.status(400).json({error:'Confira ID, tipo, metas e prêmios.'});
 const sb=await requireEliteAdmin();
 // Não editar tipo/meta de um objetivo já resgatado: protege os requisitos históricos.
 const {data:claims,error:clErr}=await sb.from('stellar_elite_claims').select('objective_id').eq('objective_id',id).limit(1);
 if(clErr)return res.status(503).json({error:clErr.message});
 if(claims?.length){const {data:current}=await sb.from('stellar_elite_objectives').select('metric,target').eq('objective_id',id).maybeSingle();if(current&&(current.metric!==metric||Number(current.target)!==target))return res.status(409).json({error:'Não altere métrica/meta de um objetivo com resgates. Crie outro ID.'});}
 const payload={objective_id:id,label,title,metric,target,credits,stl,enabled:b.enabled===true,sort_order:Number.isFinite(sortOrder)?Math.max(0,Math.min(9999,Math.trunc(sortOrder))):100,updated_at:new Date().toISOString()};
 const {data,error}=await sb.from('stellar_elite_objectives').upsert(payload,{onConflict:'objective_id'}).select().single();
 if(error)return res.status(400).json({error:error.message});res.json({ok:true,item:data});
}));


// Guerra de Facções: painel e rankings sempre originados do Supabase, nunca do save local.
app.get('/api/war/campaigns',requireUser,asyncRoute(async(req,res)=>{
 const sb=await requireEliteAdmin();
 const queries=await Promise.all([
  sb.from('stellar_war_campaigns').select('*').order('starts_at',{ascending:false}).limit(20),
  sb.from('stellar_warfront_nodes').select('map_id,node_id,owner,captured_at,revision').order('map_id'),
  sb.from('stellar_war_rules').select('*').eq('id',1).single(),
  sb.from('stellar_war_actions').select('kind,map_id,node_id,faction,occurred_at,points').order('occurred_at',{ascending:false}).limit(25),
  sb.from('stellar_war_scores').select('campaign_id,user_id,faction,clan_id,points,captures,defenses').order('points',{ascending:false}).limit(500),
  sb.from('stellar_war_supply_claims').select('claim_day').eq('user_id',req.user.id).order('claim_day',{ascending:false}).limit(1),
  sb.from('stellar_war_campaign_claims').select('campaign_id').eq('user_id',req.user.id).limit(50),
  req.sb.rpc('is_game_admin_v1763',{p_uid:req.user.id})
 ]);
 const failed=queries.find(q=>q.error);if(failed)return res.status(503).json({error:'Guerra indisponível. Verifique a migração do banco.',detail:failed.error.message});
 const [campaigns,nodes,rules,actions,scores,supply,claimed,adm]=queries.map(q=>q.data);
 const active=(campaigns||[]).find(c=>warCampaignState(c)==='ativa')||null;
 const recent=(campaigns||[]).filter(c=>c.enabled).slice(0,8);
 const targetIds=new Set(recent.map(c=>c.id));const participants=(scores||[]).filter(s=>targetIds.has(s.campaign_id));
 const clanIds=[...new Set(participants.map(s=>s.clan_id).filter(Boolean))];
 const clans=clanIds.length?await sb.from('clans').select('id,tag,name').in('id',clanIds):{data:[]};
 const claimsSet=new Set((claimed||[]).map(c=>c.campaign_id));
 const campaignRows=recent.map(c=>{
   const ranking=warRankings(c,participants,[],clans.data||[]);
   const mine=participants.find(s=>s.campaign_id===c.id&&s.user_id===req.user.id)||null;
   const best=ranking.factions[0]?.points||0;
   const eligible=warCampaignState(c)==='encerrada'&&mine&&Number(mine.points)>=Number(c.min_points);
   // Não publicar UUIDs dos pilotos de outras contas no endpoint.
   ranking.pilots=ranking.pilots.map(p=>({rank:p.rank,pilot:p.userId===req.user.id?'VOCÊ':`PILOTO #${p.rank}`,isYou:p.userId===req.user.id,faction:p.faction,points:p.points,captures:p.captures,defenses:p.defenses}));
   return {id:c.id,title:c.title,starts_at:c.starts_at,ends_at:c.ends_at,state:warCampaignState(c),min_points:c.min_points,reward_credits:c.reward_credits,reward_stl:c.reward_stl,my_points:Number(mine?.points)||0,my_faction:mine?.faction||null,claimable:Boolean(eligible&&!claimsSet.has(c.id)),claimed:claimsSet.has(c.id),winner:ranking.factions.filter(f=>f.points===best&&best>0).map(f=>f.faction),ranking};
 });
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 res.json({ok:true,nodes:nodes||[],rules:rules||{},actions:actions||[],campaigns:campaignRows,active_id:active?.id||null,supply_claimed_today:supply?.[0]?.claim_day===today,isAdmin:adm===true});
}));
app.post('/api/war/supply/claim',requireUser,asyncRoute(async(req,res)=>{
 const {data,error}=await req.sb.rpc('stellar_player_claim_war_supply');if(error)return res.status(409).json({error:error.message});res.json(data);
}));
app.post('/api/war/campaigns/:id/claim',requireUser,asyncRoute(async(req,res)=>{
 const id=String(req.params.id);if(!/^[0-9a-f-]{36}$/i.test(id))return res.status(400).json({error:'Campanha inválida.'});
 const {data,error}=await req.sb.rpc('stellar_player_claim_war_campaign',{p_campaign_id:id});if(error)return res.status(409).json({error:error.message});res.json(data);
}));
async function requireWarAdmin(req,res){const {data,error}=await req.sb.rpc('is_game_admin_v1763',{p_uid:req.user.id});if(error||data!==true){res.status(403).json({error:'Somente ADM.'});return null;}return requireEliteAdmin();}
app.get('/api/admin/war/campaigns',requireUser,asyncRoute(async(req,res)=>{
 const sb=await requireWarAdmin(req,res);if(!sb)return;const [c,r]=await Promise.all([sb.from('stellar_war_campaigns').select('*').order('starts_at',{ascending:false}).limit(100),sb.from('stellar_war_rules').select('*').eq('id',1).single()]);
 if(c.error||r.error)return res.status(503).json({error:c.error?.message||r.error?.message});res.json({campaigns:c.data||[],rules:r.data});
}));
app.post('/api/admin/war/rules',requireUser,asyncRoute(async(req,res)=>{
 const sb=await requireWarAdmin(req,res);if(!sb)return;let rule;try{rule=safeWarRulesInput(req.body);}catch(e){return res.status(400).json({error:e.message});}
 const {data,error}=await sb.from('stellar_war_rules').update({...rule,updated_at:new Date().toISOString()}).eq('id',1).select().single();if(error)return res.status(400).json({error:error.message});res.json({ok:true,rule:data});
}));
app.post('/api/admin/war/campaigns',requireUser,asyncRoute(async(req,res)=>{
 const sb=await requireWarAdmin(req,res);if(!sb)return;let payload;try{payload=safeWarCampaignInput(req.body);}catch(e){return res.status(400).json({error:e.message});}
 const id=String(req.body?.id||'');if(id&&!/^[0-9a-f-]{36}$/i.test(id))return res.status(400).json({error:'ID inválido.'});if(id)payload.id=id;
 const {data,error}=await sb.from('stellar_war_campaigns').upsert(payload,{onConflict:'id'}).select().single();if(error)return res.status(409).json({error:error.message});res.json({ok:true,campaign:data});
}));

// Sistemas adicionais do Centro de Comando isolados do motor de combate.
app.use('/api/command',requireUser,createCommandCenterRouter({serviceClient:eliteAdminClient}));
app.use('/api/relay',requireUser,createRelayRouter({serviceClient:eliteAdminClient}));
app.use('/api/relay/dominion',requireUser,createDominionRouter({serviceClient:eliteAdminClient}));
app.use('/api/frontier',requireUser,createFrontierRouter({serviceClient:eliteAdminClient}));

app.get('/api/player/save', requireUser, asyncRoute(async (req, res) => {
  // V119.1: leitura de progresso e epoca de reset iniciadas em paralelo.
  // Isso reduz uma ida-e-volta na inicializacao do Android, sem cachear saldo.
  const resetReadV1191=req.sb.from('stellar_account_reset_epochs_v478')
    .select('epoch').eq('user_id',req.user.id).maybeSingle();
  let data=null,error=null,revisionV119=null;
  ({data,error}=await readSaveForWrite(req));
  if (error) return res.status(503).json({ error:'Leitura do save indisponivel.',code:'SAVE_READ_UNAVAILABLE' });
  const {data: resetRecord,error: resetErr}=await resetReadV1191;
  if(resetErr)return res.status(503).json({error:'Integridade do reset indisponível. Execute o SQL de pré-lançamento.'});
  res.set('Cache-Control','no-store');
  const playerState=data?.state?structuredClone(data.state):null;
  if(playerState)pruneOrphanedDroneLayoutsV118(playerState);
  res.json({ checkpoint_receipts:data?.checkpoint_receipts||[],save_token:data?.save_token, state: playerState, updated_at: data?.updated_at || null,
    reset_epoch:Number(resetRecord?.epoch)||0,...(revisionV119==null?{}:{revision:revisionV119}) });
}));

// V119: consulta de diagnosticos somente leitura. Nao revela estado de outros pilotos.
app.get('/api/player/save/core/status',requireUser,asyncRoute(async(req,res)=>{
  const service=await requireEliteAdmin();
  const {data:head,error}=await service.from('stellar_player_save_head_v119')
    .select('revision,state_hash,changed_at,checkpointed_at,journaled_at').eq('user_id',req.user.id).maybeSingle();
  if(error)return res.json({ok:true,mode:'legacy',revision:null,checkpoints:[],message:'Nucleo unificado ainda nao inicializado.'});
  const {data:slots}=await service.from('stellar_player_save_checkpoint_v119')
    .select('slot,revision,state_hash,captured_at').eq('user_id',req.user.id).order('slot');
  res.set('Cache-Control','no-store');
  return res.json({ok:true,mode:saveCoreModeV119(),revision:head?.revision??null,
    lastChangedAt:head?.changed_at||null,lastCheckpointAt:head?.checkpointed_at||null,
    lastLogAt:head?.journaled_at||null,
    latencyMs:SAVE_LATENCY_V1191.snapshot(),
    checkpoints:(slots||[]).map(x=>({slot:x.slot,revision:x.revision,captured_at:x.captured_at}))});
}));
// V119.2: diagnostico pontual, somente do piloto autenticado.
// Não consulta todos os jogadores, não altera game_saves e não recupera backups sozinho.
app.get('/api/player/save/core/health',requireUser,asyncRoute(async(req,res)=>{
  const service=await requireEliteAdmin();
  const uid=req.user.id;
  const [canonical,profile,head,checkpoints,farm]=await Promise.all([
    service.rpc('stellar_read_player_save_v119',{p_user_id:uid}),
    service.from('profiles').select('credits,uridium,xp,aliens_killed').eq('id',uid).maybeSingle(),
    service.from('stellar_player_save_head_v119').select('revision,changed_at').eq('user_id',uid).maybeSingle(),
    service.from('stellar_player_save_checkpoint_v119').select('slot,revision,captured_at').eq('user_id',uid).order('slot'),
    service.from('stellar_offline_farm_v484').select('status,started_at,ends_at')
      .eq('user_id',uid).order('created_at',{ascending:false}).limit(1).maybeSingle()
  ]);
  if(canonical.error||profile.error||head.error||checkpoints.error||farm.error)
    return res.status(503).json({ok:false,code:'SAVE_HEALTH_READ_UNAVAILABLE',
      message:'Não foi possível verificar todos os componentes do save.'});
  const health=inspectSaveHealthV1192({state:canonical.data?.state,profile:profile.data,
    ownerId:uid,head:head.data,checkpoints:checkpoints.data||[],farm:farm.data,
    verified:canonical.data?.verified,mode:saveCoreModeV119()});
  res.set('Cache-Control','no-store');
  return res.json({...health,latencyMs:SAVE_LATENCY_V1191.snapshot(),
    operations:SAVE_OPERATIONS_V1192.snapshot()});
}));

// V120.0 RC: admin-only cutover diagnostics. This endpoint cannot promote a release.
app.get('/api/admin/save/v120/readiness',requireUser,asyncRoute(async(req,res)=>{
  const {data:isAdmin,error:adminError}=await req.sb.rpc('is_game_admin_v1763',{p_uid:req.user.id});
  if(adminError||isAdmin!==true)return res.status(403).json({ok:false,code:'ADMIN_REQUIRED'});
  const service=await requireEliteAdmin();
  const {data,error}=await service.rpc('stellar_save_release_readiness_v120');
  if(error)return res.status(503).json({ok:false,code:'V120_READINESS_SQL_NOT_INSTALLED',
    note:'Execute a SQL de readiness V120 em homologacao antes da avaliacao.'});
  res.set('Cache-Control','no-store');
  const promotion=savePromotionReadinessV1195({requestedMode:process.env.STELLAR_SAVE_V119_MODE});
  return res.json({ok:true,version:'V120.0-RC',promotion,database:data,
    safeToPromote:promotion.ready===true&&data?.db_preflight_passed===true&&data?.cutover_certified===true,
    operationLatency:SAVE_OPERATIONS_V1192.snapshot()});
}));

// V119.1: read-only consolidated audit view. Nao participa de compras,
// recompensas, save ou calculo de saldo. JWT fica no Render.
app.get('/api/player/save/core/events',requireUser,asyncRoute(async(req,res)=>{
  const limit=Math.min(50,Math.max(1,Math.round(Number(req.query.limit)||20)));
  const moduleName=String(req.query.module||'').trim();
  if(moduleName&&!['combate','leilao','farm','save'].includes(moduleName))
    return res.status(400).json({error:'Categoria de registro desconhecida.'});
  const service=await requireEliteAdmin();
  let query=service.from('stellar_player_save_audit_v1191')
    .select('happened_at,module,event,summary').eq('user_id',req.user.id)
    .order('happened_at',{ascending:false}).limit(limit);
  if(moduleName)query=query.eq('module',moduleName);
  const {data,error}=await query;
  if(error)return res.status(503).json({error:'Historico temporariamente indisponivel.',code:'SAVE_AUDIT_READ_UNAVAILABLE'});
  res.set('Cache-Control','no-store');
  res.json({ok:true,entries:data||[]});
}));

app.get('/api/player/save/core/logs',requireUser,asyncRoute(async(req,res)=>{
  const moduleName=String(req.query.module||'').trim();
  if(moduleName&&!SAVE_LOG_MODULES_V119.includes(moduleName))return res.status(400).json({error:'Modulo desconhecido.'});
  const limit=Math.min(50,Math.max(1,Math.round(Number(req.query.limit)||20)));
  const service=await requireEliteAdmin();
  let query=service.from('stellar_player_save_journal_v119')
    .select('revision,modules,created_at').eq('user_id',req.user.id)
    .order('revision',{ascending:false}).limit(limit);
  if(moduleName)query=query.contains('modules',[moduleName]);
  const {data,error}=await query;
  if(error)return res.status(503).json({error:'Historico do save indisponivel.'});
  res.set('Cache-Control','no-store');res.json({ok:true,entries:data||[]});
}));

/* STELLAR_SHIPS3D_FLEET_V50: server-authoritative 13 ships, without deleting ownership/inventory */
const SHIP_IDS_V50=new Set(["phoenix","leonov","liberator","piranha","vengeance","bigboy","goliath","citadel","aegis","spearhead","defcom","yamato","nostromo"]);
function normalizeShipSaveV50(state){
  if(!state||typeof state!=='object')return;
  if(SHIP_IDS_V50.has(String(state.activeShipId||'')))return;
  state.activeShipId='phoenix';
  if(!Array.isArray(state.ownedShips))state.ownedShips=[];
  if(!state.ownedShips.includes('phoenix'))state.ownedShips.push('phoenix');
  if(state.repairRequired&&typeof state.repairRequired==='object')state.repairRequired.shipId='phoenix';
}
app.use('/api/player/save',(req,res,next)=>{if(req.method==='PUT'&&req.body?.state)normalizeShipSaveV50(req.body.state);next();});
app.put('/api/player/save', requireUser, OFFLINE_FARM_GUARD_V484, asyncRoute(async (req, res) => withPurchaseLock(req.user.id, async()=> {
  let state = req.body?.state;
  if (!state || typeof state !== 'object') return res.status(400).json({ error: 'Save inválido.' });
  const {data:resetRecord,error:resetErr}=await req.sb.from('stellar_account_reset_epochs_v478').select('epoch').eq('user_id',req.user.id).maybeSingle();
  if(resetErr)return res.status(503).json({error:'Integridade do reset indisponível. Execute o SQL de pré-lançamento.'});
  const expectedEpoch=Math.max(0,Math.trunc(Number(resetRecord?.epoch)||0));
  const incomingEpoch=Math.max(0,Math.trunc(Number(state.adminResetEpoch)||0));
  if(expectedEpoch!==incomingEpoch)return res.status(409).json({error:'SAVE_RESET_STALE: progresso antigo após reset administrativo.',code:'SAVE_RESET_STALE'});
  const claimedOwner = String(state.accountOwnerId || '');
  if (claimedOwner && claimedOwner !== req.user.id) {
    const outcome=await securityService.report(req.user.id,{code:'SAVE_OWNER_FORGED',severity:'critical',evidence:{kind:'owner_mismatch'}},'cloud_save');
    if(outcome?.auto_suspended)return res.status(403).json({error:'Conta temporariamente suspensa.',code:'ACCOUNT_BANNED'});
    return res.status(409).json({ error: 'SAVE BLOQUEADO: os dados pertencem a outra conta.', code: 'SAVE_OWNER_MISMATCH' });
  }
  if(req.body?.operation_id){
    if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(req.body.operation_id))return res.status(400).json({error:'ID inválido',code:'SAVE_OPERATION_ID_INVALID'});
    req.saveOperationV133={id:req.body.operation_id,hash:operationDigestV125('checkpoint',{state:req.body.state,equipment:req.body.equipmentMutationV1062||null})};
  }
  const securedCallsign = await ensureProfile(req.sb, req.user);
  state = {
    ...state,
    accountOwnerId: req.user.id,
    accountOwnerEmail: req.user.email || null,
    profile: { ...(state.profile || {}), callsign: securedCallsign },
  };

  // V12: a coleta diária do clã é autoridade do servidor. Se um navegador ficou
  // aberto durante o reset, ele não pode sobrescrever a cobrança com um save antigo.
  let statePatch = null;
  const {data:serverSave,error:readError}=await readSaveForWrite(req);
  if(readError||!serverSave?.save_token)return res.status(503).json({error:'Leitura do save indisponível.',code:'SAVE_READ_UNAVAILABLE'});
  if(serverSave.receipt_error)return res.status(409).json({error:'Identidade de salvamento reutilizada.',code:serverSave.receipt_error});
  if(serverSave.replayed)return res.json({ok:true,replayed:true,state:serverSave.state,save_token:serverSave.save_token,updated_at:serverSave.updated_at});
  req.saveTokenV131=serverSave.save_token;
  if(Object.hasOwn(req.body,'expected_token') && req.body.expected_token!==req.saveTokenV131){
    if(!serverSave.baseline_state)return res.status(409).json({error:'Referência de save antiga. Sincronize o progresso.',code:'SAVE_REVISION_CONFLICT'});
    try{
      const draft=structuredClone(state),base=serverSave.baseline_state;
      // NPC/ore/collection/coupon commits already applied these gains. Never count
      // the same authoritative money/cargo a second time as a client delta.
      if(['serverPurchaseRevision','serverNpcRewardRevision','serverEliteRevision'].some(k=>Number(state[k]||0)>Number(base[k]||0)))for(const key of ['credits','uridium'])draft.profile[key]=base.profile?.[key]||0;
      if(['serverPurchaseRevision','serverOreRevision'].some(k=>Number(state[k]||0)>Number(base[k]||0)))draft.cargo=structuredClone(base.cargo||{});
      for(const key of ['serverPurchaseRevision','serverNpcRewardRevision','serverOreRevision','serverEliteRevision','serverStateClockV134','serverCheckpointReceiptV134'])draft[key]=base[key];
      state=mergePlayerStateV134(base,draft,serverSave.state);
    }
    catch{return res.status(409).json({error:'Outra operação alterou este setor. Reconciliando.',code:'SAVE_REVISION_CONFLICT'});}
  }
  if(serverSave.state){state.serverStateClockV134=serverSave.state.serverStateClockV134;state.serverCheckpointReceiptV134=serverSave.state.serverCheckpointReceiptV134;}
  // V106.2: saves de combate/farm nao podem alterar a montagem (CONF1/2,
  // nave, drones, AUX) sem uma intencao do hangar e baseline do servidor.
  // Mantem integralmente os validadores economicos, NPC, inventario e anti-fraude.
  // V118: layouts de drones vendidos nao sao equipamento valido. Normalizar
  // OS DOIS lados evita bloqueios falsos, sem liberar equipamento do cliente.
  const officialForGearV118=serverSave?.state?structuredClone(serverSave.state):null;
  if(officialForGearV118)pruneOrphanedDroneLayoutsV118(officialForGearV118);
  pruneOrphanedDroneLayoutsV118(state);
  const gearWriteV1062=validateEquipmentWriteV1062(officialForGearV118,state,req.body?.equipmentMutationV1062);
  if(!gearWriteV1062.ok){
    console.warn('[HANGAR_WRITE_GUARD_V1062]',gearWriteV1062.code);
    return res.status(409).json({
      error:gearWriteV1062.code==='SAVE_EQUIPMENT_STALE'?
        'Hangar alterado desde a ultima sincronizacao. Recarregue o save.':
        'Save sem acao de hangar tentou alterar equipamentos. Bloqueado para proteger sua montagem.',
      code:gearWriteV1062.code
    });
  }
  // V110: só salva os níveis de protocolos possuídos no servidor e configurações válidas.
  const auxValidationV110=validateAuxAdvancedSaveV110(serverSave?.state||null,state);
  if(!auxValidationV110.ok)return res.status(409).json({error:'Protocolos do AUX divergiram do servidor. Sincronize novamente.',code:auxValidationV110.code});
  // V108: finalizações/abates confirmados não podem retroceder e
  // prêmios exigem uma missão completa previamente salva no banco.
  const missionErrorV108=missionSaveGuardV108(serverSave?.state||null,state);
  if(missionErrorV108)return res.status(409).json({error:'Progresso de missão alterado no servidor. Reconciliando a conclusão antes do prêmio.',code:missionErrorV108});
  // Compras economicas confirmadas pelo Render nao podem ser desfeitas com save antigo.
  // O histórico idempotente de compras em lote é SEMPRE autoritativo do servidor.
  // Clientes legados que não possuem esse campo continuam compatíveis.
  if(serverSave?.state?.bulkPurchaseReceiptsV92)state.bulkPurchaseReceiptsV92=structuredClone(serverSave.state.bulkPurchaseReceiptsV92);
  else delete state.bulkPurchaseReceiptsV92;
  // V116.4: authoritative auto-trade receipts cannot be forged/erased by client PUT.
  if(serverSave?.state?.autoTradeReceiptsV1164)state.autoTradeReceiptsV1164=structuredClone(serverSave.state.autoTradeReceiptsV1164);
  else delete state.autoTradeReceiptsV1164;
  for(const key of ['natalTitleV132','natalBadgeV132']){if(serverSave?.state?.[key])state[key]=serverSave.state[key];else delete state[key];}
  const authoritativePurchaseRevision=Math.max(0,Number(serverSave?.state?.serverPurchaseRevision)||0);
  const incomingPurchaseRevision=Math.max(0,Number(state?.serverPurchaseRevision)||0);
  if(incomingPurchaseRevision<authoritativePurchaseRevision)return res.status(409).json({
    error:'Economia atualizada pelo servidor. Sincronize antes de salvar.',code:'SAVE_ECONOMY_STALE'
  });
  if(incomingPurchaseRevision>authoritativePurchaseRevision){
    await securityService.report(req.user.id,{code:'SAVE_PURCHASE_REVISION_FORGED',severity:'critical',evidence:{kind:'reserved_revision'}},'cloud_save');
    return res.status(409).json({error:'Revisao de compras invalida.',code:'SAVE_RESERVED_REVISION'});
  }
  // Recompensas NPC são escritas no save pelo PostgreSQL, nunca pelo navegador.
  const authoritativeNpcRevision=Math.max(0,Number(serverSave?.state?.serverNpcRewardRevision)||0);
  const incomingNpcRevision=Math.max(0,Number(state?.serverNpcRewardRevision)||0);
  if(incomingNpcRevision<authoritativeNpcRevision)return res.status(409).json({
    error:'Recompensas NPC atualizadas pelo servidor. Sincronize o save.',code:'SAVE_NPC_STALE'
  });
  if(incomingNpcRevision>authoritativeNpcRevision){
    await securityService.report(req.user.id,{code:'SAVE_NPC_REVISION_FORGED',severity:'critical',evidence:{kind:'npc_reward_revision'}},'cloud_save');
    return res.status(409).json({error:'Revisão NPC não autorizada.',code:'SAVE_RESERVED_REVISION'});
  }
  // Coletas de minério confirmadas pelo servidor não podem ser desfeitas por saves antigos.
  const authoritativeOreRevision=Math.max(0,Number(serverSave?.state?.serverOreRevision)||0);
  const incomingOreRevision=Math.max(0,Number(state?.serverOreRevision)||0);
  if(incomingOreRevision<authoritativeOreRevision)return res.status(409).json({
    error:'Minérios atualizados pelo servidor. Sincronize o save.',code:'SAVE_ORE_STALE'
  });
  if(incomingOreRevision>authoritativeOreRevision){
    await securityService.report(req.user.id,{code:'SAVE_ORE_REVISION_FORGED',severity:'critical',evidence:{kind:'ore_revision'}},'cloud_save');
    return res.status(409).json({error:'Revisão de minério não autorizada.',code:'SAVE_RESERVED_REVISION'});
  }
  // Recompensas Elite podem ser resgatadas enquanto há save em voo.
  // Um save velho jamais pode sobrescrever moedas e revisão confirmadas pelo SQL.
  const authoritativeEliteRevision=Number(serverSave?.state?.serverEliteRevision)||0;
  const incomingEliteRevision=Number(state?.serverEliteRevision)||0;
  if(incomingEliteRevision<authoritativeEliteRevision)return res.status(409).json({
    error:'SAVE_ELITE_STALE: sincronize as recompensas com o servidor.',code:'SAVE_ELITE_STALE'
  });
  for(const path of [['levelRewards','claimed'],['battlePass','claimedTiers'],['battlePass','premiumClaimedTiers']]){
    const old=serverSave?.state?.[path[0]]?.[path[1]]||{},next=state?.[path[0]]?.[path[1]]||{};
    if(Object.keys(next).some(k=>!Object.hasOwn(old,k)))return res.status(409).json({error:'Use o resgate confirmado pelo servidor.',code:'SAVE_SERVER_CLAIM_REQUIRED'});
  }
  const claimRollback=validateRewardClaimContinuity(state,serverSave?.state||null);
  if(claimRollback)return res.status(409).json({error:claimRollback.reason,code:claimRollback.code});
  const securityFinding=validatePlayerSave(state,serverSave?.state||null,{userId:req.user.id,isAdmin:false});
  if(securityFinding){const outcome=await securityService.report(req.user.id,securityFinding,'cloud_save');
    if(outcome?.auto_suspended)return res.status(403).json({error:'Conta temporariamente suspensa. Contate o suporte para revisão.',code:'ACCOUNT_BANNED'});
    return res.status(409).json({error:'SAVE REJEITADO: dados econômicos ou itens inválidos. Sincronize o progresso.',code:securityFinding.code});}
  const serverEconomy = serverSave?.state?.serverEconomy || {};
  const clientEconomy = state?.serverEconomy || {};
  const serverCollectionDate = String(serverEconomy.lastClanCollectionDate || '');
  const clientCollectionDate = String(clientEconomy.lastClanCollectionDate || '');
  if (serverCollectionDate && serverCollectionDate > clientCollectionDate) {
    const authoritativeCredits = Number(serverSave?.state?.profile?.credits ?? state?.profile?.credits ?? 0);
    state = {
      ...state,
      profile: { ...(state.profile || {}), credits: authoritativeCredits },
      serverEconomy: { ...clientEconomy, ...serverEconomy },
    };
    statePatch = { credits: authoritativeCredits, serverEconomy: state.serverEconomy };
  }

  const updated_at = new Date().toISOString();
  const error = await writeVerifiedSave(req,state,updated_at);
  if (error) {
    const message=String(error.message||'');
    if(message.includes('SECURITY_')){
      await securityService.report(req.user.id,{code:'SAVE_DB_GUARD',severity:'warn',evidence:{rule:(message.match(/SECURITY_[A-Z_]+/)||[])[0]||'DB_REJECT'}},'database_save');
      return res.status(409).json({error:'O servidor recusou dados inconsistentes do save. Sincronize seu jogo.',code:'SAVE_DB_GUARD'});
    }
    const codes=['SAVE_REVISION_CONFLICT','SAVE_REVISION_REQUIRED','SAVE_IDEMPOTENCY_ID_REUSED',
      'SAVE_NPC_STALE','SAVE_ORE_STALE','SAVE_COUPON_STALE','SAVE_EVENT_STALE','SAVE_ELITE_STALE','SAVE_RESET_STALE'];
    const conflict=codes.find(code=>code===error.code||message.includes(code));
    return res.status(conflict?409:503).json({error:conflict?'Sincronize o progresso do piloto.':'Gravação não confirmada. Tente novamente.',code:conflict||'SAVE_WRITE_UNAVAILABLE'});
  }

  // V118: profiles ja confirmado com game_saves na transacao unica.

  res.json({ ok: true, state:req.confirmedStateV134,save_token:req.confirmedTokenV131, updated_at:req.confirmedAtV134||updated_at, statePatch, ...(req.v119Revision!=null?{revision:req.v119Revision}:{}) });
})));


// ===================== V17.9.1 BOOTSTRAP-SAFE PLAYER LOCATION =====================
// A posição é crítica para o login, então o navegador fala apenas com o Render e o
// servidor faz a RPC autenticada no Supabase. Falha nessa rota nunca deve bloquear o mundo.
app.get('/api/player/location', requireUser, asyncRoute(async (req,res)=>{
  const {data,error}=await req.sb.rpc('get_my_player_location_v1774');
  if(error)return res.status(400).json({error:String(error.message||'Falha ao carregar posição.')});
  return res.json({location:data||null});
}));
app.post('/api/player/location', requireUser, asyncRoute(async (req,res)=>{
  const b=req.body||{};
  const {data,error}=await req.sb.rpc('save_player_location_v1774',{
    p_map_id:String(b.mapId||'x1'),
    p_territory_faction:b.territoryFaction==null?null:String(b.territoryFaction),
    p_x:Number(b.x||0),p_y:Number(b.y||0),p_angle:Number(b.angle||0),
    p_client_saved_at:Math.max(0,Math.trunc(Number(b.savedAt||Date.now())))
  });
  if(error)return res.status(400).json({error:String(error.message||'Falha ao salvar posição.')});
  return res.json(data||{ok:true});
}));

// Read-only relay ownership for clients whose PvP websocket has not joined yet.
// Uses the player's JWT + RLS. It NEVER accepts client-supplied capture/progress writes.
app.get('/api/world/sector-state',requireUser,asyncRoute(async(req,res)=>{
  const mapId=String(req.query.mapId||'');
  if(!['b41','b42','b43'].includes(mapId))return res.status(400).json({error:'Mapa de disputa inválido.',code:'INVALID_SECTOR_MAP'});
  const {data,error}=await req.sb.from('stellar_warfront_nodes').select('map_id,node_id,owner,revision,captured_at').eq('map_id',mapId).order('node_id');
  if(error){console.warn('[sector-read]',error.code||'database_error');return res.status(503).json({error:'Não foi possível consultar o domínio dos setores.',code:'SECTOR_READ_UNAVAILABLE'});}
  if(!Array.isArray(data)||data.length!==3)return res.status(503).json({error:'Setores ainda não inicializados no banco.',code:'SECTOR_DATA_MISSING'});
  res.setHeader('Cache-Control','no-store');res.json({ok:true,mapId,nodes:data});
}));
app.get('/api/world/status', (req, res) => res.json({ ok: true, version: RELEASE_VERSION, ...sharedUniverse.stats() }));
// V115: monitor de guerra disponível SOMENTE ao ADM, sem inventário ou dados pessoais.
app.get('/api/admin/v115/quality',requireUser,asyncRoute(async(req,res)=>{
  const {data:allowed,error}=await req.sb.rpc('is_game_admin_v1763',{p_uid:req.user.id});
  if(error||allowed!==true)return res.status(403).json({error:'Somente ADM.'});
  res.set('Cache-Control','no-store');res.json({ok:true,...competitiveQualitySummaryV115(sharedUniverse.stats())});
}));

const natalServiceV132=createChristmasService({service:requireEliteAdmin,ensureInactive:uid=>offlineFarmEnsureInactiveV484(uid,requireEliteAdmin)});
mountChristmasRoutes(app,{requireUser,asyncRoute,api:natalServiceV132,getWorld:()=>sharedUniverse});
app.get('*', (req, res) => res.sendFile(path.join(__dirname, '../public/index.html')));

app.use((err, req, res, next) => {
  console.error(`[${new Date().toISOString()}] ${req.method} ${req.path}`, err);
  if (res.headersSent) return next(err);
  const explicitStatus=Number(err?.status)||0;
  const isFetchError = /fetch failed|ENOTFOUND|ECONNREFUSED|ETIMEDOUT|UND_ERR/i.test(String(err?.message || err));
  const message = explicitStatus
    ? String(err?.message||'Operação recusada.')
    : isFetchError
      ? 'Falha ao conectar ao Supabase. Confira SUPABASE_URL e a Publishable Key no Render.'
      : 'Erro interno no servidor.';
  res.status(explicitStatus||502).json({
    error: message,
    detail: String(err?.message || err).slice(0, 240),
    diagnostics: configStatus(),
  });
});

const port = process.env.PORT || 3000;
const server = http.createServer(app);
const sharedUniverse = attachSharedUniverse(server, {natal:natalServiceV132,
  issueLoot:async(userId,dropId,mapKey,x,y,resources)=>{
    const db=await requireEliteAdmin();const {data,error}=await db.rpc('stellar_player_loot_issue',{p_user_id:userId,p_drop_id:dropId,p_map_key:mapKey,p_x:x,p_y:y,p_resources:resources});
    if(error)throw Error(error.message);return data;
  },
  loadWarbotConfig:async()=>{
    const sb=await requireEliteAdmin();
    const {data,error}=await sb.from('stellar_warbot_events_v477').select('map_id,enabled,mode,bots_per_faction,tier,attack_players,ends_at');
    if(error)throw new Error('SQL Warbot V47.7 indisponível');
    return data||[];
  },
  loadWarfront:async mapId=>{
    const sb=await requireEliteAdmin();
    const {data,error}=await sb.from('stellar_warfront_nodes').select('map_id,node_id,owner,revision,captured_at,captured_by').eq('map_id',mapId);
    if(error)throw new Error(error.message);
    if(!Array.isArray(data)||data.length!==3)throw new Error('Relés não inicializados no SQL.');
    // Compatible with the old database until the V34.6 SQL is applied.
    const [stateResult,moduleResult,rulesResult,balanceResult,fortResult]=await Promise.all([
      sb.from('stellar_relay_state_v346').select('*').eq('map_id',mapId),
      sb.from('stellar_relay_modules_v346').select('id,category,attribute,level,map_id,node_id,slot,clan_id').eq('map_id',mapId),
      sb.from('stellar_relay_rules_v346').select('*').eq('id',1).maybeSingle(),
      sb.from('stellar_relay_module_balance_v3463').select('*'),
      sb.from('stellar_relay_fortifications_v350').select('map_id,node_id,level').eq('map_id',mapId)
    ]);
    const missing=x=>/does not exist|schema cache|PGRST205|42P01/i.test(x?.message||'');
    if([stateResult,moduleResult,rulesResult].some(x=>x.error)){
      if([stateResult,moduleResult,rulesResult].every(x=>!x.error||missing(x.error)))return data;
      throw new Error([stateResult,moduleResult,rulesResult].find(x=>x.error)?.error?.message||'Falha nos relés');
    }
    const rules=rulesResult.data;
    return data.map(row=>({...row,relay:rules?.enabled===true?{
      ...(stateResult.data||[]).find(st=>st.node_id===row.node_id),
      modules:(moduleResult.data||[]).filter(m=>m.node_id===row.node_id),balance:balanceResult.data||[],
      level:Number((fortResult.data||[]).find(f=>f.node_id===row.node_id)?.level||1),rules
    }:null}));
  },
  readAstralCombatProfile:async userId=>{
    const {data,error}=await (await requireEliteAdmin()).rpc('stellar_u431_combat_profile',{p_user:userId});
    if(error)throw new Error('Perfil de combate indisponível.');
    return data;
  },
  readRelayLoadout:async userId=>{
    const {data,error}=await (await requireEliteAdmin()).from('game_saves').select('state').eq('user_id',userId).maybeSingle();
    if(error){const err=new Error('Equipamentos da nave não sincronizados.');err.code=error.code||'RELAY_LOADOUT_QUERY_FAILED';throw err;}
    if(!data?.state)throw Object.assign(new Error('Save de equipamentos ainda não disponível.'),{code:'RELAY_LOADOUT_SAVE_MISSING'});
    return data.state;
  },
  loadActorClan:async userId=>{
    const {data,error}=await (await requireEliteAdmin()).from('clan_members').select('clan_id').eq('user_id',userId).maybeSingle();
    if(error)throw new Error(error.message);return data?.clan_id||null;
  },
  damageRelay:async(mapId,nodeId,damage,userId)=>{
    const {data,error}=await (await requireEliteAdmin()).rpc('stellar_relay_damage_v346',{p_map_id:mapId,p_node_id:nodeId,p_damage:damage,p_attacker:userId});
    if(error)throw new Error(error.message);return data;
  },
  persistRelayCapture:async(mapId,nodeId,faction,revision,actorUserId)=>{
    const {data,error}=await (await requireEliteAdmin()).rpc('stellar_relay_capture_v346',{p_map_id:mapId,p_node_id:nodeId,p_faction:faction,p_expected_revision:revision,p_actor:actorUserId});
    if(error)throw new Error(error.message);const row=Array.isArray(data)?data[0]:data;
    if(!row||row.owner!==faction)throw new Error('Conquista não confirmada pelo banco');return row;
  },
  recordRelayPve:async(userId,key,kind)=>{
    const {error}=await (await requireEliteAdmin()).rpc('stellar_relay_record_pve_v346',{p_user_id:userId,p_event_key:key,p_kind:kind});
    if(error&&!/PGRST202|does not exist|schema cache/i.test(error.message))console.warn('[relay-pve]',error.message);
  },
  persistCapture:async(mapId,nodeId,faction,revision,actorUserId)=>{
    const sb=await requireEliteAdmin();
    const {data,error}=await sb.rpc('stellar_commit_warfront_capture',{
      p_map_id:mapId,p_node_id:nodeId,p_faction:faction,p_expected_revision:revision,p_actor:actorUserId
    });
    if(error)throw new Error(error.message);
    const row=Array.isArray(data)?data[0]:data;
    if(!row||row.owner!==faction)throw new Error('Captura não confirmada no banco.');
    return row;
  },
  recordWarDefense:async(mapId,nodeId,faction,actorUserId)=>{
    const sb=await requireEliteAdmin();
    const {data,error}=await sb.rpc('stellar_record_war_defense',{p_map_id:mapId,p_node_id:nodeId,p_faction:faction,p_actor:actorUserId});
    if(error)throw new Error(error.message);return data===true;
  },
  collectDrop:async(uid,body,sessionId,arrival)=>playerRewardsV134.collect(uid,body,sessionId,arrival),
  grantNpcReward:async(userId,killKey,npcType,baseCredits,baseStl,ownerEligible=false)=>{
    await offlineFarmEnsureInactiveV484(userId,requireEliteAdmin);
    const sb=await requireEliteAdmin();
    const grant=async()=>{
      const {data,error}=await sb.rpc(npcType.startsWith('natal')?'stellar_player_natal_npc':'stellar_player_grant_npc_reward',{
        p_user_id:userId,p_kill_key:killKey,p_npc_type:npcType,
        p_base_credits:baseCredits,p_base_stl:baseStl,p_owner_eligible:ownerEligible===true
      });
      if(error)throw new Error(String(error.message||'Recompensa NPC recusada'));
      if(!data||!Number.isSafeInteger(Number(data.revision))||Number(data.revision)<1)throw new Error('Recompensa NPC sem confirmação verificável.');
      return data;
    };
    // Consulta ledger somente na rara situação de timeout com commit anterior;
    // não adiciona consultas ao caminho normal de combate.
    const readReceipt=async()=>{
      const {data,error}=await sb.from('stellar_npc_reward_ledger').select('credits,stl')
        .eq('user_id',userId).eq('kill_key',killKey).maybeSingle();
      if(error)throw new Error('NPC_REWARD_RECOVERY_LEDGER_UNAVAILABLE');
      return data;
    };
    return grantNpcRewardSafelyV1069({grant,readReceipt});
  },
  grantOreReward:async(userId,oreKey,resource,amount,mapId)=>{
    await offlineFarmEnsureInactiveV484(userId,requireEliteAdmin);
    const sb=await requireEliteAdmin();
    let confirmedAmount=amount;
    // V34.6 bonus is read from persisted control; browser cannot self-assign ore bonuses.
    try{const {data:bonus,error:bonusErr}=await sb.rpc('stellar_relay_active_bonus_v346',{p_user_id:userId,p_map_id:mapId});
      if(!bonusErr&&bonus?.attribute==='resources')confirmedAmount=Math.min(1000,Math.max(1,Math.round(amount*(1+Number(bonus.value||0)/100))));
    }catch{}
    const {data,error}=await sb.rpc('stellar_player_grant_ore_reward',{
      p_user_id:userId,p_ore_key:oreKey,p_resource:resource,p_amount:confirmedAmount
    });
    if(error)throw new Error(String(error.message||'Coleta online recusada'));
    return data;
  },
  recordEliteEvent:async(userId,kind)=>{
    const sb=await requireEliteAdmin();
    const {error}=await sb.rpc('stellar_record_elite_event',{p_user_id:userId,p_kind:kind,p_amount:1});
    if(error)throw new Error(error.message);
  },
  loadWorldDirectives:async()=>{
    // A lista operacional vem do banco autenticado pelo servidor, nunca do cliente.
    if(!eliteAdminClient)return [];
    const now=new Date().toISOString();
    const {data,error}=await eliteAdminClient.from('stellar_world_directives')
      .select('id,title,description,map_id,category,starts_at,ends_at,enabled')
      .eq('enabled',true).lte('starts_at',now).gt('ends_at',now)
      .order('starts_at',{ascending:true}).limit(80);
    if(error)throw new Error(error.message);
    return data||[];
  },
  loadLiveOps: async(force=false)=>loadLiveOpsSnapshot(force),
  loadNpcConfig: async()=>loadNpcRuntimeSnapshot(false),
  loadWorldConfig: async()=>loadWorldRuntimeSnapshot(false),
  loadSystemsConfig: async()=>loadSystemsRuntimeSnapshot(false),
  loadPlayerEventProgress: async (token,eventId) => {
    const sb=supabaseForToken(token);if(!sb)return null;
    const {data,error}=await sb.rpc('get_my_galaxy_event_progress_v1826',{p_event_id:String(eventId||'')});
    if(error)throw new Error(error.message);return data;
  },
  recordPlayerEventProgress: async (token,eventId,amount) => {
    const sb=supabaseForToken(token);if(!sb)return null;
    const {data,error}=await sb.rpc('stellar_player_record_my_galaxy_event_progress',{
      p_event_id:String(eventId||''),p_delta:Math.max(1,Math.min(10000,Math.trunc(Number(amount)||1)))
    });
    if(error)throw new Error(error.message);return data;
  },
  loadBattleGroup: async (token) => {
    const sb=supabaseForToken(token);if(!sb)return null;
    const {data,error}=await sb.rpc('get_my_battle_group_v179');
    if(error)throw new Error(error.message);
    return data&&typeof data==='object'?data:null;
  },
  recordSecurityViolation:(userId,finding,source)=>securityService.report(userId,finding,source),
  authorizeJoin: async (token,userId) => {
    await offlineFarmEnsureInactiveV484(userId,requireEliteAdmin);
    const sb=supabaseForToken(token);if(!sb)throw new Error('Sem autenticação');
    const access=await accountAccessState(sb);if(access?.is_banned||access?.allowed===false)throw new Error('Conta suspensa');
    const {data,error}=await sb.from('game_saves').select('state').eq('user_id',userId).maybeSingle();
    if(error)throw new Error(error.message);
    const profile=data?.state?.profile||{};
    const {data:isAdmin,error:adminErr}=await sb.rpc('is_game_admin_v1763',{p_uid:userId});
    if(adminErr)throw new Error('Não foi possível validar permissões do setor.');
    return {faction:String(profile.faction||''),level:Math.max(1,Number(profile.level)||1),isAdmin:isAdmin===true};
  },
  authenticate: async (token, gameSessionId) => {
    if (!token || !gameSessionId) throw new Error('Sessão do universo ausente.');
    const base = supabaseBase();
    if (!base) throw new Error('Supabase indisponível.');
    const { data, error } = await base.auth.getUser(token);
    if (error || !data?.user) throw new Error('Sessão inválida.');
    const sb = supabaseForToken(token);
    const access=await accountAccessState(sb);
    if(access?.is_banned||access?.allowed===false)throw new Error('Conta banida.');
    const { data: sessionState, error: sessionError } = await sb.rpc('validate_game_session_v1214', {
      p_session_id: gameSessionId,
      p_touch: true,
    });
    if (sessionError || !sessionState?.valid) throw new Error('Sessão do jogo substituída.');
    const callsign = await ensureProfile(sb, data.user);
    const {data:savedProfile}=await sb.from('game_saves').select('state').eq('user_id',data.user.id).maybeSingle();
    const profile=savedProfile?.state?.profile||{};
    // Autorização do ADM vem do cadastro de roles no Supabase, nunca do callsign ou do cliente.
    const {data:isAdmin,error:adminErr}=await sb.rpc('is_game_admin_v1763',{p_uid:data.user.id});
    if(adminErr)throw new Error('Falha ao validar privilégios da conta.');
    return {user:data.user,callsign,accessToken:token,gameSessionId,faction:String(profile.faction||''),level:Math.max(1,Number(profile.level)||1),isAdmin:isAdmin===true};
  },
});


const topbarRefreshTimer=setInterval(()=>{
  refreshTopbarRuntimeSnapshot(false).catch(err=>console.warn('[topbar-runtime] refresh:',err.message));
},TOPBAR_RUNTIME_CACHE_MS);
topbarRefreshTimer.unref?.();
refreshTopbarRuntimeSnapshot(true).then(cfg=>console.log(`[topbar-runtime] v${cfg.version} cacheado em ${TOPBAR_RUNTIME_FILE}`)).catch(err=>console.warn('[topbar-runtime] bootstrap:',err.message));

const worldRefreshTimer=setInterval(()=>{
  refreshWorldRuntimeSnapshot(false).catch(err=>console.warn('[world-runtime] refresh:',err.message));
},WORLD_RUNTIME_CACHE_MS);
worldRefreshTimer.unref?.();
refreshWorldRuntimeSnapshot(true).then(cfg=>console.log(`[world-runtime] v${cfg.version} cacheado em ${WORLD_RUNTIME_FILE}`)).catch(err=>console.warn('[world-runtime] bootstrap:',err.message));

const npcRefreshTimer=setInterval(()=>{refreshNpcRuntimeSnapshot(false).catch(err=>console.warn('[npc-runtime] refresh:',err.message));},NPC_CONFIG_CACHE_MS);
npcRefreshTimer.unref?.();
refreshNpcRuntimeSnapshot(true).then(cfg=>console.log(`[npc-runtime] v${cfg.version} cacheado em ${NPC_RUNTIME_FILE}`)).catch(err=>console.warn('[npc-runtime] bootstrap:',err.message));

const shopsRefreshTimer=setInterval(()=>{refreshShopsRuntimeSnapshot(false).catch(err=>console.warn('[shops-runtime] refresh:',err.message));},SHOPS_RUNTIME_CACHE_MS);
shopsRefreshTimer.unref?.();
refreshShopsRuntimeSnapshot(true).then(cfg=>console.log(`[shops-runtime] v${cfg.version} cacheado em ${SHOPS_RUNTIME_FILE}`)).catch(err=>console.warn('[shops-runtime] bootstrap:',err.message));

// V36: at most one lightweight SQL tick per 60s, only while clients are online.
// Never recompute defensive capacity on frames or client fire events.
let dominionRegenInFlight=false;let dominionSqlWarned=false;
const dominionRegenTimer=setInterval(async()=>{
 if(!eliteAdminClient||dominionRegenInFlight||sharedUniverse.stats().clients===0)return;
 dominionRegenInFlight=true;
 try{const {error}=await eliteAdminClient.rpc('stellar_dominion_regen_v360');
  if(error&&!/PGRST202|42883|schema cache/i.test(String(error.message||''))&&!dominionSqlWarned){dominionSqlWarned=true;console.warn('[dominion-regen]',String(error.message||'').slice(0,150));}
 }catch(err){if(!dominionSqlWarned){dominionSqlWarned=true;console.warn('[dominion-regen]',String(err?.message||err).slice(0,150));}}
 finally{dominionRegenInFlight=false;}
},60000);
dominionRegenTimer.unref?.();
server.listen(port, () => {
  console.log(`Stellar Legacy ${RELEASE_VERSION} :${port}`);
  console.log('Supabase config:', configStatus());
  console.log('Shared Universe: ONLINE');
});


