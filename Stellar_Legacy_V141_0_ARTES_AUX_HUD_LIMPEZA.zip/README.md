V141.0 incremental sobre V140 / 47.7.72. Use o workflow universal. Leia README_V141_0.md. Sem SQL novo.
