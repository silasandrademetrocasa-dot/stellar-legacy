# STELLAR LEGACY V122.0 — UM DEPLOY, V121.0 A V122.0

Instale somente este ZIP no Instalador Universal do GitHub.
Base obrigatória: package.json version 47.7.60. Versão resultante: 47.7.61.
Inclui todos os arquivos alterados da V121.0, V121.1 e V122.0.

O que mudou: IndexedDB local-first, outbox de Hangar com substituição de intenções antigas, save de compatibilidade localStorage agrupado por 2s, 5s de sincronização em primeiro plano APENAS para pendências críticas, retry progressivo, retomada ao reconectar, sem duplicar writers HTTP, quatro chamadas redundantes de Hangar removidas.

O que NÃO mudou: compras, créditos/STL, leilão, PvP e recompensas permanecem validados no Render/Supabase; não existe cutover financeiro ou exclusão de jogador. Não executar SQL. Manter STELLAR_SAVE_V119_MODE=observe. Reversão ?localfirst=0 ou rollback do commit.

Detalhes: docs/V122_0_CUMULATIVA_LOCAL_FIRST.md.
