# STELLAR LEGACY V48.2.1 — PACOTE ÚNICO FINAL (FIX DE VALIDAÇÃO) (para Instalador Universal)

**Substitui V48.1, V48.1.1 e V48.1.2 anteriores.** Carregar este ZIP **uma única vez** na raiz do GitHub e rodar o Instalador Universal depois que a sessão de farm estiver encerrada. Este arquivo NÃO contém o jogo inteiro: é um **patch incremental completo para as modificações V48.1–V48.2**, baseado no Stellar Legacy já instalado.

## Incluído no mesmo ZIP

1. **V48.1**: menu superior compacto PILOTO → MISSÕES → BATALHA → MAPA → MAIS; HUD e COMPACTO em MAIS → INTERFACE; Autopilot em PILOTO para quem tem direito; UNIVERSO LV10 com exceção ADM. Mantém menus originais e seus handlers, sem botão flutuante sobre o minimapa.
2. **V48.1.1**: Missões, tutorial e Passe visíveis LV1; pontos do Passe a partir do LV2; missões diárias LV3, semanais LV5, mensais LV7, especiais LV10; tutorial descreve a liberação semanal no LV5. SQL da configuração online está incluído separadamente.
3. **V48.1.2**: Autopilot revalida acesso ao reabrir depois de pausa; prioridades loot de NPC (atirando contra inimigos em alcance) → NPCs → BOX bônus → mineração. Sem modificar permissões ou vendas.
4. **V48.2**: painel PILOTO com nome sem rótulo "JOGADOR", patente, CR, STL, nível e barra de XP acumulado/necessário; painel NAVE com barras HP, escudo e porão, velocidade por último e nome da nave. DOM atualizado sem remover os IDs que o jogo usa.
5. **Curva híbrida de piloto V48.2**: LV1→2 10k, 2→3 20k, 3→4 40k etc. (dobro até LV7→8); LV8→20 valores acordados; LV20→44 crescimento incremental de 11,5% por nível. Máximo LV44. Detalhes em `public/level-curve-v482.js` e testes.
6. **Migração por conta automática ao login**: preserva o nível e percentual do nível anterior, converte o XP acumulado uma única vez (`xpModelV482`), sem conceder recompensas adicionais, sem sobrescrever inventário, leilão ou saldos. Preserva sistemas anti-fraude.
7. **Auditoria**: `docs/AUDITORIA_FARM_2026_10_22.md` registra diferenças de XP/kills/BOX verificadas entre histórico e save. Não há manipulação automática desses números enquanto causa não foi isolada.

## Ordem segura de publicação

1. Fazer backup do banco e evitar jogadores ativos na janela de atualização, especialmente porque a curva de XP muda.
2. **Instalar este único ZIP** com Instalador Universal e aguardar validação do GitHub Actions.
3. Depois do deploy, aplicar manualmente **`sql/STELLAR_V48_1_1_MISSOES_PASSE_NIVEIS.sql`** no Supabase SQL Editor. É idempotente e altera apenas metadados de liberação de UI e categorias, não saves. O instalador NÃO roda SQL automaticamente.
4. No primeiro login após o deploy, o cliente converte o XP armazenado do jogador de V46 para V48.2. Testar LV1/LV2/LV3/LV10, o andamento de XP após refresh, HUD recolhido, botão do Autopilot após 80 s, loot atirando contra NPCs, e habilidades de ADM.
5. No endgame (LV44), excedente de XP é escalado pela última faixa, mantendo LV44 e posição relativa; nenhum ganho artificial.

## Testes

`node scripts/v482-hud-xp-patch.mjs` deve rodar automaticamente no `npm run check`, **após** os scripts da V48.1/V48.1.1. O script é idempotente. A suíte adicional verifica sequência LV1–LV20, curva LV21–44, migração de 44 níveis, HUD e elementos originais. Executar Actions no GitHub para validação completa; testes locais não garantem Render.

**Nenhum deploy no GitHub/Render/Supabase é feito pela criação deste ZIP.**

## Hotfix V48.2.1 (22/10/2026)

- Corrigido `?v=48.2.0` no import de `level-curve-v482.js` do `public/game.js`, que não atende à exigência do `scripts/verify-release.mjs`.
- A versão-base de `package.json` **continua 47.7.6**; o identificador de cache no `game.js` agora segue essa versão.
- Ajuste idempotente: corrige instalações parcialmente aplicadas em uma execução anterior e também instalações limpas.
- Se a V48.2 falhou no Actions, retire o ZIP antigo da raiz e envie **somente este ZIP corrigido**; rode o instalador e confira a etapa de validação antes de aplicar o SQL.

## V48.2.2 — Hotfix CI: 431 testes
- Atualiza o teste legado do Autopilot para a regra aprovada: NPCs antes de BOX bônus, mas loot real pode ser coletado com tiro simultâneo em NPC ao alcance.
- Atualiza o teste de regressão do V46 para confirmar a migração V46→V48.2 e a nova curva, preservando mundo, portais, economia, eventos e saves.
- Não enfraquece a validação; os novos testes incluem asserts explícitos dos recursos aprovados.
- Não modifica dados de jogadores e não exige SQL adicional além do SQL já incluído na V48.2.
