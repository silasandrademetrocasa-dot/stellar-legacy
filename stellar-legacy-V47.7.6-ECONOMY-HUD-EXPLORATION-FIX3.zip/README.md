# Stellar Legacy V47.7.6 — POLISH / ECONOMY LOCK

Patch ZIP incremental for the working GitHub version **47.7.5**. Upload exactly one ZIP to the repository root and run the established Universal Installer. Requires the V47.7.5 release already published.

Changes:
- NPC selected Target Lock restored to readable ~176px collapsed panel, with visible expand toggle.
- Boss/phase/Fury panel has a user-controlled, persistent collapse toggle that does not cover central AUX controls.
- Standard browser confirmations in main game, unified universe/market panels replaced with asynchronous, game-styled prompts, including important ADM confirmation flows. No browser `confirm` blocks the main thread.
- Unified operations/exploration no longer reload or disconnect the current game, and synchronize economy before/after remote writes.
- **Server-authoritative resale**: CR-purchased equipment returns **half the catalogue price in CR**. Elite / STL-priced equipment and drones return **the numeric catalogue price in CR only**, with *zero STL refunds*, even for auctioned or rewarded Elite equipment. Client shows the same expected price and currency.
- Items with no current enabled official shop resale quote, such as event-only `repPrime`, are marked unavailable rather than receiving fabricated prices. It must be assigned an official catalogue price by ADM if resale is desired. Equips can only be sold at the player's own safe base as before.
- No changes to existing live database schema, user saves, progression, NPC/bot FPS settings, combat physics, credits balances, clanship or relays.

Validation: `node --test tests/stability-economy-v4776.test.mjs`, `node --check` new files; full remote `npm test`/installer and live mobile interactions are pending GitHub deployment.

## FIX de instalação (V47.7.6)
- Os imports de `sale-policy-v4776.js` e `stellar-dialog-v4776.js` no `public/game.js` agora levam `?v=47.7.6`, conforme exigido pelo verificador oficial.
- Os painéis secundários também importam o novo módulo de diálogo com o cache-busting correspondente.
- O teste novo deixou de esperar `stellar-install.json` dentro do repositório, pois o Instalador Universal consome esse manifesto sem instalá-lo.
- O migrador não altera os testes específicos desta nova versão e aceita reaplicação de suas próprias transformações de confirmações e rótulos de venda.
- O código foi verificado com `node --check` e os testes isolados foram executados. A suíte completa do GitHub e o uso no servidor são verificações posteriores ao envio deste ZIP.

## FIX3 — Teste legado do Hangar (2026-10-21)
O GitHub Actions passou 380 de 381 verificações com o FIX2, mas o teste
`tests/hangar-pro-v3040.test.mjs` ainda exigia literalmente `window.confirm`.
Como a substituição por um modal assíncrono é intencional, o FIX3 atualiza o
teste legado para exigir `stellarConfirmV4776` antes de modificar o
inventário (e verificar que o jogador pode cancelar), sem suprimir a
proteção do preset. Este ZIP mantém todos os arquivos da V47.7.6/FIX2.
Não requer SQL, migração de contas ou mudança de saldos. O resultado final
da suíte completa só será confirmado após executar no GitHub Actions.
