# Stellar Legacy V118.2 — Leilão transacional e mensagens de erro

Este é um PATCH incremental para instalar sobre a V118.1 com o Instalador Universal.

## Alterações
- Lance vencedor: verificação no servidor e cobrança+entrega+recibo+status dentro de uma única transação Postgres. Erros impedem a marcação de vitória e revertem todas as alterações.
- Pedido repetido: recibo único por lance; uma resposta perdida não cobra nem entrega duas vezes.
- Frota cheia, saldo insuficiente, lance superado e produto sem cotação: mensagens em português e sem cobrança.
- Os resultados de protocolos AUX já usam RPC próprio e não foram alterados.
- Código do cliente não entrega produtos nem marca status de vitória.
- Mensagens genéricas de erro de save/compra têm instruções compreensíveis, sem códigos internos do banco.
- Cache-bust da entrada do jogo para forçar atualização do navegador após o deploy.
- Proteções anteriores de saves A/B/C, drones e Farm Offline preservadas.

## Ordem
1. Aplicar `sql/STELLAR_V118_2_LEILAO_TRANSACIONAL.sql` no Supabase primeiro. **No ambiente Galácticos, a migração já foi aplicada e validada**; NÃO é necessário rodar de novo.
2. Enviar apenas este ZIP à raiz do repositório e executar o Instalador Universal.
3. Esperar o Render marcar Live e reabrir a página/PWA.
4. Homologar uma premiação de lote barato com saldo e vaga adequados. Conferir status `won`, recibo na tabela `stellar_auction_settlements_v1182`, saldo e item no `game_saves`, perfil e A/B/C.

## Leilão antigo do Nova, 03/11 às 03h
O lance das 03h do The Devil of Dead havia sido marcado `won` sem entrega identificável. Em 03/11/2026, fiz uma **recuperação administrativa pontual no Supabase**: um Nova foi acrescentado com dois slots vazios, **sem nova cobrança**, porque o débito antigo não era verificável. A recuperação recebeu recibo único para o lance, com motivo `legacy_win_missing_delivery`. Após a operação, havia **7 Novas**, créditos inalterados e as três cópias A/B/C válidas. O SQL documental está em `docs/v1182/RECUPERACAO_NOVA_EXECUTADA.sql`. **Não execute esse SQL novamente.** Esta recuperação não substitui os testes da liquidação futura.

## Segurança
Nenhum SQL é executado automaticamente pelo ZIP. Nenhum item/saldo é editado ao instalar. O teste automatizado não substitui a homologação de um lance real no Render.

## Testes
497/497 testes automatizados aprovados; Instalador Universal simulado: 6 arquivos aplicados, nenhum removido. Uma liquidação real de lote da versão nova ainda precisa ser homologada.
