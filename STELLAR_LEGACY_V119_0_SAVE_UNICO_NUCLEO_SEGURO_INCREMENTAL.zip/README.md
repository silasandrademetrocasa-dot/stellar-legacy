# STELLAR LEGACY — V119.0 | NÚCLEO DE SAVE ÚNICO (ETAPA DE PREPARAÇÃO)

## IMPORTANTE

Esta entrega **NÃO habilita automaticamente o novo motor de gravação**. O código do Render permanece no modo seguro `observe`, sem trocar o caminho atual V118. É necessário concluir a migração e homologação das rotinas antigas ANTES de usar `STELLAR_SAVE_V119_MODE=enforce`.

NÃO apagar saves existentes, não restaurar A/B/C diretamente, não executar estas alterações enquanto houver Farm ativo e não fazer testes de carga no banco de produção sem backup recente.

### Entregue nesta etapa

- `game_saves` permanece como a única fonte canônica de estado jogável.
- Revisions por conta e hash do save (somente metadados).
- Journal de alterações identificado por módulos, consultável apenas pelo titular autenticado através do Render (sem dados financeiros detalhados no log).
- Snapshots A/B/C universais e validados com hash, derivados de qualquer commit em `game_saves`, inclusive NPC/minério e RPCs antigas (após ativar o trigger).
- Gate opcional para operações de save com ID de idempotência, verificação da revisão esperada e confirmação da V118 dentro de uma transação.
- Leitura atômica de estado e revisão; código cliente passa ID estável por tentativa.
- Scripts SQL separados para preparar, ativar, conferir e desativar sem apagar histórico.
- Testes unitários novos e todos os testes anteriores preservados.

### O que esta versão NÃO entrega ainda

1. Não migra automaticamente as mais de 20 RPCs legadas (Farm, NPC, missões, clã, cupons etc.) para o novo comando central.
2. Não elimina toda disputa entre clientes antigos e commits NPC em alta frequência. O modo `enforce` deve permanecer DESLIGADO até as ações passarem a enviar apenas comandos tipados, sem valores finais de inventário e moeda.
3. Não recupera progresso perdido ou prêmios antigos por conta própria.
4. Não foi testada com transações reais do Supabase; os testes locais não substituem homologação de produção.

### Ordem para homologação segura

1. Backup fresco de `game_saves`, `profiles`, ledgers e Farm. Checar nenhum Farm ativo.
2. Em Supabase de homologação, executar `sql/STELLAR_V119_0_SAVE_UNICO_PREPARAR.sql`.
3. Conferir contagem de saves, hashes, revisão e autorizações com `sql/STELLAR_V119_0_CONFERIR.sql`.
4. Executar `sql/STELLAR_V119_0_ATIVAR_AUDITORIA.sql` **somente em homologação**. Simular recompensa NPC, equipamento, leilão e Farm atravessando meia-noite. Avaliar tempo de banco e custo por commit.
5. Instalar este ZIP pelo Instalador Universal no repositório de TESTE e validar `npm run verify`. No Render, manter `STELLAR_SAVE_V119_MODE=observe`.
6. Migrar e testar regras de cada módulo para comandos no mesmo fluxo, antes de habilitar `enforce` numa conta de teste e só depois abrir para todas.
7. Em caso de aumento de falhas ou latência, `sql/STELLAR_V119_0_DESATIVAR_AUDITORIA.sql` desabilita o gatilho sem apagar os dados auditados.

**Nenhum SQL é aplicado automaticamente pelo ZIP.**
