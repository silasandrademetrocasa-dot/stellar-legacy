# Stellar Legacy V42.6.1 — Correção ADM e sessão

Base obrigatória: **42.6.0**. Destino: **42.6.1**.

- Corrige `Sessão ausente` nos painéis Astral Rewards e Universo: todos os módulos usam a MESMA instância de `/api.js?v=42.6.1` do jogo.
- O editor Astral Rewards exibe carregamento/erro e atualiza ao abrir/salvar.
- Trocar Aurora/Nexus/Eclipse atualiza o preview do portal mesmo quando outra requisição estiver em andamento.
- No ADM, selecionar Aurora/Nexus/Eclipse solicita atualização do runtime existente automaticamente.
- Sem alterações SQL; preserva saves, recursos, recompensas e regras econômicas.

## Instalar

1. O projeto no GitHub precisa estar na versão 42.6.0 (`package.json`).
2. Remova ZIPs antigos da raiz do repositório e envie somente este arquivo.
3. Execute **Actions > Instalador Universal > Run workflow**.
4. Valide: login, Astral Rewards ADM, troca Aurora/Nexus/Eclipse, Universo Estelar.

O script `scripts/v4261-apply-patch.mjs` é executado pela etapa `npm run check` do instalador; é idempotente e aborta se algum ponto de integração esperado não existir.
