STELLAR LEGACY V111.0 • AUX ECONOMIA, LOJA, LEILÃO E ADM

Instalar sobre a V110.2 pelo workflow Instalador Universal do GitHub.
No GitHub, manter um único ZIP na raiz.
SQL de mercado e leilão JÁ FOI APLICADO no Supabase do projeto stellar-legacy.
NÃO executar novamente o arquivo SQL aplicado (contém ALTER FUNCTION).
Não altera server/world.js nem recompensas NPC V1069.
As operações de leilão exigem jogador autenticado e são transacionadas no banco.

Validação local do ZIP não equivale a confirmação de deploy no GitHub/Render; testar conta no jogo.
