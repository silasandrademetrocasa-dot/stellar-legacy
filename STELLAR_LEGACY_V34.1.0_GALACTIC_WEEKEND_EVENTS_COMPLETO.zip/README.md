# Instalador Universal Stellar Legacy

Substitua **somente** `.github/workflows/stellar-installer-main.yml` e adicione `scripts/stellar-universal-installer.py` ao GitHub **uma única vez**. Depois, o fluxo automático aceita um ZIP por execução, na raiz do repositório.

**ZIP completo**: contém `package.json`, `public/game.js`, `public/api.js`, `public/data.js`, `server/index.js`. Detectado automaticamente como `full`; arquivos antigos em `public/`, `server/`, `sql/` e `tests/` que não aparecem no ZIP serão excluídos. NÃO envia `.github` no pacote.

**ZIP de atualização**: inclui `stellar-install.json` com `{"type":"update","baseVersion":"30.1.2"}` e os arquivos alterados. Preserva todos os arquivos não citados.

**Patch**: arquivos alterados sem manifesto são detectados como `patch`; não apaga outros. Adicione `stellar-install.json` com `{"type":"patch","baseVersion":"30.1.2","delete":["public/arquivo-antigo.js"]}` para exclusões explícitas. O campo `baseVersion` é opcional, mas recomendado.

**Versões:** não edite `package.json` em patch apenas para mudar o número se `public/index.html`, `server/index.js` e imports ainda estiverem na versão antiga; a verificação de release bloqueará o deploy. Pacotes completos devem manter todas as referências sincronizadas.

**Segurança:** bloqueia traversal, symlink, sobrescrita de `.github` e do próprio instalador; limita tamanho expandido; valida sintaxe, consistência do release e testes antes de publicar. `git push` só ocorre após validações. Como qualquer workflow GitHub, esta instalação não é uma transação atômica contra falhas na etapa final de push.


- **V32.1.8**: ajuste visual da zona neutra do portal: raio aumentado para melhorar a área segura ao redor do portal e aro tracejado bem mais transparente para não poluir a tela.

- **V32.1.8**: Mobile Experience Pro 2.0: landscape-first, 3 colunas no HUD inferior, hangar horizontal responsivo e convite não bloqueante a girar a tela.

- **V32.1.8**: chat com altura igual à do minimapa e envio de mensagens acessível no horizontal; nomes PLS/SIP/CMT no HUD; nomenclatura Stellar na coleta dos minérios (online, AUX e nave); radar no landscape limitado a 10 atualizações por segundo para reduzir custo gráfico. IDs internos e SQL preservados.


**V34.1.0 — Galactic Expansion (integração para testes):** ver `V34_RELEASE_NOTES.md` para mudanças e limitações.
