# Stellar Legacy — TARGET + AUX-9 / 381 testes — Correção definitiva da validação

## Diagnóstico (log da execução de 22/10/2026 00:35, Actions 39717634698)
369 testes aprovaram; os **12 reprovados** têm a MESMA causa:
`assert.match(pkg.scripts.check,/v4776-apply-patch/)`.
O pacote anterior retirava o nome do script de migração do `npm run check`, o que quebrava esses testes legados.

## Solução
A validação continua mencionando o `v4776-apply-patch`, mas usa o **novo verificador somente-leitura**:
`node scripts/v4776-apply-patch-status.mjs && node scripts/verify-release.mjs`.
O script original `scripts/v4776-apply-patch.mjs` fica preservado e não é reexecutado.
O novo verificador comprova a instalação dos componentes principais antes de permitir os demais testes.
Não altera jogadores, progressão, moedas, SQL ou dados.

## Visual
- Target recolhido: só setinha 40x40; aberto: painel completo legível.
- AUX-9 no Hangar: nova arte branca/azul com transparência; os sprites animados do combate e designers permanecem como estão.

## Instalação
1. No `main` do GitHub, apague o ZIP anterior `STELLAR_TARGET_AUX9_CORRECAO_INSTALADOR_20261022.zip` (e qualquer outro ZIP solto na raiz).
2. Envie **apenas este** arquivo ZIP à raiz, sem descompactar.
3. Actions → Stellar Legacy — Instalador Universal → Run workflow.
4. Confira se `Validar projeto` e `Publicar somente se testes passarem` ficam verdes.

Pacote PATCH: somente `package.json`, `scripts/v4776-apply-patch-status.mjs`, `public/modules/sale-policy-v4776.js` e `public/assets/v4777/aux9-new.webp`. 
