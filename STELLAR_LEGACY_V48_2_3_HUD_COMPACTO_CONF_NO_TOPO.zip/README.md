# Stellar Legacy V48.2.3 — Hotfix compacto PILOTO e NAVE

**Pré-requisito:** V48.2.2 instalada, `package.json` versão `47.7.6`.

Este ZIP é um **patch incremental** para a instalação atual (não é o jogo inteiro). O Instalador Universal substitui apenas `public/modules/pilot-ship-hud-v482.js` e `public/modules/pilot-ship-hud-v482.css`, preservando toda a V48.2.2, missões, passe, curva de XP, autopilot e saves.

## Layout

- PILOTO: mostra `LV 2 : 27.424 / 30.000 XP` **dentro** da barra de XP; nome, patente, CR e STL mantidos.
- NAVE: cabeçalho `PIONEER [CONF 1] [CONF 2]`, sem `NAVE` nem `NAVE ATUAL`.
- HP / ESC / PORÃO: os valores ficam dentro das barras coloridas; velocidade embaixo.
- Os botões são os mesmos IDs `battleConf1`/`battleConf2` já conectados ao `switchBattleConfigV2013` do jogo, com cooldown de cinco segundos e sem recolher o card quando clicados.
- Painel compacto, sem crescer para baixo e mantendo o botão de expandir/recolher.

## Instalação

1. Remova o ZIP usado anteriormente da raiz do GitHub.
2. Envie **apenas** este ZIP para a raiz do repositório.
3. Rode `🚀 Stellar Legacy — Instalador Universal` e confirme a conclusão com sucesso.
4. Aguarde o deploy do Render e recarregue a página sem cache antigo.

**SQL:** não é necessário. Não altera banco, contas ou progressão.
