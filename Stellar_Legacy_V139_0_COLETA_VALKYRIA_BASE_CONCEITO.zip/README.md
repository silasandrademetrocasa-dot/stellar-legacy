V139 sobre V138 completa (47.7.70). SQL já aplicado. Execute o workflow universal. A base natalina está apenas em conceito, para aprovação. Detalhes: README_V139_0.md.
