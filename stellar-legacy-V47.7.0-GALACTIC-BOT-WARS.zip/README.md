# STELLAR LEGACY V47.7 — GALACTIC BOT WARS

**Base exigida:** V47.0.0 (não use sobre V46). **Entrega incremental (PATCH)**: NÃO extrair o ZIP substituindo o projeto inteiro.

## Ordem de instalação
1. Execute **sql/STELLAR_V47_7_GALACTIC_BOT_WARS.sql** no Supabase SQL Editor. Ele só cria a tabela de configurações; todos os três mapas começam DESLIGADOS.
2. Envie somente o ZIP na raiz do GitHub e execute o workflow **Stellar Legacy — Instalador Universal**. O installer aplica os 4 módulos + script + testes, roda `npm run check` (que integra os módulos) e `npm test`; só publica se validar.
3. No jogo, ADM > EVENTOS > GALACTIC BOT WARS, configure o mapa 4-1, 4-2 ou 4-3, modo TREINO/CONQUISTA, bots por facção (1–4), dificuldade (1–3), duração 5–120 minutos e se bots atacam pilotos no modo CONQUISTA. Clique ATIVAR ou DESLIGAR.

## Regras de segurança
- Os bots são entidades temporárias controladas pelo servidor, apenas nos mapas b41/b42/b43. No máximo 12 bots por mapa e 36 caso os três mapas sejam ativados.
- Inativos por padrão; expiram automaticamente (até 120 min). Com SQL ausente, permanecem DESLIGADOS (fail closed).
- TREINO: o bot recebe tiros e devolve apenas aviso de dano simulado (sem tirar escudo/HP real). Não existe loot, XP, moedas, passe, kill, contagem de missões ou progresso por destruir bots.
- CONQUISTA: os bots lutam próximos aos relés A/B/C; não os capturam autonomamente, porque a posse real exige validação de jogador e COMMIT no banco. O ADM pode habilitar ataques reais contra pilotos.
- Ao fechar o mapa sem jogadores a sala conserva a política existente de encerramento: os bots não rodam 24h em background. A configuração permanece até o horário de término.
- Recursos de treino/bots não são NPCs de farm. Recompensas, clãs, balanços, saves e portais não são alterados.

**Importante:** código testado em simulação isolada. Verifique o resultado do GitHub Actions antes de considerar publicado.
