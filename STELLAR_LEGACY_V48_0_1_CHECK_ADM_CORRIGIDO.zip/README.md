# Stellar Legacy — Hotfix V48.0.1: Check AUTOPILOT no ADM

## Motivo

O modulo V48 consultava `refreshAccess()` durante o primeiro carregamento do painel ADM. Como o login ja iniciava essa consulta em paralelo, uma segunda chamada recebia `false` imediatamente e os checks eram ocultados. Quando a leitura de `/api/admin/autopilot/v48/grants` falhava, a rotina tambem retornava sem mostrar qualquer mensagem.

## Correcoes

- Controles aparecem em `ADM > JOGADORES` para todas as contas comuns, abaixo de BANIR/ZERAR/DELETAR.
- A montagem do painel usa a validacao de ADM ja realizada pelo proprio painel; a API continua sendo a autoridade final para ler e alterar permissoes.
- Enquanto a leitura esta em andamento, o check fica desabilitado com status `Consultando permissao...`.
- Em caso de falha, mostra mensagem do servidor e `TENTAR NOVAMENTE`, sem alterar o estado de acesso.
- Ao carregar, informa `LIBERADO` ou `BLOQUEADO` de acordo com o servidor.
- Ao mudar o check, aguarda a resposta do servidor; nao anuncia sucesso antes da confirmacao.
- Protege o ADM FELP22 e outros administradores: sem check, pois o acesso deles ja existe por regra do servidor.
- Estilos mobile mais legiveis; evita linhas ocultas por inconsistencias de layout.

## Instalacao

Coloque **apenas** este ZIP na raiz do GitHub e execute `Stellar Legacy — Instalador Universal`. O ZIP substitui um unico arquivo do frontend e adiciona um teste. Nao exige SQL, reconfiguracao de Render ou reset de conta.

## Teste

Abra ADM > JOGADORES. Confira um jogador comum e veja `Liberar AUTOPILOT`. Se o banco estiver indisponivel, aparecera um erro com retry (nao desaparecera silenciosamente). Ao marcar/desmarcar, confirme `LIBERADO/BLOQUEADO` e confira numa sessao desse jogador.

Validado localmente por teste automatizado que simula GET indisponivel, retry, leitura bem sucedida e PUT confirmado.
