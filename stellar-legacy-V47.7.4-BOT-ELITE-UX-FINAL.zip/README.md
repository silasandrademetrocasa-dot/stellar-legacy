STELLAR LEGACY — V47.7.4 • BOT ELITE POLISH + FRONTIER U-X FIX
===============================================================
PATCH INCREMENTAL | Base: V47.7.3 | SQL: NENHUM

AJUSTES:
1. BOTS: velocidade reduzida, distância de combate mais curta (115-205 unidades por função), órbita menor e retirada apenas em emergência grave. A decisão e sincronização permanecem a cada 150 ms. Dano, recarga, quantidades, defesa em bases, loot/recompensas e conquista dos relés permanecem iguais.
2. VISUAL: utiliza os sprites Prime/Elite já incluídos no jogo, `colossar-prime.webp`, `dreadnox-prime.webp` e `kharon-prime.webp`. A orientação replica o mesmo ângulo de sprites usado em `drawEnemy()` dos NPCs de combate; sem introduzir arquivos de imagem ou sombras pesadas.
3. U-1/U-2/U-3: quando o cliente ainda não carregou o privilégio ADM, consulta uma rota autenticada que verifica a MESMA permissão de administrador usada pelo WebSocket. O servidor valida a permissão novamente ao conectar. Setores neutros previamente registrados aceitam carregamento anterior ao catálogo remoto; setor explicitamente desabilitado continua bloqueado.
4. U-X NPCs: atualiza a população de uma sala vazia também após carregar as configurações de NPCs. Spawns administrativos desabilitados continuam respeitados. Ao negar acesso, não declara conexão bem-sucedida.
5. FPS: mantém o mesmo teto de até 120 no modo BAIXA, o mesmo ritmo de 150 ms dos bots e as mesmas otimizações gráficas da V47.7.3.

INSTALAÇÃO:
- Remova da raiz do repositório qualquer ZIP antigo, envie apenas `stellar-legacy-V47.7.4-BOT-ELITE-UX-FINAL.zip`.
- Execute GitHub Actions / Instalador Universal; confirme npm run check, npm test e Render.
- SQL NÃO necessário: nenhum esquema, permissão SQL, save, credencial ou saldo foi modificado.
- No jogo: em U-1 use UMA conta realmente autorizada pelo servidor como game_admins.role='admin'; valide os NPCs aparecendo. Teste novamente como jogador comum de nível insuficiente: acesso deve ser negado.
- No PvP: ative bots no ADM, avalie inclinação do sprite, velocidade/distância e FPS comparando com a V47.7.3.

VALIDAÇÃO:
45 testes locais direcionados passaram em fixture sintático, com reinstalação do patch idempotente (0 mudanças na segunda execução); pontos de integração conferidos com a V47.7.3 no GitHub.
Limitação: ainda não houve teste com o conjunto completo de arquivos no GitHub Actions nem validação ao vivo na conta ADM/dispositivo Android; só o instalador remoto e testes dentro do jogo podem confirmar essas etapas.
