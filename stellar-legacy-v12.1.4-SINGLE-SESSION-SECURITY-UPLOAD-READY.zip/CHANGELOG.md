## V12.1.4 — Login Único / Segurança de Sessão

- Uma conta só pode manter uma sessão oficial do jogo por vez.
- Novo login substitui a sessão anterior imediatamente no banco.
- Cliente conectado verifica a sessão a cada 3 segundos e também ao voltar para a aba.
- Sessão antiga é encerrada com aviso “Sua conta foi acessada em outro dispositivo”.
- Endpoints de save/autenticação validam o identificador da sessão ativa no servidor.
- Refresh token da sessão antiga não consegue reativar o jogo após substituição.
- Ao ser expulso, o save local daquela sessão é descartado para não sobrescrever o progresso do dispositivo novo.
- Logout normal limpa o registro da sessão ativa.
- Sessões antigas anteriores à V12.1.4 exigem novo login uma única vez.

## V12.1.3 — P.E.T. Guardião + Venda Segura

- Corrigido alcance do Modo Guardião: busca automática limitada ao mesmo alcance de laser da nave.
- Coleta de BOX/Pedras reduzida para 50% do raio do minimapa.
- O P.E.T. mantém o alvo de coleta mais próximo dele dentro desse raio reduzido.
- Novo modal de confirmação de venda para inventário, equipamentos equipados, equipamentos do P.E.T. e drones.
- Cancelar não altera inventário nem saldo.

# Changelog — Stellar Legacy

O projeto usa um único changelog consolidado. Os arquivos `CHANGELOG_Vx_y.md` antigos foram removidos do pacote; o histórico completo continua disponível no Git.

## Baseline V10.10.1
Conta online, save cloud, facções, mapas, NPCs, Hangar, equipamentos, P.E.T., missões, Galaxy Gate, ranking, leilão, PvP e Arena foram consolidados como base do jogo.

## V11
- Arena cinematográfica calculada no servidor.
- Sistema de patentes e ranking.
- Administradores ficam fora dos rankings públicos.
- Clãs/alianças e TAG no nome dos pilotos.
- Recompensas de nível e Passe de Batalha.

## V12
- Loja Premium em modo de teste ADM.
- Passe FREE + PREMIUM e Solace no Tier 30 Premium.
- PREMIUM mensal com benefícios de reparo, regeneração, míssil e descontos.
- Equipamentos só podem ser alterados na base.
- Microzona neutra de NPC ao redor dos portais.
- Clã LV1–10, rendimento diário, coleta automática de 10% e taxa de 5% em transferências.

## V12.1 — P.E.T. Autônomo
- Alcance de coleta passa a acompanhar o radar do minimapa.
- Assistência prioritária ao alvo atacado pelo jogador.
- Patrulha e escolta independente.
- Combate automático quando não há tarefa de coleta.

## V12.1.1 — P.E.T. Inteligente + Cleanup
- Velocidade do P.E.T. reduzida em patrulha, coleta, escolta e combate.
- Aproximação desacelera perto do objetivo para eliminar o efeito de vai-e-volta.
- BOX e pedras são escolhidas pela distância ao próprio P.E.T., desde que estejam dentro do radar do jogador.
- O alvo de coleta fica travado até ser coletado, expirar ou sair do radar; o P.E.T. não troca de objetivo a cada frame.
- Patrulha usa trajetos menores e troca de waypoint com menos frequência.
- Alvos automáticos de combate também ficam estáveis enquanto forem válidos.
- Changelogs por versão, SQL histórico, documentação obsoleta e página de catálogo de assets não usada foram removidos do release.
- Backend de referência consolidado em `sql/CURRENT_BACKEND.sql`.


## V12.1.2 — Location Persistence Hotfix
- Corrigido bug que misturava `mapId` novo com `x/y` do mapa anterior durante salto por portal.
- Novo `positionByMap` preserva coordenadas por mapa/facção.
- `saveGame()` agora sincroniza `player.x/y` antes de serializar.
- Transições de mapa fazem flush cloud imediato.
- Reload prefere save local mais recente quando o cloud ainda está alguns instantes atrasado.
