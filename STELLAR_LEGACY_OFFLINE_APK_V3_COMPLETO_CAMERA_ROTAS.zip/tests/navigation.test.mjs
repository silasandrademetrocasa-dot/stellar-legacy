import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import { routeGroups,routeFor } from '../web/routes.js';
import { renderPage } from '../web/pages.js';
import { project,unproject,bankForVelocity,DEFAULT_CAMERA_ZOOM,CAMERA_Y } from '../web/camera.js';
const mock={schema:1,name:'Teste',seq:3,level:7,xp:0,credits:100000,stl:500,map:'1-1',ship:'aurora',ownedShips:['aurora'],hp:16000,shield:12000,resources:{Prometium:12,Endurium:11,Terbium:5,Prometid:1,Duranium:1,Promerium:0,Xenomit:0},items:{laser_arc1:2,escudo_alfa:2,ammo_arc:100},confs:{1:{laser:2,shield:2,drone:0,motor:0,equipped:{laser_arc1:2,escudo_alfa:2}},2:{laser:0,shield:0,drone:0,motor:0,equipped:{}}},conf:1,kills:3,loot:18,sales:0,missions:[{id:'first',kind:'kill',need:8,start:0,claimed:false}],relay:{owner:'Neutro',capturedAt:0},clan:'Aurora',farm:{active:false,startedAt:0},events:{lastClaim:''},lastActive:Date.now(),passClaims:[]};
const args={state:mock,ship:{id:'aurora',name:'Aurora',hp:16000,shield:12000,damage:280,speed:170},capacity:1900,cargoCount:30,frameFps:30,relayInfo:{protected:false,remaining:'Disponível'},auto:false,inCombat:false,cameraZoom:.73,quality:'medium'};
test('rotas oficiais sem duplicar identificadores por grupo',()=>{
 assert.equal(routeGroups.length,9);
 for(const group of routeGroups){const ids=new Set(group.pages.map(([id])=>id));assert.equal(ids.size,group.pages.length,group.id);for(const [id] of group.pages)assert.equal(routeFor(id).id,group.id);}
});
test('todos os painéis renderizam com dados existentes',()=>{
 for(const group of routeGroups)for(const [id] of group.pages){const markup=renderPage(id,args);assert.ok(typeof markup==='string'&&markup.length>80,id);assert.doesNotMatch(markup,/undefined|NaN|Esta seção ainda não está implementada/,id)}
});
test('câmera ampla com transformação inversa estável e nav frontal',()=>{
 for(const zoom of [.65,DEFAULT_CAMERA_ZOOM,.86]){
  for(const [x,y] of [[0,0],[400,200],[-350,700]]){
   const p=project(x,y,120,-40,844,390,zoom);const w=unproject(p.x,p.y,120,-40,844,390,zoom);
   assert.ok(Math.abs(x-w.x)<1e-8&&Math.abs(y-w.y)<1e-8);
  }
 }
 assert.equal(CAMERA_Y,.57);assert.ok(bankForVelocity(999,200)<=17);assert.ok(bankForVelocity(-999,200)>=-17);
});
test('HUD contem minimapa e controles de zoom sem Canvas',()=>{
 const html=readFileSync(new URL('../web/index.html',import.meta.url),'utf8');
 const game=readFileSync(new URL('../web/game.js',import.meta.url),'utf8');
 for(const id of ['minimap','minimapSurface','toolbar','panelTabs','routeDrawer','quickTabs'])assert.ok(html.includes(`id="${id}"`),id);
 assert.ok(game.includes('screenToWorld('));assert.doesNotMatch(game,/<canvas|\.getContext\(/i);
});
