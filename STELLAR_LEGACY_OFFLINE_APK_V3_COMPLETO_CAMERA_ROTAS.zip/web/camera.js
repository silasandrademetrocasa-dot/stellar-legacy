// Câmera 2D superior do Universo Solo. Pura e testável (sem Canvas).
export const DEFAULT_CAMERA_ZOOM=0.73;
export const CAMERA_Y=0.57; // nave 7% abaixo do centro, mostrando mais setor à frente
export const project=(x,y,playerX,playerY,width,height,zoom)=>({
 x:width*0.5+(x-playerX)*zoom,
 y:height*CAMERA_Y+(y-playerY)*zoom
});
export const unproject=(px,py,playerX,playerY,width,height,zoom)=>({
 x:playerX+(px-width*0.5)/zoom,
 y:playerY+(py-height*CAMERA_Y)/zoom
});
export const bankForVelocity=(vx,speed)=>Math.max(-17,Math.min(17,vx/Math.max(70,speed)*18));
