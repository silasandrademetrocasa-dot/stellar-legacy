// Rotas nativas do Universo Solo. Somente UI local: nenhuma requisicao HTTP.
export const routeGroups = [
 {id:'pilot',label:'PILOTO',icon:'◉',default:'profile',pages:[['profile','Perfil'],['achievements','Conquistas']]},
 {id:'ship',label:'NAVE',icon:'◇',default:'hangar',pages:[['hangar','Naves'],['equipment','Equipamentos'],['drones','Drones'],['config','CONF1 / CONF2']]},
 {id:'aux',label:'AUX',icon:'✦',default:'aux',pages:[['aux','AUX-9'],['protocols','Protocolos']]},
 {id:'missions',label:'MISSÕES',icon:'☷',default:'missions',pages:[['missions','Missões'],['pass','Passe Solo']]},
 {id:'activities',label:'ATIVIDADES',icon:'◷',default:'autopilot',pages:[['autopilot','Autopilot'],['farm','Farm Offline'],['cargo','Porão'],['refinery','Refinaria']]},
 {id:'events',label:'EVENTOS',icon:'⚑',default:'events',pages:[['events','Eventos Solo'],['relay','Relés'],['clan','Clã']]},
 {id:'market',label:'MERCADO',icon:'▣',default:'market',pages:[['market','Loja'],['ammo','Munições'],['inventory','Inventário'],['cargo-market','Vender recursos']]},
 {id:'map',label:'MAPA',icon:'⌖',default:'map',pages:[['map','Setores'],['radar','Radar tático']]},
 {id:'settings',label:'AJUSTES',icon:'⚙',default:'settings',pages:[['settings','Save e backup'],['graphics','Gráficos']]},
];
export const routeFor=(id)=>routeGroups.find(g=>g.pages.some(p=>p[0]===id))||routeGroups[0];
export const groupFor=(id)=>routeGroups.find(g=>g.id===id)||routeGroups[0];
export const allRoutes=routeGroups.flatMap(g=>g.pages.map(([id,label])=>({id,label,group:g.id})));
