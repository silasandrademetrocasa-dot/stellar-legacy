import { resources,ships,enemies,maps,mapLabel,mapImage,shopItems,fmt } from './catalog.js';
import { retrieve,commit,exportData,importData } from './storage.js';
import { routeGroups,routeFor,groupFor } from './routes.js';
import { renderPage, refines, passes } from './pages.js';
import { DEFAULT_CAMERA_ZOOM, CAMERA_Y,project,unproject,bankForVelocity } from './camera.js';
const $=id=>document.getElementById(id), esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)), rand=(a,b)=>a+Math.random()*(b-a), uid=()=>globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random()}`;
let camera={zoom:DEFAULT_CAMERA_ZOOM}, flight={vx:0,vy:0,bank:0}, radarLast=0, state, world={npcs:[],ores:[],map:'',target:null}, viewport={w:1,h:1}, dest=null, auto=false, inCombat=false, last=performance.now(), fpsTs=performance.now(), fpsFrames=0, frameFps=0, elapsedSave=0, nextNpcAttack=0, nextPlayerAttack=0, nextAi=0, lastHud=0, currentPanel='', inputLocked=false, dirty=false;
const resourceById=Object.fromEntries(resources.map(r=>[r.id,r]));
const clsShip=id=>ships.find(x=>x.id===id)||ships[0];
const S=(s=state)=>clsShip(s.ship);
function fresh(){let resources={};for(const r of Object.keys(resourceById))resources[r]=0;return {schema:1,seq:0,name:'Piloto Solo',level:1,xp:0,credits:120000,stl:1400,map:'1-1',x:0,y:0,ship:'aurora',ownedShips:['aurora'],hp:16000,shield:12000,resources,capacity:1900,items:{laser_arc1:2,escudo_alfa:2,ammo_arc:1000},conf:1,confs:{1:{laser:2,shield:2,motor:0,drone:0},2:{laser:2,shield:2,motor:0,drone:0}},kills:0,loot:0,sales:0,missions:[{id:'first',kind:'kill',need:8,start:0,done:false,claimed:false},{id:'mine',kind:'collect',need:30,start:0,done:false,claimed:false},{id:'merchant',kind:'sell',need:150,start:0,done:false,claimed:false}],relay:{owner:'Neutro',capturedAt:0},clan:'Aurora',farm:{active:false,startedAt:0,minutes:60},events:{lastClaim:''},passClaims:[],cameraZoom:.73,quality:'medium',lastActive:Date.now(),logs:[],receipts:[]};}
const capacity=(s=state)=>Math.round(s.capacity);const cargoCount=(s=state)=>Object.values(s.resources).reduce((a,b)=>a+(+b||0),0);const power=()=>{const c=state.confs[state.conf];return S().damage+(c.laser||0)*80+(c.drone||0)*25};const maxHp=(s=state)=>S(s).hp;const maxShield=(s=state)=>S(s).shield+(s.confs[s.conf].shield||0)*750;
// Fila UNICA: compra, venda, saque, resgate e equipamento nao competem entre si.
// Nunca anuncia sucesso antes do commit atomico no IndexedDB.
let operationQueue=Promise.resolve();
function transact(action,fn,{backup=false}={}){
 const job=operationQueue.catch(()=>{}).then(async()=>{
  inputLocked=true;
  try{
   const draft=structuredClone(state);
   if(fn(draft)===false)return false;
   draft.seq=(Number(draft.seq)||0)+1;
   draft.lastActive=Date.now();
   draft.logs.unshift({at:draft.lastActive,action});
   draft.logs.length=Math.min(draft.logs.length,50);
   await commit(draft,{checkpoint:backup||draft.seq%15===0});
   // Movimento em curso nao fica preso na transacao que salvou o inventario.
   const moved=dirty && dest && (draft.x!==state.x||draft.y!==state.y);
   const x=state.x,y=state.y;
   state=draft;
   if(moved){state.x=x;state.y=y;dirty=true;}else dirty=false;
   updateHud();return true;
  }catch(err){show('Falha ao salvar: '+err.message);console.error(err);return false;}
  finally{inputLocked=false;}
 });
 operationQueue=job.catch(()=>{});
 return job;
}
function notify(txt){const host=$('gameMessages');const el=document.createElement('p');el.textContent=txt;host.prepend(el);while(host.children.length>3)host.lastChild.remove();setTimeout(()=>el.remove(),4500)}
let noticeTimer;function show(txt){const n=$('notice');n.textContent=txt;n.classList.add('visible');clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>n.classList.remove('visible'),2600);}
function updateHud(){if(!state)return;$('cr').textContent=fmt(state.credits);$('stl').textContent=fmt(state.stl);$('level').textContent=state.level;$('pilotName').textContent=state.name;$('mapName').textContent=`${mapLabel(state.map)} • ${state.map}`;const path=`./assets/ships/${state.ship}.webp`;if(!$('shipImage').getAttribute('src')||!$('shipImage').getAttribute('src').endsWith('/'+state.ship+'.webp'))$('shipImage').src=path;
 const hp=clamp(state.hp/maxHp()*100,0,100),sh=clamp(state.shield/maxShield()*100,0,100);$('hpFill').style.width=hp+'%';$('hpLabel').textContent=`HP ${fmt(state.hp)} / ${fmt(maxHp())}`;$('shieldFill').style.width=sh+'%';$('shieldLabel').textContent=`ESC ${fmt(state.shield)} / ${fmt(maxShield())}`;$('autopilotBtn').textContent=auto?'◉ AUTOPILOT ON':'◉ AUTOPILOT OFF';$('autopilotBtn').classList.toggle('active',auto);$('fightBtn').classList.toggle('active',inCombat)}
function makeWorld(){world.npcs=[];world.ores=[];world.target=null;world.map=state.map;const zone=state.map.startsWith('1')?0:state.map.startsWith('2')?1:state.map.startsWith('3')?2:3;for(let i=0;i<11;i++){const e=enemies[clamp(zone+Math.floor(rand(0,3)),0,enemies.length-1)];world.npcs.push({id:uid(),kind:'npc',x:rand(-950,950),y:rand(-950,950),hp:e.hp,max:e.hp,e,alive:true,lastHit:0,el:null});}
 for(let i=0;i<18;i++){const r=resources[Math.floor(rand(0,Math.min(6,zone+4)))];world.ores.push({id:uid(),kind:'ore',x:rand(-1000,1000),y:rand(-1000,1000),r,qty:Math.floor(rand(3,13)),el:null});}
 $('mapBackdrop').style.backgroundImage=`url('${mapImage(state.map)}')`;createEntities();updateHud();}
function createEntities(){const host=$('world');host.replaceChildren();for(const obj of [...world.npcs,...world.ores]){const el=document.createElement('div');el.className=obj.kind==='npc'?'sprite':'oreSprite';el.dataset.id=obj.id;const im=document.createElement('img');im.src=obj.kind==='npc'?`./assets/npcs/${obj.e.sprite}`:`./assets/ores/${obj.r.icon}`;el.append(im);if(obj.kind==='npc'){const bar=document.createElement('div');bar.className='smallbar';bar.innerHTML='<i style="width:100%"></i>';el.append(bar);const name=document.createElement('div');name.className='spriteName';name.textContent=obj.e.name;el.append(name)}el.addEventListener('pointerdown',ev=>{ev.stopPropagation();if(obj.kind==='npc'){world.target=obj;inCombat=true;show('Alvo: '+obj.e.name);$('selectedTarget').hidden=false;updateTargetLabel()}else{dest={x:obj.x,y:obj.y,ore:obj.id};show('Coletando '+obj.r.name)}}, {passive:true});obj.el=el;host.append(el);}}
function updateTargetLabel(){const t=world.target;$('selectedTarget').hidden=!t;if(t)$('selectedTarget').textContent=`⚔ ${t.e.name} · HP ${fmt(Math.max(0,t.hp))}`;}
function playerScreen(){return {x:viewport.w*.50,y:viewport.h*CAMERA_Y};}
function worldToScreen(x,y){return project(x,y,state.x,state.y,viewport.w,viewport.h,camera.zoom);}
function screenToWorld(x,y){return unproject(x,y,state.x,state.y,viewport.w,viewport.h,camera.zoom);}
function renderEntities(){const w=viewport.w,h=viewport.h;for(const o of [...world.npcs,...world.ores]){if(!o.el)continue;const p=worldToScreen(o.x,o.y),visible=p.x>-55&&p.x<w+55&&p.y>-55&&p.y<h+55&&o.alive!==false;o.el.style.display=visible?'':'none';if(visible){o.el.style.left=p.x.toFixed(1)+'px';o.el.style.top=p.y.toFixed(1)+'px';o.el.style.transform=`translate3d(-50%,-50%,0) scale(${camera.zoom.toFixed(2)})`;if(o.kind==='npc')o.el.querySelector('i').style.width=clamp(o.hp/o.max*100,0,100)+'%';}}$('mapBackdrop').style.transform=`translate3d(${(-state.x*.04*camera.zoom).toFixed(1)}px,${(-state.y*.04*camera.zoom).toFixed(1)}px,0)`;}
function dronesFrame(now){const host=$('drones');const count=Math.min(state.confs[state.conf].drone||0,8);if(host.children.length!==count){host.replaceChildren();for(let i=0;i<count;i++){const el=document.createElement('img');el.src='./assets/drones/drone_common.webp';host.append(el)}}for(let i=0;i<count;i++){const a=now*.0012+i*2*Math.PI/count;host.children[i].style.transform=`translate3d(${Math.cos(a)*48}px,${Math.sin(a)*42}px,0)`;}}
// Fisica suavizada e apresentaçao frontal: o sprite não gira 180° nem aponta a traseira.
function travel(dt){
 const epsilon=dt>0?1-Math.exp(-dt*7):0;
 if(dest){
  let dx=dest.x-state.x,dy=dest.y-state.y,d=Math.hypot(dx,dy);
  const maximum=S().speed+(state.confs[state.conf].motor||0)*7;
  if(d<10){
   state.x=dest.x;state.y=dest.y;
   const oreId=dest.ore;dest=null;flight.vx=0;flight.vy=0;
   if(oreId){const o=world.ores.find(x=>x.id===oreId);if(o)collect(o)}
  }else{
   const speed=maximum*Math.min(1,Math.max(.20,d/130));
   const wantX=dx/d*speed,wantY=dy/d*speed;
   flight.vx+=(wantX-flight.vx)*epsilon;flight.vy+=(wantY-flight.vy)*epsilon;
   const travelX=flight.vx*dt,travelY=flight.vy*dt;
   if(Math.hypot(travelX,travelY)>=d){state.x=dest.x;state.y=dest.y;flight.vx=0;flight.vy=0;}
   else{state.x+=travelX;state.y+=travelY;}
   dirty=true;
  }
 }else{flight.vx+=(0-flight.vx)*epsilon;flight.vy+=(0-flight.vy)*epsilon;}
 // Inclina somente 17° para cada lado; movimento continua independente da arte.
 const bankGoal=bankForVelocity(flight.vx,S().speed);
 flight.bank+=(bankGoal-flight.bank)*(1-Math.exp(-dt*5));
 const el=$('pilotSprite');
 el.style.transform=`translate3d(-50%,-50%,0) rotate(${flight.bank.toFixed(2)}deg)`;
}
function collect(o){
 if(o.collecting)return;
 o.collecting=true;
 let amount=0;
 transact('coleta:'+o.r.name,s=>{
  const available=capacity(s)-cargoCount(s);
  amount=Math.min(o.qty,available);
  if(amount<1)return false;
  s.resources[o.r.id]=(s.resources[o.r.id]||0)+amount;
  s.loot+=amount;
 }).then(ok=>{
  if(ok){notify(`+${amount} ${o.r.name}`);o.qty-=amount;
   if(o.qty<=0){o.x=rand(-950,950);o.y=rand(-950,950);o.qty=Math.round(rand(4,15));}}
  else notify('Coleta nao salva; o recurso continua no mapa.');
 }).finally(()=>{o.collecting=false});
}
function experience(x,s){
 s.xp+=x;
 while(s.xp>=s.level*2000){s.xp-=s.level*2000;s.level++;
  s.hp=maxHp(s);s.shield=maxShield(s);}
}
function flash(p){const el=document.createElement('div');el.className='blast';el.style.left=(p.x-24)+'px';el.style.top=(p.y-24)+'px';$('effects').append(el);setTimeout(()=>el.remove(),240)}
function destroy(t){
 t.alive=false;flash(worldToScreen(t.x,t.y));
 const e=t.e;const zone=state.map.startsWith('3')?3:state.map.startsWith('2')?2:1;
 transact('recompensa:'+e.name,s=>{
  s.credits+=e.credit;s.stl+=e.stl;s.kills++;experience(240+zone*120,s);
  const res=resources[Math.floor(rand(0,Math.min(resources.length-1,zone+3)))];
  const n=Math.min(Math.round(rand(3,10)),capacity(s)-cargoCount(s));
  if(n>0){s.resources[res.id]+=n;s.loot+=n;}
 },{backup:true}).then(ok=>{
  if(ok){notify(`${e.name} eliminado • +${fmt(e.credit)} CR • +${e.stl} STL`);
   setTimeout(()=>{t.x=rand(-1000,1000);t.y=rand(-1000,1000);t.hp=t.max;t.alive=true},7000);}
  else {t.hp=t.max;t.alive=true;notify('Recompensa nao salva: inimigo restaurado.');}
 });
 if(world.target===t){world.target=null;inCombat=false;updateTargetLabel();}
}
function playerAttack(now){const t=world.target;if(!t||!t.alive){inCombat=false;return;}const dist=Math.hypot(t.x-state.x,t.y-state.y);if(dist>650){if(auto)dest={x:t.x,y:t.y};return;}if(now<nextPlayerAttack)return;nextPlayerAttack=now+480;const p=worldToScreen(t.x,t.y);const el=document.createElement('div');el.className='shot';const start=playerScreen();el.style.left=start.x+'px';el.style.top=start.y+'px';const angle=Math.atan2(p.y-start.y,p.x-start.x)*180/Math.PI+90;el.style.transform=`rotate(${angle}deg) scaleY(${clamp(dist*camera.zoom/50,2,18)})`;$('projectiles').append(el);setTimeout(()=>el.remove(),115);
 t.hp-=power();if(t.hp<=0)destroy(t);updateTargetLabel();}
function npcAttack(now){if(now<nextNpcAttack)return;nextNpcAttack=now+1200;const near=world.npcs.filter(x=>x.alive&&Math.hypot(x.x-state.x,x.y-state.y)<200);if(!near.length)return;const dmg=Math.round(near.reduce((a,n)=>a+n.e.dmg,0)*.32);if(state.shield>0){const take=Math.min(dmg,state.shield);state.shield-=take;state.hp-=dmg-take;}else state.hp-=dmg;
 dirty=true;if(state.hp<=0){state.hp=maxHp();state.shield=maxShield();state.x=0;state.y=0;dest=null;auto=false;inCombat=false;notify('Nave recuperada na base. Nenhum item perdido.');transact('recuperação da nave',s=>{});} }
function nearest(list){let best=null,d=Infinity;for(const x of list){if(x.alive===false)continue;let q=Math.hypot(x.x-state.x,x.y-state.y);if(q<d){d=q;best=x;}}return best;}
function autoStep(){if(!auto||currentPanel)return;if(cargoCount()>=capacity()*.9){dest={x:0,y:0};if(Math.hypot(state.x,state.y)<35){auto=false;show('Porão cheio — nave voltou à base');updateHud();}return;}const ore=nearest(world.ores);const npc=nearest(world.npcs);if(ore&&Math.hypot(ore.x-state.x,ore.y-state.y)<270){dest={x:ore.x,y:ore.y,ore:ore.id};return;}if(npc){world.target=npc;inCombat=true;dest={x:npc.x+125,y:npc.y};}}
function tick(now){const dt=Math.min(.035,(now-last)/1000);last=now;if(state&&!currentPanel&&!inputLocked){viewport.w=$('gameView').clientWidth;viewport.h=$('gameView').clientHeight;travel(dt);if(inCombat)playerAttack(now);npcAttack(now);renderEntities();dronesFrame(now);renderRadar(now);if(now>nextAi){nextAi=now+550;autoStep()}if(now-lastHud>170){lastHud=now;updateHud()}elapsedSave+=dt;if(elapsedSave>=6){elapsedSave=0;if(dirty&&!inputLocked)transact('posicao:periodico',()=>{}).catch(e=>show('Erro no save local: '+e.message));}}
 fpsFrames++;if(now-fpsTs>=1000){frameFps=Math.round(fpsFrames*1000/(now-fpsTs));fpsFrames=0;fpsTs=now;$('fpsLabel').textContent='FPS '+frameFps+(auto?' • AUTO':'');}requestAnimationFrame(tick);}
function sell(id){const r=resourceById[id];if(!r||r.price<=0){show('Recurso reservado para craft/refinaria');return;}const n=state.resources[id]||0;if(!n){show('Sem recurso para vender');return;}transact('venda:'+r.name,s=>{const q=s.resources[id]||0;if(q<1)return false;s.resources[id]=0;s.credits+=q*r.price;s.sales+=q;},{backup:true}).then(ok=>{if(ok){show(`Venda confirmada localmente: +${fmt(n*r.price)} CR`);panel(currentPanel==='cargo-market'?'cargo-market':'cargo')}});}
function sellAll(){const q=resources.filter(r=>r.price>0).map(r=>({id:r.id,amount:state.resources[r.id]||0,price:r.price}));const total=q.reduce((x,r)=>x+r.amount*r.price,0);if(!total){show('Nada vendável no porão');return;}transact('venda:porão',s=>{let gain=0;for(const r of q){const n=s.resources[r.id]||0;s.resources[r.id]=0;gain+=n*r.price;s.sales+=n;}s.credits+=gain;},{backup:true}).then(ok=>{if(ok){show(`Porão vendido: +${fmt(total)} CR`);panel(currentPanel==='cargo-market'?'cargo-market':'cargo')}});}
function buy(item){transact('compra:'+item.name,s=>{if(s[item.currency]<item.price)return false;s[item.currency]-=item.price;s.items[item.id]=(s.items[item.id]||0)+(['ammo','missile'].includes(item.type)?item.bonus:1);},{backup:true}).then(ok=>{show(ok?item.name+' adquirido e salvo offline':'Saldo insuficiente');panel(currentPanel==='ammo'?'ammo':currentPanel==='aux'?'aux':'market')});}
function purchaseShip(id){const x=clsShip(id);if(state.ownedShips.includes(id)){transact('troca de nave',s=>{s.ship=id;s.hp=maxHp(s);s.shield=maxShield(s);},{backup:true}).then(ok=>{if(ok){show('Nave selecionada');panel('hangar')}});return;}transact('nova nave:'+x.name,s=>{if(s.credits<x.price)return false;s.credits-=x.price;s.ownedShips.push(id);s.ship=id;s.hp=x.hp;s.shield=x.shield;},{backup:true}).then(ok=>{show(ok?'Nova nave adquirida':'Créditos insuficientes');panel('hangar')});}
const btn=(text,code,extra='')=>`<button type="button" ${extra} data-command="${esc(code)}">${esc(text)}</button>`;
function panel(id){
 const group=routeFor(id);currentPanel=id;
 $('panelLayer').hidden=false;
 $('panelGroup').textContent=group.label;
 const sub=group.pages.find(p=>p[0]===id);
 $('panelTitle').textContent=sub?.[1]||id;
 $('panelTabs').innerHTML=group.pages.map(([page,label])=>`<button data-panel="${esc(page)}" class="${page===id?'active':''}">${esc(label)}</button>`).join('');
 $('panelContent').innerHTML=renderPage(id,{state,ship:S(),capacity:capacity(),cargoCount:cargoCount(),frameFps,relayInfo:relayInfo(),auto,inCombat,cameraZoom:camera.zoom,quality:state.quality||'medium'});
 document.querySelectorAll('#toolbar button[data-group]').forEach(b=>b.classList.toggle('active',b.dataset.group===group.id));
 $('routeDrawer').hidden=true;$('menuToggle').setAttribute('aria-expanded','false');
}
function setupMenus(){
 $('toolbar').innerHTML=routeGroups.map(g=>`<button data-group="${g.id}" data-panel="${g.default}">${g.icon} ${g.label}</button>`).join('');
 $('routeDrawer').innerHTML=routeGroups.map(g=>`<section class="routeDrawerGroup"><b>${g.icon} ${g.label}</b><div class="routeDrawerLinks">${g.pages.map(([id,label])=>`<button data-panel="${id}">${esc(label)}</button>`).join('')}</div></section>`).join('');
 const nav=e=>{const btn=e.target.closest('button[data-panel]');if(btn){e.stopPropagation();panel(btn.dataset.panel)}};
 $('toolbar').addEventListener('click',nav);
 $('routeDrawer').addEventListener('click',nav);
 $('panelTabs').addEventListener('click',nav);
 $('quickTabs').addEventListener('click',nav);
 $('minimapMapBtn').addEventListener('click',nav);
 $('menuToggle').onclick=()=>{const open=$('routeDrawer').hidden;$('routeDrawer').hidden=!open;$('menuToggle').setAttribute('aria-expanded',String(open));};
}
function renderRadar(now){
 if(now-radarLast<210||$('minimap').classList.contains('collapsed'))return;
 radarLast=now;
 const scale=1100,coords=$('minimapCoords');
 coords.textContent=`${Math.round(state.x)}, ${Math.round(state.y)}`;
 const dots=[{kind:'ship',x:state.x,y:state.y},{kind:'base',x:0,y:0},
  ...world.ores.map(o=>({kind:'ore',x:o.x,y:o.y})),
  ...world.npcs.filter(o=>o.alive).map(o=>({kind:world.target===o?'target':'npc',x:o.x,y:o.y})),
  ...(dest?[{kind:'dest',x:dest.x,y:dest.y}]:[])];
 const surface=$('minimapPoints');
 // Reusar nós: não reconstruir a árvore do DOM a cada frame.
 while(surface.childElementCount<dots.length){const el=document.createElement('i');el.className='minipoint';surface.append(el)}
 while(surface.childElementCount>dots.length)surface.lastChild.remove();
 for(let i=0;i<dots.length;i++){
  const d=dots[i],el=surface.children[i];
  el.className='minipoint '+d.kind;
  el.style.left=(50+clamp((d.x-state.x)/scale,-1,1)*48).toFixed(1)+'%';
  el.style.top=(50+clamp((d.y-state.y)/scale,-1,1)*48).toFixed(1)+'%';
 }
}
function closePanel(){currentPanel='';$('panelLayer').hidden=true;}
function relayInfo(){const passed=Math.max(0,Date.now()-(state.relay.capturedAt||0));if(!state.relay.capturedAt)return {protected:false,remaining:'Disponível para conquista'};const cycle=passed%(24*3600000),protectedPhase=cycle<12*3600000,remain=(protectedPhase?12*3600000:24*3600000)-cycle;return {protected:protectedPhase,remaining:Math.floor(remain/3600000)+'h '+Math.floor(remain%3600000/60000)+'min'}}
function normalizeOfflineState(s){
 s.cameraZoom=clamp(Number(s.cameraZoom)||.73,.60,.95);
 s.quality=['low','medium','high'].includes(s.quality)?s.quality:'medium';
 s.passClaims=Array.isArray(s.passClaims)?s.passClaims:[];
 s.confs=s.confs||{1:{laser:0,shield:0,motor:0,drone:0},2:{laser:0,shield:0,motor:0,drone:0}};
 for(const n of [1,2]){
  const c=s.confs[n]||(s.confs[n]={laser:0,shield:0,motor:0,drone:0});
  if(!c.equipped){c.equipped={laser_arc1:Math.min(c.laser||0,s.items?.laser_arc1||0),escudo_alfa:Math.min(c.shield||0,s.items?.escudo_alfa||0)};}
  refreshLoadout(c);
 }
 camera.zoom=s.cameraZoom;
 $('shell').classList.toggle('quality-low',s.quality==='low');
}
function refreshLoadout(config){
 for(const t of ['laser','shield','motor','drone'])
  config[t]=shopItems.filter(i=>i.type===t).reduce((sum,item)=>sum+Math.max(0,Number(config.equipped[item.id])||0),0);
}
async function commands(c){const [action,...rest]=c.split(':'),id=rest.join(':');
 if(action==='open'){panel(id);return;}
 if(action==='toggleAuto'){auto=!auto;if(!auto)dest=null;updateHud();show(auto?'Autopilot local ativo':'Autopilot desligado');panel('autopilot');return;}
 if(action==='base'){auto=false;dest={x:0,y:0};closePanel();show('Retornando à base');return;}
 if(action==='farm'){await toggleFarm();panel('farm');return;}
 if(action==='radarOn'){$('minimap').classList.remove('collapsed');closePanel();return;}
 if(action==='camera'){
  const zoom=Number(id);if(![.65,.73,.86].includes(zoom))return;
  const ok=await transact('camera:zoom',s=>{s.cameraZoom=zoom;},{backup:true});
  if(ok){camera.zoom=zoom;panel('graphics');show('Distância da câmera ajustada e salva');}
  return;
 }
 if(action==='quality'){
  if(!['low','medium','high'].includes(id))return;
  const ok=await transact('grafico:'+id,s=>{s.quality=id;},{backup:true});
  if(ok){$('shell').classList.toggle('quality-low',id==='low');panel('graphics');}return;
 }
 if(action==='unequip'){
  const item=shopItems.find(x=>x.id===id);if(!item)return;
  const ok=await transact('retirar:'+item.name,s=>{const c=s.confs[s.conf];if(!(c.equipped[id]>0))return false;c.equipped[id]--;refreshLoadout(c);},{backup:true});
  if(ok)panel(currentPanel==='drones'?'drones':'equipment');return;
 }
 if(action==='refine'){
  const recipe=refines.find(x=>x.id===id);if(!recipe)return;
  const ok=await transact('refinaria:'+id,s=>{
   if(recipe.consume.some(([r,q])=>(s.resources[r]||0)<q))return false;
   for(const [r,q] of recipe.consume)s.resources[r]-=q;
   s.resources[recipe.output]=(s.resources[recipe.output]||0)+recipe.quantity;
  },{backup:true});
  show(ok?'Refino confirmado no save local':'Recursos insuficientes');panel('refinery');return;
 }
 if(action==='pass'){
  const p=passes.find(x=>x.id===id);if(!p)return;
  const ok=await transact('passe:'+id,s=>{
   s.passClaims||=[];
   if(s.passClaims.includes(id)||(s[p.kind]||0)<p.need)return false;
   s.passClaims.push(id);s.credits+=p.credits;s.stl+=p.stl;
  },{backup:true});if(ok)show('Bônus do passe confirmado');panel('pass');return;
 }
if(action==='sell')sell(id);if(action==='sellAll')sellAll();if(action==='buy'){const x=shopItems.find(z=>z.id===id);if(x)buy(x);}if(action==='ship')purchaseShip(id);if(action==='conf'){await transact('configuração '+id,s=>{s.conf=Number(id);s.shield=clamp(s.shield,0,maxShield(s));},{backup:true});show('CONF'+id+' aplicada e salva offline');panel(currentPanel==='config'?'config':'equipment')}
 if(action==='equip'){
  const item=shopItems.find(x=>x.id===id&&['laser','shield','motor','drone'].includes(x.type));if(!item)return;
  const ok=await transact('equipar:'+item.name,s=>{
   const c=s.confs[s.conf];c.equipped||={};
   if((c.equipped[id]||0)>=(s.items[id]||0))return false;
   c.equipped[id]=(c.equipped[id]||0)+1;refreshLoadout(c);
  },{backup:true});
  show(ok?'Item equipado e salvo':'Nenhuma unidade disponível');
  panel(currentPanel==='drones'?'drones':'equipment');return;
 }
 if(action==='map'){auto=false;dest=null;flight.vx=0;flight.vy=0;await transact('mapa:'+id,s=>{s.map=id;s.x=0;s.y=0;s.hp=maxHp(s);s.shield=maxShield(s);},{backup:true});auto=false;inCombat=false;dest=null;makeWorld();closePanel();show('Bem-vindo ao setor '+id);}
 if(action==='mission'){const m=state.missions.find(m=>m.id===id);if(m){const score=m.kind==='kill'?state.kills:m.kind==='collect'?state.loot:state.sales;if(!m.claimed&&score-m.start>=m.need){await transact('missão:'+id,s=>{const m=s.missions.find(x=>x.id===id);m.claimed=true;s.credits+=m.need*800;s.stl+=Math.ceil(m.need/3);},{backup:true});show('Recompensa resgatada!');panel('missions')}}}
 if(action==='capture'){if(relayInfo().protected){show('Relé ainda protegido');return;}await transact('captura relé',s=>{s.relay.owner=s.clan;s.relay.capturedAt=Date.now();s.credits+=50000;s.stl+=20;},{backup:true});show('Relé conquistado — escudo 12 horas');panel(currentPanel==='clan'?'clan':currentPanel==='events'?'events':'relay')}
 if(action==='setClan'){const name=($('clanField')?.value||'').trim().slice(0,22);if(name){await transact('nome do clã',s=>{s.clan=name},{backup:true});panel(currentPanel==='clan'?'clan':currentPanel==='events'?'events':'relay')}}
 if(action==='event'){const phase=Number(id),key=phase+':'+Math.floor(Date.now()/3600000);if(state.events.lastClaim===key)return;await transact('evento solo',s=>{s.events.lastClaim=key;s.credits+=25000;s.stl+=15;},{backup:true});panel(currentPanel==='clan'?'clan':currentPanel==='events'?'events':'relay');show('Evento solo recompensado')}
 if(action==='save'){await transact('save manual',()=>{}, {backup:true});show('Estado e checkpoint salvos')}
 if(action==='repair'){await transact('reparar nave',s=>{if(s.credits<500)return false;s.credits-=500;s.hp=maxHp(s);s.shield=maxShield(s);},{backup:true});panel('settings')}
 if(action==='export'){await operationQueue;const raw=await exportData();if(window.StellarNativeBackup?.exportSave){window.StellarNativeBackup.exportSave(raw);show('Escolha onde salvar seu backup no Android');return;}const url=URL.createObjectURL(new Blob([raw],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=`stellar-offline-save-${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);show('Backup exportado')}
 if(action==='import'){if(window.StellarNativeBackup?.importSave)window.StellarNativeBackup.importSave();else $('uploadSave')?.click()}
}
async function toggleFarm(){if(state.farm.active){const seconds=Math.max(0,(Date.now()-state.farm.startedAt)/1000),mins=Math.min(480,seconds/60),n=Math.floor(mins*2),reward=Math.floor(mins*1600);await transact('resgate farm offline',s=>{if(!s.farm.active)return false;s.farm.active=false;s.farm.startedAt=0;s.credits+=reward;s.stl+=Math.floor(mins/3);s.kills+=Math.floor(mins/2);s.resources.Prometium+=Math.min(n,Math.max(0,capacity(s)-cargoCount(s)));},{backup:true});show(`Farm resgatado: +${fmt(reward)} CR, ${Math.floor(mins)} min`);}else{await transact('início farm',s=>{s.farm.active=true;s.farm.startedAt=Date.now();},{backup:true});show('Farm iniciado: feche o jogo e retorne depois');}updateFarmButton();}
function updateFarmButton(){$('farmBtn').textContent=state.farm.active?'◷ RESGATAR FARM':'◷ FARM OFFLINE';$('farmBtn').classList.toggle('active',state.farm.active)}
function bind(){
 setupMenus();
 $('panelContent').onclick=e=>{const cmd=e.target.closest('[data-command]');if(cmd)commands(cmd.dataset.command).catch(err=>show('Erro: '+err.message))};
 $('closePanel').onclick=closePanel;
 $('panelLayer').onclick=e=>{if(e.target===$('panelLayer'))closePanel()};
 $('gameView').addEventListener('pointerdown',e=>{
  if(e.target.closest('#bottomHud,#quickTabs,#minimap,#selectedTarget,#gameMessages,#fpsLabel'))return;
  const rect=$('gameView').getBoundingClientRect();
  dest=screenToWorld(e.clientX-rect.left,e.clientY-rect.top);
  auto=false;updateHud();
 },{passive:true});
 $('minimapToggle').onclick=e=>{e.stopPropagation();const open=$('minimap').classList.toggle('collapsed');$('minimapToggle').textContent=open?'+':'−';};
 $('minimapSurface').addEventListener('pointerdown',e=>{
  e.stopPropagation();const rect=$('minimapSurface').getBoundingClientRect();
  const rx=clamp((e.clientX-rect.left)/rect.width,0,1),ry=clamp((e.clientY-rect.top)/rect.height,0,1);
  dest={x:state.x+(rx-.5)*2200,y:state.y+(ry-.5)*2200};auto=false;updateHud();show('Destino marcado no radar');
 });
 $('minimapSurface').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();panel('map')}});
 $('autopilotBtn').onclick=()=>{auto=!auto;if(!auto)dest=null;updateHud();show(auto?'Autopilot local ativo':'Autopilot desligado')};
 $('fightBtn').onclick=()=>{if(!world.target||!world.target.alive)world.target=nearest(world.npcs);inCombat=!inCombat;updateTargetLabel();updateHud()};
 $('baseBtn').onclick=()=>{auto=false;dest={x:0,y:0};show('Voltando à base')};
 $('farmBtn').onclick=toggleFarm;
 $('panelContent').addEventListener('change',async e=>{
  if(e.target?.id==='uploadSave'){
   const f=e.target.files[0];if(!f)return;
   try{const n=await importData(await f.text());state=n;normalizeOfflineState(state);world={npcs:[],ores:[],map:'',target:null};auto=false;inCombat=false;dest=null;makeWorld();panel('settings');show('Save importado com sucesso');}catch(err){show('Importação falhou: '+err.message)}
  }
 });
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&state&&dirty)transact('pausa:snapshot',()=>{}).catch(()=>{});last=performance.now()});
 window.addEventListener('pagehide',()=>{if(state&&dirty)transact('sair:snapshot',()=>{}).catch(()=>{});});
}
// SAF nativo chama esta funcao ao selecionar um backup JSON.
window.StellarNativeImport=async raw=>{
 try{await operationQueue;const n=await importData(raw);state=n;normalizeOfflineState(state);auto=false;inCombat=false;dest=null;
 makeWorld();updateHud();updateFarmButton();panel('settings');show('Backup importado com sucesso!');}
 catch(e){show('Backup invalido: '+e.message)}
};
window.StellarOfflineFlush=()=>transact('app:pausa',()=>{});
async function boot(){try{const loaded=await retrieve();state=loaded.state||fresh();normalizeOfflineState(state);if(!loaded.state)await commit(state,{checkpoint:true});if(loaded.source!=='primary'&&loaded.source!=='new'){await commit(state,{checkpoint:true});show('Save recuperado do checkpoint '+loaded.source)}
 state.hp=clamp(state.hp||1,0,maxHp());state.shield=clamp(state.shield||0,0,maxShield());$('splash').remove();$('shell').hidden=false;bind();makeWorld();updateFarmButton();updateHud();requestAnimationFrame(tick);if(!window.StellarNativeBackup && 'serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});
 if(state.farm.active)notify('Farm Offline disponível para resgate');else notify('Bem-vindo ao Universo Solo: 100% offline');
}catch(e){$('bootStatus').textContent='Não foi possível abrir seu save local: '+e.message;console.error(e)}}boot();
