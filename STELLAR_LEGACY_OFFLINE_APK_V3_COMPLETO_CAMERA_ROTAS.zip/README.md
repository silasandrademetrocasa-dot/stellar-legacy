# Stellar Legacy Offline — APK Android V3

Versão local de laboratório com **câmera mais alta e ampla**, nave frontal suavizada, minimapa tático e rotas oficiais separadas.

## Incluído
- Menus: Piloto, Nave, AUX, Missões, Atividades, Eventos, Mercado, Mapa, Ajustes.
- Abas separadas para hangar, equipamentos, drones, CONF1/2, mercado, munições, porão, refinaria, Farm, Autopilot e muito mais.
- Minimapa DOM/CSS interativo, com nave, NPC, minério, alvo, base e destino. Não usa Canvas.
- Câmera padrão de 73%, ajustável para 65/73/86% em **Ajustes → Gráficos**. Nave renderizada um pouco abaixo do centro para ampliar visão à frente.
- Nave nunca faz giro 180°, inclinação visual suavizada a até ±17°, aceleração/amortecimento de movimento.
- Economia, missão, Passe Solo, refinaria, configurações e save local transacionais no IndexedDB.
- Sem Render, SQL, login ou Supabase; relés e clãs são **simulados somente neste aparelho**.

## Construção
`npm run check && npm test`

O workflow oficial Android incluído no pacote compila o APK, mas **não foi executado aqui**. Rode os testes físicos no Android antes de substituir um app instalado. Faça backup JSON dos saves sempre que trocar de versão.
