# Stellar Legacy — Combat Reborn 47.0.0

Patch incremental sobre a versão 46.2.0: um ZIP, sem alteração do SQL, saves, tabelas, moedas, drops ou autorização de combate.

## Componentes
1. Áudio — laser pesado, motor da nave, ruptura de escudo, portais PvP e Astrais.
2. Visual — anéis de acerto, escudos, explosões e alertas de fase de chefe (com limites por qualidade gráfica).
3. NPC — deslocamento lateral discreto apenas para elites/chefes locais quando já perseguem o jogador. Não altera alcance, dano, ataque ou IA do servidor.
4. Portais — assinaturas gráficas PvP e Astrais, sem mexer nas rotas ou posições.
5. Mobile/HUD — menos efeitos simultâneos e configuração de efeitos táticos na aba já existente.
6. Verificação — testes de comportamento, preservação de autoridade e consistência do pacote.

## Instalar
Mantenha exatamente um ZIP na raiz do repositório; execute o workflow "Stellar Legacy — Instalador Universal" em GitHub Actions. O instalador deve validar antes de publicar.

## Avisos
Este é um patch incremental, não um jogo standalone. Requer que a branch main esteja em V46.2.0. O script de atualização é idempotente após a primeira aplicação. No caso de erro de teste, a versão publicada não deve ser substituída. Valide os FPS em hardware móvel antes de ativar perfis pesados.
