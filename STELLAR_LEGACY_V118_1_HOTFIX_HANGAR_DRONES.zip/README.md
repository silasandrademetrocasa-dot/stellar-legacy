STELLAR LEGACY — V118.1 Hotfix de montagem após venda de drone

Contexto: V118.0 já instalada. Este é um pacote incremental, NÃO cumulativo, sem SQL.

Ajuste: ao ler e validar um save, o Render remove referências aos drones não possuídos e alinha SOMENTE a planta da configuração ativa aos slots físicos oficiais dos drones existentes. A configuração inativa não é recriada. O servidor continua exigindo intenção explícita e baseline correto para equipar/remover. Não altera créditos, STL, inventário, ownership, combate ou itens físicos.

O bug anterior foi reproduzido por fixture: após uma venda, as duas configurações conservavam IDs órfãos e a ativa não coincidia com o equipamento físico. Isso gerava SAVE_EQUIPMENT_INTENT_REQUIRED a cada tentativa de save.

Testes locais: 493/493, incluindo cenários de proteção contra alteração sem intenção, normalização idempotente e preservação da CONF inativa. Não homologado em produção, e o sucesso de testes não garante a ausência de outras causas de falha.

Instalação: coloque somente este ZIP na raiz do repositório com V118.0 e execute o Instalador Universal. Não executar SQL e não mexer em saves manualmente. Antes de equipar: fechar a aba, reabrir o jogo e recarregar o estado oficial. Confirmar primeiro uma única alteração, logout/login e saldo. Se voltar a rejeitar, interromper testes e coletar logs.

Segurança: backups A/B/C e migração V118.0 devem permanecer inalterados. Nunca editar o estado econômico local para superar um erro de equipamento.
