STELLAR LEGACY — FPS LIVRE NOS 3 MODOS (22/10/2026)

Instalacao: colocar este ZIP SOZINHO na raiz do repositorio GitHub e executar
Actions -> Stellar Legacy — Instalador Universal. Remover qualquer ZIP anterior.

Arquivos alterados:
- public/modules/frame-gate.js: deixa passar todos os novos quadros de rAF
  independentemente dos FPS nominais dos perfis BAIXA/MEDIA/ALTA.
- tests/fps-unlocked-quality-v4776.test.mjs: 5 testes de regressao.

O valor nominal de qualidade permanece em 120/45/60 para preservar metas do
modo AUTO (e evitar degradacao visual erronea em telas 60Hz). A cadencia real
do jogo nao e limitada por esses valores: depende da taxa de atualizacao do
aparelho, do navegador e do tempo de processamento da cena.

Sem SQL, alteracoes de renderizacao grafica, HUD, save ou servidor.
Nao ha garantia de FPS maior que a capacidade fisica do aparelho.
