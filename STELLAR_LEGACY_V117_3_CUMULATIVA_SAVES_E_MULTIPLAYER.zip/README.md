# STELLAR LEGACY V117.3 — CUMULATIVA SAVES + MULTIPLAYER

**Inclui integralmente os patches cumulativos anteriores até V117.0, mais as fases V117.2 e V117.3.**

Mudanças desta fase:
- Autosave em combate: reduzir conflitos NPC sem contornar validação de revisão; checkpoints locais e operações críticas preservados.
- Uma conexão WebSocket válida por piloto, inclusive após mudança de mapa.
- Recompensa NPC só para destinatários únicos, válidos e ativos na mesma sala.
- Proteção de ataques de NPC, relé e mineração contra sockets antigos.
- Testes com dois pilotos simulados para grupo/PvP/relés e rotas do Autopilot.

Instalação: colocar **somente este ZIP** na raiz do repositório e executar `scripts/stellar-universal-installer.py` via workflow já existente.

Nenhum SQL novo é aplicado. Nenhuma chance, loot, dano, saldo, item ou preço foi reequilibrado.
**A homologação real de 8h e duas contas no Render ainda está pendente após o deploy.**

Documentação: docs/v117/LEIA_PRIMEIRO_V117_3_CUMULATIVA.md
