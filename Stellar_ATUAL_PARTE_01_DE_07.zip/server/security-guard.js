// Antifraude: sinais objetivos, sem confiar em valores enviados pelo navegador.
// Heurísticas deliberadamente conservadoras: uma divergência pequena não é prova de trapaça.
export const SECURITY_LIMITS=Object.freeze({creditsPerSave:100_000_000,stlPerSave:1_000_000,creditsAbsolute:1_000_000_000_000,stlAbsolute:10_000_000_000,itemQuantity:1_000_000_000});
const entries=Object.freeze({inventory:SECURITY_LIMITS.itemQuantity,ammo:1_000_000_000_000,rockets:SECURITY_LIMITS.itemQuantity,cargo:SECURITY_LIMITS.itemQuantity,materials:SECURITY_LIMITS.itemQuantity});
function numberField(value){if(value===null||value===undefined)return 0;if(typeof value==='boolean'||typeof value==='object')return NaN;return Number(value);}
function currency(state,key){return numberField(state?.profile?.[key]);}
function issue(code,severity='warn',summary='Validação de integridade recusada.',evidence={}){return {code,severity,summary,evidence};}
export function validatePlayerSave(incoming,stored,{userId,isAdmin=false}={}){
 if(!incoming||typeof incoming!=='object'||Array.isArray(incoming))return issue('SAVE_INVALID','warn');
 if(incoming.accountOwnerId && String(incoming.accountOwnerId)!==String(userId))return issue('SAVE_OWNER_FORGED','critical','Save com proprietário divergente.');
 if(stored?.accountOwnerId&&String(stored.accountOwnerId)!==String(userId))return issue('SAVE_EXISTING_OWNER_MISMATCH','warn','Save existente com proprietário divergente.');
 for(const [key,max] of [['credits',SECURITY_LIMITS.creditsAbsolute],['uridium',SECURITY_LIMITS.stlAbsolute]]){
  const v=currency(incoming,key);if(!Number.isSafeInteger(v)||v<0||v>max)return issue('SAVE_INVALID_CURRENCY','critical',`Saldo ${key} fora dos limites financeiros.`,{field:key});
  const prior=currency(stored,key);const delta=v-(Number.isFinite(prior)?prior:0);
  if(!isAdmin&&stored&&delta>(key==='credits'?SECURITY_LIMITS.creditsPerSave:SECURITY_LIMITS.stlPerSave))return issue('SAVE_UNEXPLAINED_BALANCE','warn','Aumento de saldo acima do limite por save.',{field:key,increment:Math.round(delta)});
 }
 // Protocolos alteram apenas habilidades locais, nunca dinheiro: limitar campos e pontos
 // evita payloads absurdos sem punir uma migração/lag com autoban.
 if(incoming?.pet?.protocols!=null){
  const p=incoming.pet.protocols,ids=['guard','ore','box','repair','kami'];
  const level=Math.max(1,Math.min(20,Math.trunc(Number(incoming.pet.level)||1)));
  const capacity=Math.min(12,level+2);
  if(!p||typeof p!=='object'||Array.isArray(p)||Object.keys(p).some(k=>!ids.includes(k)))
   return issue('SAVE_AUX_PROTOCOL_INVALID','warn','Configuração dos protocolos do AUX fora do formato.');
  let sum=0;
  for(const id of ids){const n=p[id]??0;if(!Number.isInteger(n)||n<0||n>3)return issue('SAVE_AUX_PROTOCOL_INVALID','warn','Nível de protocolo inválido.',{protocol:id});sum+=n;}
  if(sum>capacity)return issue('SAVE_AUX_PROTOCOL_INVALID','warn','Protocolos excederam os espaços de nível.',{points:sum,capacity});
 }
 for(const [group,max] of Object.entries(entries)){
  const bucket=incoming[group];if(bucket==null)continue;
  if(typeof bucket!=='object'||Array.isArray(bucket))return issue('SAVE_INVALID_INVENTORY','warn','Inventário com formato inválido.',{group});
  for(const [item,quantity] of Object.entries(bucket)){
    if(typeof quantity==='object')continue; // receitas legadas com metadados complexos continuam funcionando.
    if(!Number.isSafeInteger(Number(quantity))||Number(quantity)<0||Number(quantity)>max)return issue('SAVE_ITEM_OVERFLOW','critical','Quantidade de itens inválida.',{group,item:String(item).slice(0,48)});
  }
 }
 if(stored&&!isAdmin){
  const oldOreRev=Number(stored.serverOreRevision)||0;const newOreRev=Number(incoming.serverOreRevision)||0;
  if(newOreRev>oldOreRev)return issue('SAVE_ORE_REVISION_FORGED','critical','Revisão de mineração controlada pelo servidor.');
  const oldNpcRev=Number(stored.serverNpcRewardRevision)||0;
  const newNpcRev=Number(incoming.serverNpcRewardRevision)||0;
  if(newNpcRev>oldNpcRev)return issue('SAVE_NPC_REVISION_FORGED','critical','Revisão de abates gerenciada pelo servidor.',{field:'serverNpcRewardRevision'});
  const oldPurchase=Number(stored.serverPurchaseRevision)||0;const newPurchase=Number(incoming.serverPurchaseRevision)||0;
  if(newPurchase>oldPurchase)return issue('SAVE_PURCHASE_REVISION_FORGED','critical','Revisao de compra alterada pelo navegador.');
  const oldElite=Number(stored.serverEliteRevision)||0;const newElite=Number(incoming.serverEliteRevision)||0;
  if(newElite>oldElite)return issue('SAVE_RESERVED_REVISION','critical','Tentativa de avançar revisão controlada pelo servidor.',{field:'serverEliteRevision'});
  const oldCoupon=Number(stored.serverCouponRevision)||0;const newCoupon=Number(incoming.serverCouponRevision)||0;
  if(newCoupon>oldCoupon)return issue('SAVE_RESERVED_REVISION','critical','Revisão de cupom controlada pelo servidor.',{field:'serverCouponRevision'});
 }
 return null;
}
export function invalidShopArguments(body,allowedKeys){
 if(!body||typeof body!=='object'||Array.isArray(body))return issue('SHOP_INVALID_PAYLOAD','warn');
 const extras=Object.keys(body).filter(k=>!allowedKeys.includes(k));
 if(extras.some(k=>/(price|cost|discount|balance|currency|qty|amount|reward|item|grant|premium|product_id)/i.test(k)))return issue('SHOP_PRICE_MANIPULATION','critical','Parâmetros econômicos não autorizados enviados à compra.',{extraFields:extras.slice(0,8)});
 return null;
}
