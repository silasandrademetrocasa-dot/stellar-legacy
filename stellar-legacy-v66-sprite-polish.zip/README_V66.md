# Stellar Legacy V66

- Ajuste de recorte dos sprites 2D
- AUX-9 com animação mais lenta e mais agradável
