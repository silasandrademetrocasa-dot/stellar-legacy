STELLAR LEGACY V47.7.2 — STABILITY POLISH
========================================

BASE: V47.7.1 (GitHub main). Um PATCH incremental; nenhuma limpeza do projeto.

Objetivo: encerrar a linha Bot Wars com FPS preservado, sem novas funções.

Correções:
* Impede disparos do piloto em zonas protegidas contra bots.
* Remove verificação de fogo amigo duplicada no servidor.
* Descarta ANTES de criar beam e som os tiros de bots fora de tela.
* Preserva os sprites de facção, minimapa 'MAPA 4-2', botão UNIVERSO e controles ADM.
* Nenhuma alteração em moedas, dano base, XP, drops, saves, SQL, captura dos relés.
* O motor roda na cadência existente e com o mesmo limite de 12 bots por mapa.

INSTALAÇÃO:
1. Coloque SOMENTE este ZIP na raiz do repositório GitHub.
2. Execute 'Instalar ZIP universal' no Actions.
3. Confira que o npm run check e npm test passaram antes do deploy.
4. Valide rapidamente treinamento e conquista em 4-1, com FPS no celular.

SQL: NÃO É NECESSÁRIO. O SQL da V47.7.0 permanece.

VALIDAÇÃO: testes de regressão executados em fixture local; validação da suíte total
é responsabilidade do workflow GitHub, ainda não executado para este pacote.
