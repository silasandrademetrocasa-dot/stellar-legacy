# V118.0 — SAVE ÚNICO TRANSACIONAL A/B/C

**ATENÇÃO: O SQL DEVE SER APLICADO ANTES DO INSTALADOR!**

Leia `docs/v118/LEIA_PRIMEIRO_SAVE_UNICO_ABC.md`. O ZIP é incremental sobre a V117.3.1, não elimina progresso. Cria um RPC seguro do Render com perfil+save atômicos e três gerações de backup. Corrige referências órfãs de drones em CONF1/2 e limpa rótulos de versão públicos. Não faz mudança de balanceamento nem altera chances de sorteio. Não restaura automaticamente backups A/B/C nem desabilita proteções NPC/ORE. Não execute durante resgate ou farm offline ativo. A migração SQL não foi executada no banco de produção durante a elaboração.
