V140 sobre V139 completa (47.7.71). Bases Terra/Marte/Júpiter em X-1/X-8 com totens funcionais. Não precisa de SQL novo. Use o workflow universal. Leia README_V140_0.md e docs/v140/REVISAO_ARTES.md.
