// ÚNICA fonte persistente: IndexedDB. Nenhuma chamada SQL, HTTP, Render ou Supabase.
const DB='stellar_legacy_offline_solo_v1', VERSION=1;
let dbPromise;
function open(){if(dbPromise)return dbPromise;dbPromise=new Promise((resolve,reject)=>{
 const q=indexedDB.open(DB,VERSION);q.onupgradeneeded=()=>{const d=q.result;if(!d.objectStoreNames.contains('records'))d.createObjectStore('records');};
 q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);
});return dbPromise;}
export const checksum=state=>{let h=2166136261;const s=JSON.stringify(state);for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16)};
function request(q){return new Promise((res,rej)=>{q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});}
export async function retrieve(){const d=await open();const t=d.transaction('records','readonly');const s=t.objectStore('records');const [primary,a,b,c]=await Promise.all(['primary','A','B','C'].map(k=>request(s.get(k))));
 const valid=v=>v&&v.state&&v.hash===checksum(v.state);
 if(valid(primary))return {state:primary.state,source:'primary',sequence:primary.sequence||0};
 for(const [slot,v] of [['A',a],['B',b],['C',c]]){if(valid(v))return {state:v.state,source:slot,sequence:v.sequence||0};}
 return {state:null,source:'new',sequence:0};}
let chain=Promise.resolve();
export function commit(state,{checkpoint=false}={}){const snapshot=structuredClone(state);const packet={state:snapshot,hash:checksum(snapshot),sequence:snapshot.seq||0,savedAt:Date.now()};
 // All writes serialized; state and checkpoints updated in the same IndexedDB transaction.
 const job=chain.catch(()=>{}).then(async()=>{const d=await open();await new Promise((resolve,reject)=>{const t=d.transaction('records','readwrite');const s=t.objectStore('records');
  const get=s.get('A');get.onsuccess=()=>{if(checkpoint){const old=get.result;if(old){const getB=s.get('B');getB.onsuccess=()=>{if(getB.result)s.put(getB.result,'C');s.put(old,'B');s.put(packet,'A');};}else s.put(packet,'A');}s.put(packet,'primary');};
 t.oncomplete=resolve;t.onerror=()=>reject(t.error);t.onabort=()=>reject(t.error);
 });return packet;});chain=job;return job;}
export async function exportData(){const v=await retrieve();if(!v.state)throw new Error('Sem save local');return JSON.stringify({format:'stellar-offline-save',version:1,exportedAt:new Date().toISOString(),data:v.state,checksum:checksum(v.state)},null,2);}
export async function importData(raw){const obj=JSON.parse(raw);if(obj.format!=='stellar-offline-save'||obj.version!==1||!obj.data||checksum(obj.data)!==obj.checksum)throw new Error('Arquivo de save inválido');await commit(obj.data,{checkpoint:true});return obj.data;}
