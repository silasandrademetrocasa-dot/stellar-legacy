# Stellar Legacy • Universo Solo (edição de recuperação)

Esta é uma versão **independente e jogável**, criada para permitir voltar a jogar sem as rotas antigas de gravação/SQL do Stellar Legacy online. **Não substitui automaticamente todas as funcionalidades da V130:** é um jogo solo separado, com parte dos sistemas importantes implementada de forma limpa. O projeto online original não é modificado.

## Instalação
1. Publique todos os arquivos desta pasta na raiz do repositório GitHub Pages (ou em uma pasta própria, como `/solo/`).
2. Abra o endereço HTTPS do GitHub Pages **uma vez com internet** para registrar o service worker e obter os assets. Após isso, o jogo é utilizável offline no mesmo navegador/dispositivo, desde que os arquivos permaneçam em cache.
3. Use o menu **Ajustes → Exportar backup** regularmente. Limpar os dados do navegador/APK pode apagar IndexedDB e cache offline.
4. Para gerar APK WebView, garanta que o WebView permita IndexedDB e uso de service worker. A publicação GitHub Pages usa caminhos relativos; não há URL de Render nem credencial Supabase.

## Sistemas utilizáveis
- Combate PvE, movimento por toque, NPCs, radar espacial visual, loot, coleta, recursos, porão, venda individual e total, créditos e STL locais.
- Hangar, 43 naves, equipamentos, drones, AUX como item, CONF1/CONF2 e lojas.
- Missões simples, recompensa única, Autopilot, Farm Offline até 8h com resgate local persistente.
- Setores Terra, Marte, Júpiter, PvP/Universo/Astral **como mapas individuais**, sem outras pessoas reais.
- Relé com 12h de escudo + 12h disputável, clã local, evento por jogador e recompensas. NÃO é multiplayer compartilhado.
- IndexedDB como **única autoridade de gravação**, checkpoints A/B/C e backup import/export JSON.

## Limitações conhecidas
- PvP real, leilão real, troca entre jogadores, clans externos e Warfront sincronizado não existem aqui. Não há servidor compartilhado nem segurança anticheat; créditos/STL desta versão não devem ser transferidos para uma economia online.
- A simplificação do motor pode produzir mecânicas e balanceamento diferentes do Stellar Legacy V130. O conteúdo integral da V130 não foi migrado.
- Testes automatizados não reproduzem todas as condições térmicas e WebView Android.

## Salvamento
Compras/vendas/equipamentos/relé/missões são persistidos em IndexedDB antes de apresentar a confirmação. Movimento salva em lotes a cada 6 segundos, e na ocultação do aplicativo. Checkpoints A/B/C são mantidos na mesma transação do banco local; há recuperação após falha de integridade.

## Release
Versão SOLO-1.0.0 (baseada em artes/catálogo da V130, mas isolada dela). Não requer SQL. Não requer Render. Para alterar o jogo online anterior, é necessário um projeto de migração diferente — não copie esta build sobre a V130 sem backup do repositório.
