V142.0 sobre V141 / 47.7.73. Use o workflow universal. SQL já aplicado; leia README_V142_0.md.
