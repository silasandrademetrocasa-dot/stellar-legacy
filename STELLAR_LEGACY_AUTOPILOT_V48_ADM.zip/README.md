# STELLAR LEGACY — AUTOPILOT V48.0 (integração segura)

## O que este pacote entrega

- Novo painel **🤖 STELLAR AUTOPILOT** para contas ADM e para usuários que receberem permissão individual por check no ADM > Jogadores.
- Mapas X-1…X-8 / U-1…U-3, apenas quando o jogador tem acesso ao destino e existe rota pelos portais. **Não atravessa setores PvP 4-X**.
- Filtro de tipos de NPC (nenhum marcado significa NPCs comuns), alvo mais próximo ou eficiência estimada, perseguição e disparo com o armamento equipado.
- Coleta por nave dos BOX bônus, recursos deixados pelos NPCs e mineração opcional; utiliza os métodos de coleta já existentes.
- Venda via comerciante no X-1 ou usando equipamento remoto, conforme regras atuais; caminho de retorno pelos portais oficiais.
- Auto-reabastecimento laser/mísseis com preços e validação do servidor, respeitando o CPU de compra automática fora da base ou o comerciante na base; orçamento máximo em CR para compras iniciadas pelo Autopilot.
- HP baixo => retirada/recuperação na base. Morte exige reparo normal do jogador. Tempo máximo por sessão e botão de parar.
- Status e relatório copiável com tempo, XP, CR líquidos, STL, NPCs, BOX, drops, coleta de minérios e compras.
- Check individual de autorização na lista ADM de jogadores. ADM é autorizado por função já existente no banco; demais usuários começam sem autorização.
- Banco preparado para a fonte `verified_purchase` **futura**. Não inclui checkout, plano, preço real, nem visibilidade na loja Premium.

## Instalação — duas partes

1. **Banco:** a migração `sql/STELLAR_V48_AUTOPILOT_ACESSO.sql` **já foi aplicada** no projeto Supabase `stellar-legacy` nesta conversa, e foi conferida: RLS ativado, sem grants de jogadores. Não é necessário executá-la novamente.
2. **Código:** envie o ZIP sozinho à raiz do repositório GitHub e execute `Actions → Stellar Legacy — Instalador Universal`. O instalador aplica o patch idempotente no `npm run check` e executa os testes existentes. **Não** adicione manualmente nenhum arquivo à loja Premium.
3. Atualize o navegador e faça login no ADM; aparece o botão discreto **🤖 AUTOPILOT**. Em `ADM → Jogadores`, cada conta comum recebe um check de acesso. Após ativar, o jogador deve sair e entrar novamente para ver o botão.

## Restrição operacional importante

**Esta V48 opera a nave real em uma sessão ativa no navegador.** Não roda offline ou com a janela fechada, e navegadores mobile podem reduzir ou suspender o jogo quando colocados em segundo plano. Não há ainda runner de conta headless no Render: isso exige implementar um piloto virtual autorizado pelo servidor com combate, caminhos, inventário, save e recompensas sem duplicação. Até essa integração ser validada, não seria correto prometer farm autônomo remoto de uma conta real.

O modo assistido **não cria XP, CR ou STL diretamente**. Chama as funções normais do jogo, sujeitas às permissões, valores do catálogo e verificações do servidor. A conta usada é aquela que está autenticada e pilotando no navegador; nunca faz login em outra conta ou troca de usuário em segundo plano.

## Segurança e limites

- Nenhum jogador comum pode conceder a permissão por si só; a permissão é consultada pelo Render e revalidada periodicamente. Check só altera `source='admin'` após autenticação da função administrativa.
- O bot é desligado ao perder a permissão, conexão, login, ao morrer, ao ficar em mapa não suportado ou ao acabar o tempo da sessão.
- Toque manual no canvas devolve o controle ao usuário e desliga o bot.
- Nunca escolhe jogadores como alvo, não permite ganhar recompensas dos Warbots de treinamento, não faz teleporte direto ou modifica os saldos por fora.
- O teto de compras diz respeito apenas às compras feitas por esse módulo; compras de outros recursos/CPUs já equipados seguem as regras próprias do jogo.
- A seleção `U-X` continua sujeita às permissões de acesso e portais normais; selecione X-1 primeiro para validar o bot.

## Testes locais

- 7 testes de decisão do algoritmo passaram: mapas, filtros, prioridade de retirada, drops, NPCs, grafos/portais e proteção de acesso.
- Script de integração testado em cenário isolado, com aplicação e reaplicação idempotente (2 execuções).
- Sintaxe de ambos os módulos JS validada com Node 22.
- O projeto integral deve passar pelo workflow antes do deploy; testes em produção com jogadores reais ainda são necessários.

## Teste recomendado (ADM)

1. Abra X-1 online, configure o filtro para um NPC comum, selecione BOX e drops, teste 10 minutos.
2. Veja o bot chegar até o alvo pelo movimento normal e disparar armamento equipado; confirme que loot e balanços persistem após recarregar.
3. Aumente para X-2, teste retorno pelo portal à base quando o porão encher.
4. Use limite de compra baixo; confirme que o bot não faz novas compras depois do limite.
5. Desative o check de acesso numa conta de teste separada; valide que o bot para após revalidação e não volta no próximo login.

Sem SQL destrutivo, reset de contas ou concessão de prêmio nessa instalação.
