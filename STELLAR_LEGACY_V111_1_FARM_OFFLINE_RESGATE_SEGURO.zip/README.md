STELLAR LEGACY V111.1 — RECUPERAÇÃO SEGURA DO FARM OFFLINE

Instalar por cima da V111.0 pelo Instalador Universal.
O SQL de resgate é aplicado ao Supabase separadamente; caso já tenha sido aplicado, não executar novamente.
A recuperação ocorre apenas ao tocar em RESGATAR/TERMINAR e após validação transacional no servidor.
Salvamentos e recompensas de jogador não são alterados pela instalação do pacote.
NÃO clicar em CANCELAR SEM GANHOS nas sessões em revisão.

Critérios de recuperação: nenhuma recompensa online, perfil e save financeiramente sincronizados, saldo preservado e
(para sessões antigas, atualização exata na virada do dia; para sessões futuras, assinatura do estado econômico igual).
O banco mantém a função de liquidação original e o status 'settled' para impedir pagamentos repetidos.

Este ZIP inclui apenas as alterações. Não modifica server/world.js, scripts de NPCs ou o módulo do hangar.
