# Stellar Legacy — Limpeza de apresentação

Atualização incremental **42.6.1 → 42.6.2**, para o Instalador Universal. Não é um ZIP completo.

- Remove 40 instruções e notas de release antigas na raiz, preservando o `README.md` ativo.
- Remove 5 scripts incrementais antigos que não participam mais do comando de validação. Conserva o instalador e o script v381 necessário ao teste legado.
- Remove textos de versão, SQL, banco de dados, servidor e termos de implementação de mensagens dos painéis Astrais/Universo/ADM, sem mudar nomes de APIs, contratos SQL ou chaves de saves.
- Esconde o número da versão no relatório local de desempenho. As versões continuam nos identificadores técnicos de cache/instalação.
- Preserva sprites e assets, dados, SQL, testes de regressão, anticheat, autenticação e infraestrutura de deploy.

**Atenção:** arquivos históricos removidos do Git `main` permanecem acessíveis no histórico de commits do GitHub. O patch não executa SQL e não toca no Supabase.

## Instalação

Coloque somente o ZIP na raiz do GitHub. O fluxo `Instalador Universal` instala e executa `npm run check` e `npm test`. O patch é idempotente.
