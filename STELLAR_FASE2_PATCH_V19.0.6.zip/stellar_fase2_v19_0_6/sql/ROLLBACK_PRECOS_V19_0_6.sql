-- USAR SOMENTE SE REVERTER O CODIGO PARA V19.0.5.
-- Nao remove a tabela de config; preserva dados ADM para futura volta.
UPDATE public.live_shop_prices_v16
SET price=CASE catalog_key
 WHEN 'gate_life:alpha' THEN 4000000
 WHEN 'gate_life:beta' THEN 8000000
 WHEN 'gate_life:gamma' THEN 15000000 END,
 currency='credits',updated_at=now()
WHERE catalog_key IN ('gate_life:alpha','gate_life:beta','gate_life:gamma')
  AND kind='gate_life';
