#!/usr/bin/env node
// Stellar Legacy V19.0.6 — Instalador de codigo incremental sobre V19.0.5.
// Use no diretorio raiz do projeto, com Node 18+. Nenhum arquivo e enviado a internet.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';

const work=process.cwd(),bundle=path.dirname(fileURLToPath(import.meta.url));
const files=['public/game.js','public/api.js','public/index.html','public/style.css','server/index.js','package.json','CHANGELOG.md'];
const original=new Map(),next=new Map();
for(const file of files){const full=path.join(work,file);if(!fs.existsSync(full))throw Error(`Arquivo ausente em ${work}: ${file}. Execute na pasta raiz do Stellar Legacy.`);const value=fs.readFileSync(full,'utf8');original.set(file,value);next.set(file,value);}
const read=p=>next.get(p),write=(p,s)=>next.set(p,s);
const replace=(p,a,b)=>{let s=read(p);if(!s.includes(a))throw Error(`Trecho esperado nao encontrado em ${p}: ${String(a).slice(0,110)}`);if(s.indexOf(a)!==s.lastIndexOf(a))throw Error(`Trecho ambiguo em ${p}: ${String(a).slice(0,60)}`);write(p,s.replace(a,b));};
const insertBefore=(p,anchor,body)=>replace(p,anchor,body+'\n'+anchor);

if(!/"version"\s*:\s*"19\.0\.5"/.test(read('package.json')))throw Error('Exige a versao 19.0.5; sua arvore nao e a versao base da Fase 1. Atualize a copia antes de aplicar.');

// 1: Endpoints expostos pelo proprio servidor; autorizacao no SQL/RPC.
write('public/api.js',read('public/api.js')+`\n// V19.0.6 — ADM Portais Astrais\nexport async function loadGalaxyGatesOnline(refresh=false){\n return serverFetch('/api/runtime/gates'+(refresh?'?refresh=1':''),{},true);\n}\nexport async function adminUpdateGalaxyGateOnline(key,config){\n return serverFetch('/api/admin/runtime/gates',{method:'POST',body:JSON.stringify({key,config})},true);\n}\n`);
const serverRoutes=`\n// V19.0.6 — Fonte assinada e validada no banco para ondas e recompensas dos Portais.\napp.get('/api/runtime/gates',requireUser,asyncRoute(async(req,res)=>{\n const {data,error}=await req.sb.rpc('get_galaxy_gate_config_v1906');\n if(error||!data?.config)return res.status(503).json({error:'Configuracao dos Portais indisponivel; confirme a migracao SQL V19.0.6.'});\n res.json(data);\n}));\napp.post('/api/admin/runtime/gates',requireUser,asyncRoute(async(req,res)=>{\n const key=String(req.body?.key||''),config=req.body?.config;\n if(!['alpha','beta','gamma'].includes(key)||!config||typeof config!=='object'||Array.isArray(config))return res.status(400).json({error:'Protocolo ou configuracao invalidos.'});\n const {data,error}=await req.sb.rpc('admin_update_galaxy_gate_config_v1906',{p_key:key,p_gate:config});\n if(error){const message=String(error.message||'Erro ao salvar Portal.');return res.status(/permiss|negad|administrativ/i.test(message)?403:400).json({error:message});}\n res.json(data);\n}));\n`;
insertBefore('server/index.js','// ===================== PLAYER TELEMETRY =====================',serverRoutes);

// 2: Vida adicional: 10.000 STL autoritativos no servidor (nao mais Creditos).
let server=read('server/index.js');
const lifeStart=server.indexOf("    else if(action==='gate_life'){");
const lifeEnd=server.indexOf("    else if(action==='gate_life_bonus'){",lifeStart);
if(lifeStart<0||lifeEnd<lifeStart)throw Error('Nao foi possivel localizar o bloco de compra de vida no servidor.');
const lifeNew=`    else if(action==='gate_life'){\n      const key=String(payload.protocol||'alpha'),def=GATE_SERVER_DEFS[key];\n      if(!def)throw Object.assign(new Error('Portal invalido.'),{status:400});\n      const g=ensureGalaxyGateServer(state),gate=g[key];\n      const mapOk=String(state.mapId||'')==='x1'&&String(state.territoryFaction||state.profile?.faction||'')===String(state.profile?.faction||'');\n      if(!mapOk)throw Object.assign(new Error('Compre vidas do Portal somente na sua base X-1.'),{status:409});\n      if(gate.lives>=def.maxLives)throw Object.assign(new Error('Limite de vidas atingido.'),{status:409});\n      const cost=10000;debitServer(state,cost,'uridium');gate.lives=Math.min(def.maxLives,gate.lives+1);\n      info={action,protocol:key,lives:gate.lives,max_lives:def.maxLives,cost,currency:'uridium'};\n    }\n`;
server=server.slice(0,lifeStart)+lifeNew+server.slice(lifeEnd);
const serverDrop="  g.lifeBonus=(g.lifeBonus||0)+1;return {kind:'life',label:'Vida Astral Reserva +1'};";
if(!server.includes(serverDrop))throw Error('Nao foi localizada a queda de vida no Materializador do servidor.');
server=server.replace(serverDrop,"  g.jumpBonus++;return {kind:'jump',label:'Bônus de Salto +1'}; // Vida removida dos giros V19.0.6");
server=server.replace("'sell_drone','gate_life','gate_spin'","'sell_drone','gate_spin'");
if(!server.includes('Number(x.lives)||def.baseLives'))throw Error('Esperada a normalizacao de vida no servidor.');
server=server.replace('Number(x.lives)||def.baseLives','(x.lives===null||x.lives===undefined?def.baseLives:Number(x.lives))');
write('server/index.js',server);

// 3: Runtime dos Portais e snapshots para manter ondas atuais durante uma tentativa em andamento.
const runtime=fs.readFileSync(path.join(bundle,'patches/gate_runtime.js.txt'),'utf8');
const admin=fs.readFileSync(path.join(bundle,'patches/gate_admin.js.txt'),'utf8');
insertBefore('public/game.js','function freshGateProtocol(){',runtime);
insertBefore('public/game.js','// V18.2.6 • Editor da BOX BÔNUS / custos dos Portais.',admin);
replace('public/game.js','adminSetCouponActiveOnline } from', 'adminSetCouponActiveOnline, loadGalaxyGatesOnline, adminUpdateGalaxyGateOnline } from');
replace('public/game.js',"function galaxyGateDef(key=currentGateKey()){return GALAXY_GATE_DEFS[key]||GALAXY_GATE_DEFS.alpha;}",
 `function galaxyGateDef(key=currentGateKey()){\n const base=GALAXY_GATE_DEFS[key]||GALAXY_GATE_DEFS.alpha;\n const activeRun=progress?.galaxyGate?.[key]?.run;\n return activeRun?.gateSetup?{...base,...activeRun.gateSetup}:base;\n}`);
replace('public/game.js',"a.run={active:true,round:1,waveIndex:0,remaining:{},nextWaveAt:0,nextRoundAt:0,killRewards:{credits:0,uridium:0,xp:0},roundRewardsClaimed:[],startedAt:Date.now()};",
 "a.run={active:true,round:1,waveIndex:0,remaining:{},nextWaveAt:0,nextRoundAt:0,killRewards:{credits:0,uridium:0,xp:0},roundRewardsClaimed:[],gateSetup:gateConfigDraft(gd.key),startedAt:Date.now()};");
for(const [oldCost,newCost] of [['lifeCost:4000000','lifeCost:10000'],['lifeCost:8000000','lifeCost:10000'],['lifeCost:15000000','lifeCost:10000']])replace('public/game.js',oldCost,newCost);
replace('public/game.js','Number(a.lives)||def.baseLives','(a.lives===null||a.lives===undefined?def.baseLives:Number(a.lives))');
// Evitar reiniciar contador 0 na entrada do Portal.
replace('public/game.js','Number(a.lives)||gd.baseLives','(a.lives===null||a.lives===undefined?gd.baseLives:Number(a.lives))');
const playerDrop="  g.lifeBonus=(g.lifeBonus||0)+1;return {kind:'life',label:'Vida Astral Reserva +1'};";
replace('public/game.js',playerDrop,"  g.jumpBonus++;return {kind:'jump',label:'Bônus de Salto +1'}; // Vida nao cai mais no giro");
let game=read('public/game.js');
const waveStart=game.indexOf('function spawnAlphaWave(){'),waveEnd=game.indexOf('function processRespawns(){',waveStart);
if(waveStart<0||waveEnd<waveStart)throw Error('Trecho de ondas nao encontrado.');
let waveSection=game.slice(waveStart,waveEnd);
waveSection=waveSection.replaceAll('GALAXY_ALPHA_WAVE_INTERVAL_MS','(galaxyGateDef().waveIntervalMs||GALAXY_ALPHA_WAVE_INTERVAL_MS)');
waveSection=waveSection.replaceAll('GALAXY_ALPHA_ROUND_INTERVAL_MS','(galaxyGateDef().roundIntervalMs||GALAXY_ALPHA_ROUND_INTERVAL_MS)');
game=game.slice(0,waveStart)+waveSection+game.slice(waveEnd);write('public/game.js',game);
// Fixa o preco visual, descontado por Stellarium.
replace('public/game.js',"const a=alphaGate(),gd=galaxyGateDef(),q=liveQuote(`gate_life:${gd.key}`),cost=q?.price??gd.lifeCost;",
 "const a=alphaGate(),gd=galaxyGateDef(),cost=10000;");
replace('public/game.js','if(progress.profile.credits<cost){showToast(`Faltam ${fmt(cost-progress.profile.credits)} CR para comprar +1 vida`);return;}',
 'if(progress.profile.uridium<cost){showToast(`Faltam ${fmt(cost-progress.profile.uridium)} STL para comprar +1 vida`);return;}');
replace('public/game.js',"value:cost,currency:'credits',confirmLabel:'COMPRAR VIDA',onConfirm:()=>runEconomyAction('gate_life'",
 "value:cost,currency:'uridium',confirmLabel:'COMPRAR VIDA',onConfirm:()=>runEconomyAction('gate_life'");
replace('public/game.js','lifeQuote=liveQuote(`gate_life:${gd.key}`),lifeCost=lifeQuote?.price??gd.lifeCost;', 'lifeCost=10000;');
replace('public/game.js','ui.buyGateLife.textContent=`COMPRAR VIDA +1 • ${fmt(lifeCost)} CR`;', 'ui.buyGateLife.textContent=`COMPRAR VIDA +1 • ${fmt(lifeCost)} STL`;');
replace('public/game.js','progress.profile.credits<lifeCost;','progress.profile.uridium<lifeCost;');
replace('public/game.js',"closeNavigationModals(ui.gateModal);renderGalaxyGate();ui.gateModal.classList.remove('hidden');",
 "closeNavigationModals(ui.gateModal);refreshGateLiveConfig(true).catch(()=>{});renderGalaxyGate();ui.gateModal.classList.remove('hidden');");
// Admin tab agora consulta a API de combate alem do editor de giros.
replace('public/game.js',"if(next==='portals')renderAdminPortalsEditor();",
 "if(next==='portals'){renderAdminPortalsEditor();if(!gateAdminRuntime.snapshot)loadAdminGateEditor(false);}");
replace('public/game.js','adminBonusEditor.snapshot=await loadBonusConfigOnline(force);renderAdminBonusEditor();adminBonusMessage',
 'adminBonusEditor.snapshot=await loadBonusConfigOnline(force);renderAdminBonusEditor();renderAdminPortalsEditor();adminBonusMessage');
// Substitui somente o card informativo por um formulario funcional.
game=read('public/game.js');
const placeholderStart=game.indexOf('<article class="admin-bonus-block"><h4>🛸 ONDAS, NPCs E PRÊMIOS</h4>');
const placeholderEnd=game.indexOf('</article>`;',placeholderStart);
if(placeholderStart<0||placeholderEnd<placeholderStart)throw Error('Placeholder da Fase 1 ausente.');
// O template original termina com </article>`;: preservar o final da string.
game=game.slice(0,placeholderStart)+'<article class="admin-bonus-block"><h4>🛸 ONDAS, NPCs E PRÊMIOS</h4>${renderAdminGateBuilder()}</article>'+game.slice(placeholderEnd+('</article>'.length));
write('public/game.js',game);
replace('public/game.js',"$('#adminRuntimePortalsGrid')?.addEventListener('click',e=>{if(e.target.closest('[data-portal-price-save]'))saveAdminPortalPrices();});",
 "$('#adminRuntimePortalsGrid')?.addEventListener('click',e=>{if(handleAdminGateBuilderClick(e))return;if(e.target.closest('[data-portal-price-save]'))saveAdminPortalPrices();});");
replace('public/game.js',"$('#adminRuntimePortalsReload')?.addEventListener('click',()=>loadAdminBonusEditor(true));",
 "$('#adminRuntimePortalsReload')?.addEventListener('click',()=>{loadAdminBonusEditor(true);loadAdminGateEditor(true);});");
// Corrige estado local se o configurador salvar e voltar a abrir o card.
replace('public/index.html', 'O editor de ondas e recompensas ficará na próxima fase, após validação do servidor.',
 'Ondas, NPCs, recompensas e intervalos editáveis • Aurora, Nexus e Eclipse.');
// Atualiza versões dos recursos carregados pelo navegador para evitar cache antigo.
for(const f of ['public/index.html','public/game.js'])write(f,read(f).replaceAll('19.0.5','19.0.6'));
write('public/style.css',read('public/style.css')+`\n/* V19.0.6 — Portais ADM */\n.portal-gate-tabs,.portal-gate-row-buttons,.portal-gate-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:10px 0}\n.portal-gate-round{border:1px solid rgba(89,192,255,.24);background:rgba(5,17,33,.7);border-radius:12px;margin:8px 0;padding:10px}\n.portal-gate-round>summary{cursor:pointer;color:#ccefff;display:flex;justify-content:space-between;gap:12px}\n.portal-gate-round-body{padding:10px 0;display:grid;gap:10px}\n.portal-gate-waves{display:grid;gap:8px}.portal-gate-wave{display:grid;grid-template-columns:80px minmax(160px,1fr) minmax(100px,140px) auto;align-items:end;gap:8px;border:1px solid rgba(82,160,218,.16);border-radius:10px;padding:9px}\n.portal-gate-wave label,.portal-gate-round-body label,.portal-gate-reward label{display:flex;flex-direction:column;gap:5px;font-size:11px}\n.portal-gate-wave input,.portal-gate-wave select,.portal-gate-round input,.portal-gate-reward input,.portal-gate-reward select{width:100%;min-height:34px;padding:7px;background:#091b30;color:#e4f7ff;border:1px solid #2b6687;border-radius:8px}\n.portal-gate-reward{border-top:1px solid rgba(90,180,255,.22);padding-top:10px;margin:12px 0}.portal-gate-reward h5{font-size:12px;margin:0 0 8px;color:#f4d488}\n@media(max-width:720px){.portal-gate-wave{grid-template-columns:1fr 1fr}.portal-gate-wave>b{grid-column:1/-1}.portal-gate-wave>button{grid-column:1/-1}}\n`);
replace('package.json','"version": "19.0.5"','"version": "19.0.6"');
replace('package.json','v19.0.5-adm-phase1-visual-editors','v19.0.6-adm-phase2-portals');
write('CHANGELOG.md',`## V19.0.6 — ADM fase 2 (Portais Astrais, ondas e economia)\n- Editor visual para Aurora, Nexus e Eclipse: NPCs, ondas, rounds, intervalos, escalas e recompensas.\n- Configuracao versionada no Supabase, protegida por RPC administrativa e limites de quantidade.\n- Novas vidas nao saem do Materializador: o antigo premio raro vira bonus de salto. Reservas anteriores continuam utilizaveis.\n- Vida adicional custa 10.000 STL (na base X-1, autorizacao pelo servidor).\n- Corrigida normalizacao que restaurava vida zero em determinados saves.\n- Tentativas iniciadas preservam o snapshot das regras ate a conclusao.\n- SQL obrigatorio: sql/V19_0_6_ADM_PORTAIS.sql.\n\n`+read('CHANGELOG.md'));

// Verificacao local antes de substituir os arquivos. Sem mexer no projeto se algo falhar.
const temp=fs.mkdtempSync(path.join(work,'.stellar-phase2-check-'));
try{
 for(const f of ['public/game.js','public/api.js','server/index.js']){
   const out=path.join(temp,path.basename(f));fs.writeFileSync(out,read(f));
   execFileSync(process.execPath,['--check',out],{stdio:'pipe'});
 }
}finally{fs.rmSync(temp,{recursive:true,force:true});}
// Aplica todo o pacote em arquivos de codigo. O usuario decide quando subir Git e executar SQL.
for(const f of files){fs.writeFileSync(path.join(work,f),read(f),'utf8');}
const sqlDir=path.join(work,'sql');fs.mkdirSync(sqlDir,{recursive:true});
const sqlFrom=path.join(bundle,'sql/V19_0_6_ADM_PORTAIS.sql'),sqlTo=path.join(sqlDir,'V19_0_6_ADM_PORTAIS.sql');
if(path.resolve(sqlFrom)!==path.resolve(sqlTo))fs.copyFileSync(sqlFrom,sqlTo);
console.log('✔ Stellar Legacy V19.0.6 — Fase 2 aplicada em',work);
console.log('✔ Codigo validado com node --check (game, api, server).');
console.log('⚠ Aplique sql/V19_0_6_ADM_PORTAIS.sql antes de publicar o novo codigo.');
console.log('⚠ Revise o diff Git, teste as 3 portas e so depois publique no Render.');
