STELLAR LEGACY V47.7.3 • PERFORMANCE RESCUE / FRONTIER ADM FIX
===============================================================

PATCH incremental sobre 47.7.2. Não contém nem executa SQL.

1. FPS: remove o teto de 30 FPS do perfil BAIXA; permite até 120 FPS quando o dispositivo e o rAF suportarem, sem aumentar efeitos, resolução ou densidade. NÃO GARANTE 120 FPS no aparelho.
2. IA: os bots recalculam o alvo/movimento e enviam seus estados com cadência de 150 ms (antes 300 ms). Mesmo número máximo de bots, mesmos danos, recarga e limites.
3. Mapas U-X: valida o status do ADM autenticado antes de negar a entrada por nível em U-1, U-2 e U-3; servidor continua autoritativo. Ao entrar em U-X vazio, o servidor reconcilia os NPCs com a configuração online existente.
4. Preserva navegação linear, bloqueios de jogadores comuns, facções, recompensas, saves, mineracao e conquistas.

INFRAESTRUTURA: Render nao suporta Sao Paulo; mover Supabase de Sao Paulo para Virginia requer novo projeto e migracao completa de Auth/DB/Storage. Nenhuma migracao foi realizada, para preservar dados e evitar cobranças.

INSTALAÇÃO:
- Remova qualquer ZIP antigo da raiz do repositório e envie SOMENTE este ZIP.
- Execute GitHub Actions / Instalador Universal.
- Confira npm run check e npm test, e aguarde a publicação do Render.
- Teste perfil BAIXA com monitor de FPS, PvP com 6-12 bots e mapa U-1 com a conta ADM abaixo do nível 20; depois compare com 47.7.2.

VALIDAÇÃO: testes locais da lógica de patches, motor de bots e qualidade foram executados em fixtures; teste end-to-end real e medições de FPS ainda dependem do GitHub e do aparelho.
