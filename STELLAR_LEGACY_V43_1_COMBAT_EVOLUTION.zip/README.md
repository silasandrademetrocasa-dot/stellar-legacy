STELLAR LEGACY — COMBAT EVOLUTION • atualização incremental V42.6.2 → V43.1.0

1. Faça backup antes de instalar.
2. Aplique o arquivo sql/STELLAR_V43_1_COMBAT_EVOLUTION.sql no Supabase.
3. Envie este ZIP (somente ele) à raiz do GitHub e use o Instalador Universal.
4. Valide a Forja e o ADM com contas de teste. O dano PvE Astral inicia DESATIVADO por segurança.
5. Após os testes de danos, munições, armas e configurações, o ADM pode ativar a Lança Eclipse para PvE. Nunca ative diretamente sem a homologação.

Incluído: bônus de dano PvE até 4% para Lança Eclipse, por configuração, verificado no banco; API de controle pelo ADM; teto de anomalia conservador na sala de NPCs quando benefício estiver habilitado; equipamentos defensivos ainda sem buffs.

NÃO INCLUÍDO: servidor totalmente autoritativo em todos os tipos de combate; PvP reescrito; bônus de escudo/velocidade; raids. Esses recursos permanecem para a próxima validação. Sem alteração destrutiva de save/inventário.
