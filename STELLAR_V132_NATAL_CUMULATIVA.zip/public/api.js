import {offlineFarmDirectActivityAllowedV103} from './modules/offline-farm-activity-v103.js?v=47.7.63';
import {createReadCoalescerV104} from './modules/read-coalescer-v104.js?v=47.7.63';
import {persistSessionV101,loadPersistedSessionV101,clearPersistedSessionV101} from './modules/login-persistence-v101.js';
const SESSION_KEY = 'stellarLegacyV4Session';
const GOOGLE_OAUTH_PENDING_KEY = 'stellarLegacyGoogleOAuthPendingV18216';
let session = null;
let currentUser = null;
let configPromise = null;
let sessionReplacementNotified = false;
const coalesceReadV104=createReadCoalescerV104();

async function readJson(res) {
  return res.json().catch(async () => {
    const text = await res.text().catch(() => '');
    return text ? { error: text } : {};
  });
}

function notifySessionReplaced(message = 'Sua conta foi acessada em outro dispositivo.', code = 'SESSION_REPLACED') {
  if (sessionReplacementNotified) return;
  sessionReplacementNotified = true;
  const userId = currentUser?.id || null;
  signOutLocal();
  try {
    window.dispatchEvent(new CustomEvent('stellar-session-replaced', {
      detail: { message, userId, code },
    }));
  } catch {}
}

// STELLAR_NETWORK_RECOVERY_V4831: transport failure must never be mistaken for a revoked login.
function verifiedAuthDenialV4831(e){
  return !!e&&(['SESSION_REPLACED','SESSION_REQUIRED','ACCOUNT_BANNED'].includes(e.code)||[401,403].includes(Number(e.status)));
}
async function boundedFetchV4831(url,options={},duration=18000){
  const controller=new AbortController();
  let timedOut=false;
  const upstream=options.signal;
  const onAbort=()=>controller.abort();
  if(upstream){if(upstream.aborted)controller.abort();else upstream.addEventListener('abort',onAbort,{once:true});}
  const timer=setTimeout(()=>{timedOut=true;controller.abort();},duration);
  try{
    const res=await fetch(url,{...options,signal:controller.signal});
    // JSON read is also bounded; stalled response bodies must release operation locks.
    const body=await readJson(res);
    return {res,body};
  }catch(e){
    const err=new Error(timedOut?'Tempo limite de comunicação excedido.':'Conexão temporariamente indisponível.');
    err.code=timedOut?'NETWORK_TIMEOUT':'NETWORK_OFFLINE';
    if(upstream?.aborted)err.code='REQUEST_ABORTED';
    throw err;
  }finally{clearTimeout(timer);if(upstream)upstream.removeEventListener('abort',onAbort);}
}

async function serverFetch(path, options = {}, withAuth = false) {
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  if (withAuth) {
    if (!session?.access_token) throw new Error('Sessão ausente.');
    headers.Authorization = `Bearer ${session.access_token}`;
    if (session?.game_session_id) headers['X-Game-Session-Id'] = session.game_session_id;
  }

  const requestSession=saveSessionKey();
  const fetchBody=()=>boundedFetchV4831(path,{...options,headers,cache:'no-store'});
  const eligible=(!options.method||options.method.toUpperCase()==='GET')&&!options.body&&!options.signal;
  const {res,body} = await (eligible?coalesceReadV104('render|'+String(session?.game_session_id||'public')+'|'+String(session?.access_token||'')+'|'+path+'|'+JSON.stringify(headers),fetchBody):fetchBody());
  if (!res.ok) {
    const msg = body?.error || body?.message || `Erro ${res.status}`;
    const err = new Error(String(msg));
    err.status = res.status;
    err.code = body?.code || null;
    if (withAuth && requestSession===saveSessionKey() && ['SESSION_REPLACED','SESSION_REQUIRED','ACCOUNT_BANNED'].includes(err.code)) {
      notifySessionReplaced(String(msg), err.code);
    }
    throw err;
  }
  return body;
}

async function getConfig() {
  if (!configPromise) {
    configPromise = boundedFetchV4831('/api/config',{cache:'no-store'})
      .then(({res,body}) => {
        if (!res.ok) throw new Error(body.error || 'Supabase não configurado.');
        if (!body.supabaseUrl || !body.supabasePublishableKey) throw new Error('Configuração pública do Supabase incompleta.');
        return {
          url: String(body.supabaseUrl).replace(/\/+$/, ''),
          key: String(body.supabasePublishableKey),
        };
      }).catch(e=>{configPromise=null;throw e;});
  }
  return configPromise;
}

async function supabaseFetch(path, options = {}, withAuth = false) {
  // V103: scripts do jogo fazem chamadas diretas ao PostgREST. A camada HTTP
  // do Render não consegue protegê-las; impedir a operação ANTES de enviar.
  const farmActive=typeof document!=='undefined'&&document.body?.classList.contains('stellar-offline-active-v485');
  if(withAuth&&!offlineFarmDirectActivityAllowedV103(path,options.method||'GET',farmActive)){
    const error=new Error('Farm Offline ativo: operação que altera seu progresso bloqueada. Consulte os menus e finalize o farm antes de batalhar/comprar/evoluir.');
    error.code='FARM_OFFLINE_ACTIVE';error.status=409;throw error;
  }
  const { url, key } = await getConfig();
  const headers = {
    apikey: key,
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  if (withAuth) {
    if (!session?.access_token) throw new Error('Sessão ausente.');
    headers.Authorization = `Bearer ${session.access_token}`;
  }

  const requestSession=saveSessionKey();
  const fetchBody=()=>boundedFetchV4831(`${url}${path}`,{...options,headers});
  const safeRpcRead=(options.method||'GET').toUpperCase()==='POST'&&/^\/rest\/v1\/rpc\/(?:get_game_runtime_public_v1813|get_npc_runtime_config_v1811|get_world_runtime_config_v1814|get_shops_runtime_config_v1817c|get_systems_runtime_config_v1815|get_battle_pass_runtime_config_v1817b|get_balance_runtime_v1909|get_bonus_box_config_v1825|get_galaxy_gate_config_v1906)$/.test(path);
  const readOnly=((!options.method||options.method.toUpperCase()==='GET')||safeRpcRead)&&!options.signal;
  const {res,body} = await (readOnly?coalesceReadV104('sql|'+String(session?.game_session_id||'public')+'|'+String(session?.access_token||'')+'|'+(options.method||'GET')+'|'+path+'|'+String(options.body||'')+'|'+JSON.stringify(headers),fetchBody):fetchBody());
  if (!res.ok) {
    const msg = body?.msg || body?.message || body?.error_description || body?.error || `Erro ${res.status}`;
    throw new Error(String(msg));
  }
  return body;
}

function setSession(nextSession, user = null) {
  if(currentUser?.id!==user?.id || session?.game_session_id!==nextSession?.game_session_id)clearSaveBaseline();
  session = nextSession;
  currentUser = user;
  if (session?.game_session_id) sessionReplacementNotified = false;
  // Web: sessão da aba. APK: token de renovação opcional em cofre criptografado.
  try { sessionStorage.setItem(SESSION_KEY, JSON.stringify({ session, user: currentUser })); } catch {}
  try { localStorage.removeItem(SESSION_KEY); } catch {}
  persistSessionV101(session,currentUser);
}

function sessionFromAuth(body) {
  if (!body?.access_token) return null;
  const now = Math.floor(Date.now() / 1000);
  return {
    access_token: body.access_token,
    refresh_token: body.refresh_token,
    expires_at: body.expires_at || (body.expires_in ? now + Number(body.expires_in) : null),
    game_session_id: body.game_session_id || null,
  };
}

async function upsertProfile(user, callsign = '') {
  if (!user?.id || !session?.access_token) return;
  const preferred = (callsign || user.user_metadata?.callsign || user.email?.split('@')[0] || 'Pilot').slice(0, 24);
  await supabaseFetch('/rest/v1/profiles?on_conflict=id', {
    method: 'POST',
    headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
    body: JSON.stringify({ id: user.id, callsign: preferred, updated_at: new Date().toISOString() }),
  }, true);
}

export function getSession() { return session; }
export function getSessionCredentials() { return { accessToken: session?.access_token || '', gameSessionId: session?.game_session_id || '' }; }
export function getUser() { return currentUser; }

export async function signUp({ callsign, email, password }) {
  const body = await serverFetch('/api/auth/signup', {
    method: 'POST',
    body: JSON.stringify({
      callsign: String(callsign).trim().slice(0, 24),
      email: String(email).trim().toLowerCase(),
      password,
    }),
  });

  const nextSession = body.session || null;
  const user = body.user || null;
  if (nextSession && user) setSession(nextSession, user);

  return {
    user,
    session: nextSession,
    requires_confirmation: Boolean(body.requires_confirmation),
  };
}

export async function requestPasswordReset(email) {
  const value = String(email || '').trim().toLowerCase();
  if (!value || !value.includes('@')) throw new Error('Informe um e-mail válido.');
  const redirectTo = `${window.location.origin}${window.location.pathname || '/'}?recovery=1`;
  try {
    await supabaseFetch(`/auth/v1/recover?redirect_to=${encodeURIComponent(redirectTo)}`, {
      method: 'POST',
      body: JSON.stringify({ email: value }),
    });
  } catch (err) {
    await supabaseFetch('/auth/v1/recover', {
      method: 'POST',
      body: JSON.stringify({ email: value }),
    });
  }
  return { ok: true };
}

export async function restorePasswordRecoveryFromUrl() {
  const hash = new URLSearchParams(String(window.location.hash || '').replace(/^#/, ''));
  const query = new URLSearchParams(window.location.search || '');
  const type = hash.get('type') || query.get('type');
  const accessToken = hash.get('access_token');
  if (type !== 'recovery' || !accessToken) return null;
  const refreshToken = hash.get('refresh_token') || '';
  const expiresIn = Number(hash.get('expires_in') || 3600);
  session = {
    access_token: accessToken,
    refresh_token: refreshToken,
    expires_at: Math.floor(Date.now() / 1000) + expiresIn,
    game_session_id: null,
  };
  try {
    const user = await supabaseFetch('/auth/v1/user', {}, true);
    currentUser = {
      id: user.id,
      email: user.email,
      callsign: user.user_metadata?.callsign || user.email?.split('@')[0] || 'Pilot',
    };
    setSession(session, currentUser);
    history.replaceState({}, document.title, window.location.pathname || '/');
    return { session, user: currentUser, recovery: true };
  } catch (err) {
    signOutLocal();
    throw new Error('O link de recuperação expirou ou é inválido. Solicite outro e-mail.');
  }
}

// V18.2.16 — Google OAuth (redirect na mesma aba, sem gravar tokens permanentemente).
// Usa Supabase Auth como identidade e o backend como guardião da sessão única.
export async function beginGoogleSignIn() {
  const { url } = await getConfig();
  const status = await supabaseFetch('/auth/v1/settings');
  if (status?.external?.google !== true) {
    throw new Error('Google ainda não está habilitado no Supabase. Ative Authentication > Providers > Google antes de testar.');
  }
  if (session?.game_session_id) {
    throw new Error('Saia da conta atual antes de entrar com outra conta Google.');
  }
  const redirectTo = `${window.location.origin}${window.location.pathname || '/'}`;
  const request = new URL(`${url}/auth/v1/authorize`);
  request.searchParams.set('provider', 'google');
  request.searchParams.set('redirect_to', redirectTo);
  // O estado é de curta duração e só vale nesta aba. Não salvamos tokens OAuth no URL.
  sessionStorage.setItem(GOOGLE_OAUTH_PENDING_KEY, JSON.stringify({ at: Date.now(), redirectTo }));
  window.location.assign(request.toString());
}

export async function restoreGoogleSignInFromUrl() {
  const raw = sessionStorage.getItem(GOOGLE_OAUTH_PENDING_KEY);
  const hash = new URLSearchParams(String(window.location.hash || '').replace(/^#/, ''));
  const query = new URLSearchParams(String(window.location.search || ''));
  const oauthError = hash.get('error') || query.get('error');
  const token = hash.get('access_token');
  // Se não iniciamos este fluxo nesta aba, não aceitamos tokens inesperados.
  if (!raw) return null;
  let pending = null;
  try { pending = JSON.parse(raw); } catch {}
  const fresh = Number.isFinite(Number(pending?.at)) && Date.now() - Number(pending.at) <= 15 * 60 * 1000;
  const sameOrigin = pending?.redirectTo === `${window.location.origin}${window.location.pathname || '/'}`;
  if (!fresh || !sameOrigin) {
    sessionStorage.removeItem(GOOGLE_OAUTH_PENDING_KEY);
    if (token || oauthError) history.replaceState({}, document.title, window.location.pathname || '/');
    throw new Error('O login do Google expirou. Tente novamente.');
  }
  if (!token && !oauthError) return null;
  // Não manter access_token / refresh_token no histórico da navegação.
  sessionStorage.removeItem(GOOGLE_OAUTH_PENDING_KEY);
  history.replaceState({}, document.title, window.location.pathname || '/');
  if (oauthError) {
    throw new Error('A autenticação pelo Google foi cancelada ou não autorizada. Tente novamente.');
  }
  const refreshToken = hash.get('refresh_token');
  if (!refreshToken || hash.get('token_type')?.toLowerCase() !== 'bearer') {
    throw new Error('O Google não retornou uma sessão válida. Tente novamente.');
  }
  const body = await serverFetch('/api/auth/google/session', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: '{}',
  });
  if (!body?.game_session_id || !body?.user?.id) throw new Error('Não foi possível confirmar a sessão do jogo.');
  const now = Math.floor(Date.now() / 1000);
  setSession({
    access_token: token,
    refresh_token: refreshToken,
    expires_at: Number(hash.get('expires_at')) || now + Number(hash.get('expires_in') || 3600),
    game_session_id: body.game_session_id,
  }, body.user);
  return { user: body.user, session, provider: 'google' };
}

export async function signIn({ email, password }) {
  const body = await serverFetch('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({
      email: String(email).trim().toLowerCase(),
      password,
    }),
  });
  if (!body?.session?.access_token || !body?.user) throw new Error('Login inválido.');
  setSession(body.session, body.user);
  return { user: body.user, session: body.session };
}

export function signOutLocal() {
  clearSaveBaseline();
  clearPersistedSessionV101();
  session = null;
  currentUser = null;
  try { sessionStorage.removeItem(SESSION_KEY); } catch {}
  try { localStorage.removeItem(SESSION_KEY); } catch {}
}

let lastRefreshErrorV101=null;
async function refreshSession() {
  lastRefreshErrorV101=null;
  if (!session?.refresh_token) return false;
  const key=saveSessionKey();
  try {
    const body = await serverFetch('/api/auth/refresh', {
      method: 'POST',
      body: JSON.stringify({ refresh_token: session.refresh_token, game_session_id: session.game_session_id }),
    });
    checkSaveSession(key);
    if (!body?.session?.access_token || !body?.user) throw new Error('Sessão não renovada');
    setSession(body.session, body.user);
    return true;
  } catch (err) {
    if(key!==saveSessionKey())return false;
    lastRefreshErrorV101=err;
    if(verifiedAuthDenialV4831(err))signOutLocal();
    // Rede indisponível NÃO elimina o login criptografado do APK.
    return false;
  }
}

async function authedServerFetch(path, options = {}, retry = true) {
  const key=saveSessionKey();
  try {
    return await serverFetch(path, options, true);
  } catch (err) {
    if (['SESSION_REPLACED','SESSION_REQUIRED'].includes(err?.code)) throw err;
    checkSaveSession(key);
    const authish = err?.status === 401 || /jwt|token|expired|unauthorized|sessão|401/i.test(String(err?.message || err));
    if (retry && authish && await refreshSession()){checkSaveSession(key);return authedServerFetch(path, options, false);}
    throw err;
  }
}

async function authedSupabaseFetch(path, options = {}, retry = true) {
  try {
    return await supabaseFetch(path, options, true);
  } catch (err) {
    const msg = String(err?.message || err);
    const authish = /jwt|token|expired|unauthorized|401/i.test(msg);
    if (retry && authish && await refreshSession()) return authedSupabaseFetch(path, options, false);
    throw err;
  }
}

let lastRestoreErrorV101=null;
export function getSessionRestoreErrorV101(){return lastRestoreErrorV101;}
export async function restoreSession() {
  lastRestoreErrorV101=null;
  let stored=null;
  try {
    // Primeiro tenta a sessão da aba, depois o cofre Android (nunca localStorage).
    const raw=sessionStorage.getItem(SESSION_KEY);
    if(raw) stored=JSON.parse(raw);
  }catch{}
  if(!stored?.session) stored=loadPersistedSessionV101();
  if(!stored?.session)return null;
  try {
    session=stored.session;
    currentUser=stored.user||null;
    if(!session?.game_session_id || (!session?.access_token && !session?.refresh_token)){
      const e=new Error('Sessão antiga; entre novamente.');e.code='SESSION_REQUIRED';throw e;
    }
    // O processo Android pode ter sido encerrado: access_token não é salvo no cofre.
    // Renova usando a RPC oficial que mantém a proteção de sessão única.
    const expiry=Number(session.expires_at)||0;
    if(!session.access_token || !expiry || expiry<=Math.floor(Date.now()/1000)+90){
      if(!await refreshSession()){
        lastRestoreErrorV101=lastRefreshErrorV101||new Error('Não foi possível renovar a sessão.');
        return null;
      }
    }
    const body=await authedServerFetch('/api/auth/me');
    currentUser=body.user;
    setSession(session,currentUser);
    return {session,user:currentUser};
  }catch(err){
    lastRestoreErrorV101=err;
    // 401/403 ou sessão substituída: desautorizar. 5xx/timeout: manter cofre.
    if(verifiedAuthDenialV4831(err))signOutLocal();
    return null;
  }
}

export async function checkGameSession() {
  if (!session?.access_token || !session?.game_session_id) return false;
  const body = await authedServerFetch('/api/auth/session-status', {}, false);
  return Boolean(body?.active);
}

export async function endGameSession() {
  if (!session?.access_token || !session?.game_session_id) {
    signOutLocal();
    return;
  }
  try {
    await authedServerFetch('/api/auth/logout', { method: 'POST', body: '{}' }, false);
  } finally {
    signOutLocal();
  }
}

let serverSaveRevisionV119=null;
let saveToken=null;
let activeBaseline=0;
const readBaselines=new WeakMap();
function clearSaveBaseline(){
  serverSaveRevisionV119=null;
  saveToken=null;
  activeBaseline++;
}
function saveSessionKey(){return JSON.stringify([currentUser?.id,session?.game_session_id]);}
function checkSaveSession(key){
  if(key!==saveSessionKey())throw Object.assign(new Error('Sessão de salvamento alterada.'),{code:'SAVE_SESSION_CHANGED'});
}
export function adoptSaveRead(read){
  const meta=readBaselines.get(read);
  if(!meta)return;
  checkSaveSession(meta.sessionKey);
  serverSaveRevisionV119=meta.revision;
  saveToken=meta.token;
  activeBaseline++;
}
function saveRevision(value){
  if(value==null)return null;
  if(!Number.isSafeInteger(Number(value))||Number(value)<0)throw new Error('Revisão de save inválida.');
  return Number(value);
}
export function knownSaveRevisionV119(){return serverSaveRevisionV119;}
export async function loadCloudSave() {
  if (!currentUser?.id) throw new Error('Usuário não identificado.');
  const sessionKey=saveSessionKey();
  const body=await authedServerFetch('/api/save');
  checkSaveSession(sessionKey);
  if(!body||!Object.hasOwn(body,'state'))throw new Error('Leitura do progresso incompleta.');
  const read={state:body.state,updated_at:body.updated_at||null,reset_epoch:Number(body.reset_epoch)||0,
    revision:saveRevision(body.revision)};
  const meta={sessionKey,revision:read.revision,token:body.save_token??null};
  readBaselines.set(read,meta);
  if(read.state)readBaselines.set(read.state,meta);
  return read;
}

export async function saveCloudSave(state, equipmentMutationV1062=null, saveMetaV119=null) {
  if (!currentUser?.id) throw new Error('Usuário não identificado.');
  const key=saveSessionKey(), baseline=activeBaseline;
  const result=await authedServerFetch('/api/save', {
    method: 'PUT',
    body: JSON.stringify({ state, ...(equipmentMutationV1062?{equipmentMutationV1062}:{}),
      ...(saveMetaV119?.operation_id?{operation_id:saveMetaV119.operation_id}:{}),
      ...(serverSaveRevisionV119!=null?{expected_revision:serverSaveRevisionV119}:{expected_token:saveToken}) }),
  });
  checkSaveSession(key);
  if(result?.ok!==true)throw new Error('Save sem confirmação.');
  if(baseline!==activeBaseline)throw Object.assign(new Error('O progresso mudou durante a gravação.'),{code:'SAVE_REVISION_CONFLICT'});
  serverSaveRevisionV119=saveRevision(result.revision);
  saveToken=result.save_token??null;
  activeBaseline++;
  return result;
}

export async function updateCallsign(callsign) {
  const preferred = String(callsign || '').trim().replace(/\s+/g, ' ').slice(0, 24);
  if (preferred.length < 3) throw new Error('O nome precisa ter pelo menos 3 caracteres.');
  const body = await authedServerFetch('/api/account/callsign', {
    method: 'PUT',
    body: JSON.stringify({ callsign: preferred }),
  });
  if (!body?.user) throw new Error('Não foi possível confirmar o novo nome.');
  currentUser = body.user;
  setSession(session, currentUser);
  return currentUser;
}

export async function updatePassword(password) {
  const value = String(password || '');
  if (value.length < 6) throw new Error('A nova senha precisa ter pelo menos 6 caracteres.');
  await authedSupabaseFetch('/auth/v1/user', {
    method: 'PUT',
    body: JSON.stringify({ password: value }),
  });
  return { ok: true };
}

export async function loadRankings() {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/get_public_rankings', {
    method: 'POST',
    body: JSON.stringify({}),
  });
  return Array.isArray(rows) ? rows : [];
}

export async function loadAuctionBids() {
  if (!currentUser?.id) throw new Error('Usuário não identificado.');
  const rows = await authedSupabaseFetch(`/rest/v1/auction_bids?user_id=eq.${encodeURIComponent(currentUser.id)}&status=eq.active&select=*&order=updated_at.desc`);
  return Array.isArray(rows) ? rows : [];
}

export async function saveAuctionBidOnline({ hourKey, lotRef, userBid, lot }) {
  if (!currentUser?.id) throw new Error('Usuário não identificado.');
  const rows = await authedSupabaseFetch('/rest/v1/auction_bids?on_conflict=user_id,hour_key,lot_ref', {
    method: 'POST',
    headers: { Prefer: 'resolution=merge-duplicates,return=representation' },
    body: JSON.stringify({
      user_id: currentUser.id,
      hour_key: hourKey,
      lot_ref: lotRef,
      user_bid: Math.max(0, Math.round(Number(userBid) || 0)),
      lot: lot || {},
      status: 'active',
      updated_at: new Date().toISOString(),
    }),
  });
  return Array.isArray(rows) ? rows[0] || null : null;
}

export async function markAuctionBidStatusOnline({ hourKey, lotRef, status }) {
  if (!currentUser?.id) throw new Error('Usuário não identificado.');
  await authedSupabaseFetch(`/rest/v1/auction_bids?user_id=eq.${encodeURIComponent(currentUser.id)}&hour_key=eq.${encodeURIComponent(hourKey)}&lot_ref=eq.${encodeURIComponent(lotRef)}`, {
    method: 'PATCH',
    headers: { Prefer: 'return=minimal' },
    body: JSON.stringify({ status, updated_at: new Date().toISOString() }),
  });
  return { ok: true };
}

export async function loadAuctionMarket(hourKey) {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/get_auction_market', {
    method: 'POST',
    body: JSON.stringify({ p_hour_key: String(hourKey || '') }),
  });
  return Array.isArray(rows) ? rows : [];
}

export async function placeAuctionBidOnline({ hourKey, lotRef, userBid, lot }) {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/place_auction_bid_online', {
    method: 'POST',
    body: JSON.stringify({
      p_hour_key: String(hourKey || ''),
      p_lot_ref: String(lotRef || ''),
      p_user_bid: Math.max(0, Math.round(Number(userBid) || 0)),
      p_lot: lot || {},
    }),
  });
  return Array.isArray(rows) ? rows[0] || null : null;
}

export async function upsertPlayerPresenceOnline(payload) {
  if (!currentUser?.id) throw new Error('Usuário não identificado.');
  await authedSupabaseFetch('/rest/v1/player_presence?on_conflict=user_id', {
    method: 'POST',
    headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
    body: JSON.stringify({
      user_id: currentUser.id,
      callsign: String(payload.callsign || currentUser.callsign || 'Pilot').slice(0, 24),
      map_id: String(payload.mapId || 'x1'),
      territory_faction: String(payload.territoryFaction || 'battle'),
      x: Number(payload.x || 0),
      y: Number(payload.y || 0),
      angle: Number(payload.angle || 0),
      ship_id: String(payload.shipId || 'phoenix'),
      faction: payload.faction || null,
      pilot_title: String(payload.pilotTitle || 'Piloto Estelar').slice(0, 64),
      level: Math.max(1, Number(payload.level || 1)),
      hp: Math.max(0, Math.round(Number(payload.hp || 0))),
      max_hp: Math.max(0, Math.round(Number(payload.maxHp || 0))),
      shield: Math.max(0, Math.round(Number(payload.shield || 0))),
      max_shield: Math.max(0, Math.round(Number(payload.maxShield || 0))),
      updated_at: new Date().toISOString(),
    }),
  });
  return { ok: true };
}

export async function loadMapPresenceOnline(mapId, territoryFaction='battle') {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/get_map_presence_v12', {
    method: 'POST',
    body: JSON.stringify({
      p_map_id: String(mapId || 'x1'),
      p_territory_faction: String(territoryFaction || 'battle'),
    }),
  });
  return Array.isArray(rows) ? rows : [];
}

// V17.7.7 • posição autoritativa separada do save econômico.
// Bootstrap-critical: passa pelo próprio servidor do jogo. Isso evita que uma RPC direta
// navegador -> Supabase segure a inicialização do mapa/NPCs quando a rota externa estiver lenta.
export async function savePlayerLocationCheckpointOnline(payload, { keepalive = false } = {}) {
  if (!currentUser?.id) return null;
  return authedServerFetch('/api/player/location', {
    method: 'POST',
    keepalive: Boolean(keepalive),
    body: JSON.stringify({
      mapId: String(payload?.mapId || 'x1'),
      territoryFaction: payload?.territoryFaction == null ? null : String(payload.territoryFaction),
      x: Number(payload?.x || 0),
      y: Number(payload?.y || 0),
      angle: Number(payload?.angle || 0),
      savedAt: Math.max(0, Math.trunc(Number(payload?.savedAt || Date.now()))),
    }),
  }, false);
}

export async function loadPlayerLocationCheckpointOnline() {
  if (!currentUser?.id) return null;
  const body = await authedServerFetch('/api/player/location', {}, false);
  return body?.location ?? body ?? null;
}

export async function listClansOnline() {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/list_clans_v12', {
    method: 'POST', body: JSON.stringify({}),
  });
  return Array.isArray(rows) ? rows : [];
}

export async function loadMyClanOnline() {
  return authedSupabaseFetch('/rest/v1/rpc/get_my_clan_v12', {
    method: 'POST', body: JSON.stringify({}),
  });
}

export async function createClanOnline({name, tag}) {
  return authedSupabaseFetch('/rest/v1/rpc/create_clan_v12', {
    method: 'POST', body: JSON.stringify({p_name:String(name||''), p_tag:String(tag||'')}),
  });
}

export async function joinClanOnline(clanId) {
  return authedSupabaseFetch('/rest/v1/rpc/join_clan_v12', {
    method: 'POST', body: JSON.stringify({p_clan_id:clanId}),
  });
}

export async function getClanRequestsOnline() {
  return authedSupabaseFetch('/rest/v1/rpc/get_clan_requests_v19', {
    method: 'POST', body: JSON.stringify({}),
  });
}

export async function reviewClanRequestOnline({requestId,approve}) {
  return authedSupabaseFetch('/rest/v1/rpc/review_clan_request_v19', {
    method: 'POST', body: JSON.stringify({p_request_id:requestId,p_approve:!!approve}),
  });
}

export async function cancelClanRequestOnline(requestId) {
  return authedSupabaseFetch('/rest/v1/rpc/cancel_clan_request_v19', {
    method: 'POST', body: JSON.stringify({p_request_id:requestId}),
  });
}

export async function setClanMemberRoleOnline({targetUserId,role}) {
  return authedSupabaseFetch('/rest/v1/rpc/set_clan_member_role_v19', {
    method: 'POST', body: JSON.stringify({p_target_user_id:targetUserId,p_role:role}),
  });
}

export async function leaveClanOnline() {
  return authedSupabaseFetch('/rest/v1/rpc/leave_clan_v12', {
    method: 'POST', body: JSON.stringify({}),
  });
}

export async function donateClanCreditsOnline(amount) {
  return authedSupabaseFetch('/rest/v1/rpc/donate_clan_credits_v12', {
    method: 'POST', body: JSON.stringify({p_amount:Math.max(0,Math.trunc(Number(amount)||0))}),
  });
}

export async function transferClanCreditsOnline({callsign, amount}) {
  return authedSupabaseFetch('/rest/v1/rpc/transfer_clan_credits_v12', {
    method: 'POST', body: JSON.stringify({p_target_callsign:String(callsign||''),p_amount:Math.max(0,Math.trunc(Number(amount)||0))}),
  });
}

export async function claimClanCreditGrantsOnline() {
  return authedSupabaseFetch('/rest/v1/rpc/claim_clan_credit_grants_v12', {
    method: 'POST', body: JSON.stringify({}),
  });
}


export async function recordClanAlienKillOnline({npcType,isBoss=false}) {
  return authedSupabaseFetch('/rest/v1/rpc/record_clan_alien_kill_v12', {
    method: 'POST', body: JSON.stringify({p_npc_type:String(npcType||''),p_is_boss:!!isBoss}),
  });
}

export async function getPremiumShopOnline() {
  return authedSupabaseFetch('/rest/v1/rpc/get_premium_shop_v12', {
    method: 'POST', body: JSON.stringify({}),
  });
}

// V18.2.15: Somente prévia/simulação administrativa, sem pagamento nem recompensas.
export async function getPremiumStageCatalogOnline() {
  return authedSupabaseFetch('/rest/v1/rpc/get_premium_stage_catalog_v1833', {
    method: 'POST', body: JSON.stringify({}),
  });
}
export async function adminPreviewPremiumStageOnline() {
  return authedSupabaseFetch('/rest/v1/rpc/admin_preview_premium_stage_v1832', {
    method: 'POST', body: JSON.stringify({}),
  });
}
export async function adminSimulatePremiumStageOnline(productId, idempotencyKey) {
  return authedSupabaseFetch('/rest/v1/rpc/admin_simulate_premium_checkout_v1832', {
    method: 'POST', body: JSON.stringify({
      p_product_id: String(productId || ''),
      p_idempotency_key: String(idempotencyKey || ''),
    }),
  });
}

export async function testPurchasePremiumOnline(productId) {
  return authedSupabaseFetch('/rest/v1/rpc/test_purchase_premium_v12', {
    method: 'POST', body: JSON.stringify({p_product_id:String(productId||'')}),
  });
}

export async function queuePvpAttackOnline({targetUserId,damage,shieldDrain=false,mapId,territoryFaction}) {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/queue_pvp_attack', {
    method: 'POST',
    body: JSON.stringify({
      p_target_user_id: targetUserId,
      p_damage: Math.max(0,Math.round(Number(damage)||0)),
      p_shield_drain: !!shieldDrain,
      p_map_id: String(mapId||'x1'),
      p_territory_faction: String(territoryFaction||'battle'),
    }),
  });
  return Array.isArray(rows) ? rows[0] || null : null;
}

export async function consumePvpDamageEventsOnline() {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/consume_pvp_damage_events', {
    method: 'POST',
    body: JSON.stringify({}),
  });
  return Array.isArray(rows) ? rows : [];
}


export async function syncArenaProfileOnline(payload) {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/sync_arena_profile', {
    method: 'POST',
    body: JSON.stringify({
      p_callsign: String(payload.callsign || currentUser?.callsign || 'Pilot'),
      p_faction: payload.faction || null,
      p_level: Math.max(1, Math.round(Number(payload.level) || 1)),
      p_ship_id: String(payload.shipId || 'phoenix'),
      p_hp: Math.max(1, Math.round(Number(payload.hp) || 1)),
      p_shield: Math.max(0, Math.round(Number(payload.shield) || 0)),
      p_laser_damage: Math.max(0, Math.round(Number(payload.laserDamage) || 0)),
      p_speed: Math.max(0, Math.round(Number(payload.speed) || 0)),
    }),
  });
  return Array.isArray(rows) ? rows[0] || null : null;
}

export async function loadArenaState() {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/get_arena_state', {
    method: 'POST',
    body: JSON.stringify({}),
  });
  return Array.isArray(rows) ? rows[0] || null : null;
}


export async function loadArenaDailyRewardStatus() {
  const body = await authedSupabaseFetch('/rest/v1/rpc/get_arena_daily_reward_status', {
    method: 'POST',
    body: JSON.stringify({}),
  });
  return Array.isArray(body) ? body[0] || null : body || null;
}

export async function claimArenaDailyReward() {
  const body = await authedSupabaseFetch('/rest/v1/rpc/claim_arena_daily_reward', {
    method: 'POST',
    body: JSON.stringify({}),
  });
  return Array.isArray(body) ? body[0] || null : body || null;
}

export async function loadArenaOpponents() {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/get_arena_opponents', {
    method: 'POST',
    body: JSON.stringify({}),
  });
  return Array.isArray(rows) ? rows : [];
}

export async function loadArenaHistory() {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/get_arena_history', {
    method: 'POST',
    body: JSON.stringify({}),
  });
  return Array.isArray(rows) ? rows : [];
}

export async function arenaAttackOnline(targetUserId) {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/arena_attack_v11', {
    method: 'POST',
    body: JSON.stringify({ p_target_user_id: targetUserId }),
  });
  return Array.isArray(rows) ? rows[0] || null : null;
}

export async function removePlayerPresenceOnline() {
  if (!currentUser?.id) return { ok: true };
  await authedSupabaseFetch(`/rest/v1/player_presence?user_id=eq.${encodeURIComponent(currentUser.id)}`, {
    method: 'DELETE',
    headers: { Prefer: 'return=minimal' },
  });
  return { ok: true };
}



// Leitura autenticada e SEM escrita: domínio no banco enquanto a sala está reconectando.
export async function loadSectorOwnershipOnline(mapId){
  const id=String(mapId||'');
  if(!['b41','b42','b43'].includes(id))throw new Error('Mapa de controle inválido.');
  return authedServerFetch(`/api/world/sector-state?mapId=${encodeURIComponent(id)}`);
}

// ===================== V13.1 WARFRONT =====================
export async function loadWarfrontStateOnline() {
  return authedSupabaseFetch('/rest/v1/rpc/get_warfront_state_v131', {
    method: 'POST', body: JSON.stringify({}),
  });
}

export async function hitWorldBossOnline(damage) {
  return authedSupabaseFetch('/rest/v1/rpc/hit_world_boss_v131', {
    method: 'POST', body: JSON.stringify({p_damage:Math.max(1,Math.round(Number(damage)||0))}),
  });
}

export async function claimWorldBossRewardOnline() {
  return authedSupabaseFetch('/rest/v1/rpc/claim_world_boss_reward_v131', {
    method: 'POST', body: JSON.stringify({}),
  });
}

export async function declareClanWarOnline(targetClanId) {
  return authedSupabaseFetch('/rest/v1/rpc/declare_clan_war_v131', {
    method: 'POST', body: JSON.stringify({p_target_clan_id:targetClanId}),
  });
}

export async function recordClanWarScoreOnline(points, reason='combat') {
  return authedSupabaseFetch('/rest/v1/rpc/record_clan_war_score_v131', {
    method: 'POST', body: JSON.stringify({p_points:Math.max(1,Math.round(Number(points)||0)),p_reason:String(reason||'combat').slice(0,40)}),
  });
}

// ===================== V16 LIVE OPS =====================
export async function loadLiveOpsOnline(force=false) {
  const suffix=force?'?refresh=1':'';
  return authedServerFetch(`/api/live-ops${suffix}`, {}, false);
}

export async function adminUpdateWeekendSettingsOnline(payload){
  return authedServerFetch('/api/admin/runtime/events/central/settings',{method:'POST',body:JSON.stringify(payload)},false);
}
export async function adminUpdateWeekendEventOnline(eventKey,payload){
  return authedServerFetch(`/api/admin/runtime/events/central/event/${encodeURIComponent(String(eventKey||''))}`,{method:'POST',body:JSON.stringify(payload)},false);
}
export async function adminSetManualEventOnline(payload){
  return authedServerFetch('/api/admin/runtime/events/central/manual',{method:'POST',body:JSON.stringify(payload)},false);
}

export async function adminUpdateLiveEventScheduleOnline(eventKey,payload={}) {
  return authedServerFetch(`/api/admin/runtime/events/${encodeURIComponent(String(eventKey||''))}`, {
    method:'POST', body:JSON.stringify(payload&&typeof payload==='object'?payload:{})
  }, false);
}

export async function loadAdminSecurityIncidents(){
  return authedServerFetch('/api/admin/security/incidents');
}
export async function reviewAdminSecurityIncident(id,note){
  return authedServerFetch(`/api/admin/security/incidents/${Number(id)}/review`,{
    method:'POST',body:JSON.stringify({note:String(note||'')})
  });
}

export async function purchaseLiveCatalogOnline(catalogKey,requestId=null) {
  return authedServerFetch('/api/live/purchase', {
    method: 'POST',
    body: JSON.stringify({ catalog_key: String(catalogKey || ''),...(requestId?{request_id:requestId}:{}) }),
  }, false);
}

// V92 • uma compra de suprimentos por chamada; requestId evita duplicação em retry.
export async function purchaseLiveBulkOnline(catalogKey,quantity,requestId,expectedPrice,expectedCurrency,expectedPackSize){
  return authedServerFetch('/api/live/purchase/bulk',{
    method:'POST',body:JSON.stringify({catalog_key:catalogKey,quantity,request_id:requestId,expected_price:expectedPrice,expected_currency:expectedCurrency,expected_pack_size:expectedPackSize})
  },false);
}

export async function economyActionOnline(action, payload = {},requestId=null) {
  return authedServerFetch('/api/economy/action', {
    method: 'POST',
    body: JSON.stringify({ action: String(action || ''), payload: payload && typeof payload === 'object' ? payload : {},...(requestId?{request_id:requestId}:{}) }),
  }, false);
}



// ===================== V18.2.1 CUPONS SQL-FIRST =====================
// Resgate autoritativo: o servidor valida o login e a função SQL entrega o prêmio.
export async function redeemGameCouponOnline(code) {
  return authedServerFetch('/api/coupons/redeem', {
    method: 'POST',
    body: JSON.stringify({ code: String(code||'').trim().toUpperCase().slice(0,64) }),
  });
}

// V19.0.3 • Editor ADM de cupons configuráveis. Operações validadas pelo PostgreSQL.
export async function adminCouponDashboardOnline(){return authedServerFetch('/api/admin/coupons',{},false);}
export async function adminCreateCouponOnline(payload){return authedServerFetch('/api/admin/coupons',{method:'POST',body:JSON.stringify(payload)},false);}
export async function adminSetCouponActiveOnline(code,active){return authedServerFetch(`/api/admin/coupons/${encodeURIComponent(code)}/active`,{method:'POST',body:JSON.stringify({active:!!active})},false);}

// ===================== V16.2 CHAT DOCK =====================
export async function getChatHistoryOnline({channel='global', recipientCallsign='', limit=60}={}) {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/get_chat_history_v16', {
    method: 'POST',
    body: JSON.stringify({
      p_channel: String(channel || 'global'),
      p_recipient_callsign: recipientCallsign ? String(recipientCallsign).trim().slice(0,24) : null,
      p_limit: Math.max(1, Math.min(100, Math.round(Number(limit)||60))),
    }),
  });
  return Array.isArray(rows) ? rows : rows ? [rows] : [];
}

export async function sendChatMessageOnline({channel='global', body='', recipientCallsign=''}={}) {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/send_chat_message_v16', {
    method: 'POST',
    body: JSON.stringify({
      p_channel: String(channel || 'global'),
      p_body: String(body || '').trim().slice(0,240),
      p_recipient_callsign: recipientCallsign ? String(recipientCallsign).trim().slice(0,24) : null,
    }),
  });
  return Array.isArray(rows) ? rows[0] || null : rows || null;
}


// ===================== V16.3 DRONE DESIGNERS =====================
export async function getMyDesignersOnline() {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/get_my_designers_v16', {
    method: 'POST', body: JSON.stringify({}),
  });
  return Array.isArray(rows) ? rows[0] || null : rows || null;
}

export async function setDesignLoadoutOnline({kind, designId=null, droneId=null}={}) {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/set_design_loadout_v16', {
    method: 'POST',
    body: JSON.stringify({
      p_kind: String(kind || ''),
      p_design_id: designId ? String(designId) : null,
      p_drone_id: droneId ? String(droneId) : null,
    }),
  });
  return Array.isArray(rows) ? rows[0] || null : rows || null;
}

export async function claimGateDroneDesignOnline({gate, completion}={}) {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/claim_gate_drone_design_v163', {
    method: 'POST',
    body: JSON.stringify({
      p_gate: String(gate || ''),
      p_completion: Math.max(1, Math.round(Number(completion)||0)),
    }),
  });
  return Array.isArray(rows) ? rows[0] || null : rows || null;
}


export async function claimEventDesignerOnline({eventId, eventKey}={}) {
  const rows = await authedSupabaseFetch('/rest/v1/rpc/claim_event_designer_v165', {
    method: 'POST',
    body: JSON.stringify({
      p_event_id: String(eventId || '').slice(0,160),
      p_event_key: String(eventKey || '').slice(0,64),
    }),
  });
  return Array.isArray(rows) ? rows[0] || null : rows || null;
}


// ===================== ADMIN CONTROL PANEL =====================
export async function getAdminStatus(){
  return authedServerFetch('/api/admin/status');
}
// V47.7.4 — server-authenticated U-X preflight; never takes admin claims from the browser.
export async function frontierAdminAccessV4774(mapId){
  if(!/^u[1-3]$/.test(String(mapId||'')))throw new Error('Setor inválido');
  return authedServerFetch('/api/frontier/admin-entry?mapId='+encodeURIComponent(mapId));
}
export async function adminSearchAccounts(query=''){
  return authedServerFetch(`/api/admin/users?q=${encodeURIComponent(String(query||''))}`);
}
export async function adminRecentActions(){
  return authedServerFetch('/api/admin/actions');
}
export async function adminBanAccount(userId,{minutes=0,reason=''}={}){
  return authedServerFetch(`/api/admin/users/${encodeURIComponent(userId)}/ban`,{method:'POST',body:JSON.stringify({minutes,reason})});
}
export async function adminUnbanAccount(userId){
  return authedServerFetch(`/api/admin/users/${encodeURIComponent(userId)}/unban`,{method:'POST',body:'{}'});
}
export async function adminResetAccount(userId){
  return authedServerFetch(`/api/admin/users/${encodeURIComponent(userId)}/reset`,{method:'POST',body:'{}'});
}
export async function adminDeleteAccount(userId){
  return authedServerFetch(`/api/admin/users/${encodeURIComponent(userId)}`,{method:'DELETE'});
}


// ===================== V17.7.1 TELEMETRY =====================
export async function pushTelemetryBatch(batch={}){
  return authedServerFetch('/api/telemetry',{method:'POST',body:JSON.stringify(batch||{})});
}
export async function adminTelemetryOverview(){
  return authedServerFetch('/api/admin/telemetry');
}
export async function adminPlayerTelemetry(userId){
  return authedServerFetch(`/api/admin/telemetry/${encodeURIComponent(String(userId||''))}`);
}


// ===================== V17.9.0 BATTLE GROUPS =====================
export async function getBattleGroupOnline(){
  const rows=await authedSupabaseFetch('/rest/v1/rpc/get_my_battle_group_v179',{method:'POST',body:'{}'});
  return Array.isArray(rows)?rows[0]||null:rows||null;
}
export async function createBattleGroupOnline(){
  const rows=await authedSupabaseFetch('/rest/v1/rpc/create_battle_group_v179',{method:'POST',body:'{}'});
  return Array.isArray(rows)?rows[0]||null:rows||null;
}
export async function inviteBattleGroupOnline(callsign){
  const rows=await authedSupabaseFetch('/rest/v1/rpc/invite_battle_group_v179',{method:'POST',body:JSON.stringify({p_callsign:String(callsign||'').trim().slice(0,24)})});
  return Array.isArray(rows)?rows[0]||null:rows||null;
}
export async function searchBattleGroupPlayersOnline(query){
  const rows=await authedSupabaseFetch('/rest/v1/rpc/search_battle_group_players_v1793',{method:'POST',body:JSON.stringify({p_query:String(query||'').trim().slice(0,24)})});
  return Array.isArray(rows)?rows[0]||null:rows||null;
}
export async function inviteBattleGroupUserOnline(userId){
  const rows=await authedSupabaseFetch('/rest/v1/rpc/invite_battle_group_user_v1793',{method:'POST',body:JSON.stringify({p_target_user_id:String(userId||'')})});
  return Array.isArray(rows)?rows[0]||null:rows||null;
}
export async function respondBattleGroupInviteOnline(inviteId,accept){
  const rows=await authedSupabaseFetch('/rest/v1/rpc/respond_battle_group_invite_v179',{method:'POST',body:JSON.stringify({p_invite_id:String(inviteId||''),p_accept:!!accept})});
  return Array.isArray(rows)?rows[0]||null:rows||null;
}
export async function leaveBattleGroupOnline(){
  const rows=await authedSupabaseFetch('/rest/v1/rpc/leave_battle_group_v179',{method:'POST',body:'{}'});
  return Array.isArray(rows)?rows[0]||null:rows||null;
}
export async function kickBattleGroupMemberOnline(userId){
  const rows=await authedSupabaseFetch('/rest/v1/rpc/kick_battle_group_member_v179',{method:'POST',body:JSON.stringify({p_target_user_id:String(userId||'')})});
  return Array.isArray(rows)?rows[0]||null:rows||null;
}
export async function setBattleGroupRallyOnline({mapId,territoryFaction,x,y}={}){
  const rows=await authedSupabaseFetch('/rest/v1/rpc/set_battle_group_rally_v179',{method:'POST',body:JSON.stringify({p_map_id:String(mapId||''),p_territory_faction:territoryFaction?String(territoryFaction):null,p_x:Number(x)||0,p_y:Number(y)||0})});
  return Array.isArray(rows)?rows[0]||null:rows||null;
}


// ===================== V18.1.0 DATA DRIVEN CORE =====================
export async function loadRuntimeConfigOnline(refresh=false){
  // V18.1.3+: o navegador lê somente o snapshot validado pelo Render.
  return serverFetch(`/api/runtime/topbar${refresh?'?refresh=1':''}`,{},true);
}

// ===================== V18.1.6B ADMIN INTERFACE EDITOR =====================
export async function adminUpdateRuntimeModuleOnline(moduleKey,payload={}){
  return serverFetch(`/api/admin/runtime/interface/${encodeURIComponent(String(moduleKey||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}


// ===================== V18.1.1 NPC RUNTIME CONFIG =====================
export async function loadNpcRuntimeConfigOnline(refresh=false){
  return serverFetch(`/api/runtime/npcs${refresh?'?refresh=1':''}`,{},true);
}

// ===================== V18.1.6C ADMIN NPC EDITOR =====================
export async function adminUpdateNpcRuntimeOnline(npcKey,payload={}){
  return serverFetch(`/api/admin/runtime/npcs/${encodeURIComponent(String(npcKey||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}
export async function adminUpdateNpcSpawnRuntimeOnline(npcKey,mapId,payload={}){
  return serverFetch(`/api/admin/runtime/npcs/${encodeURIComponent(String(npcKey||''))}/spawns/${encodeURIComponent(String(mapId||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}

// ===================== V18.1.6A ADMIN RUNTIME MONITOR =====================
export async function loadAdminRuntimeMonitorOnline(refresh=false){
  return serverFetch(`/api/admin/runtime-monitor${refresh?'?refresh=1':''}`,{},true);
}


// ===================== V18.1.4 WORLD RUNTIME CONFIG =====================
export async function loadWorldRuntimeConfigOnline(refresh=false){
  return serverFetch(`/api/runtime/world${refresh?'?refresh=1':''}`,{},true);
}

// ===================== V18.1.6D ADMIN WORLD EDITOR =====================
export async function adminUpdateWorldMapOnline(mapId,payload={}){
  return serverFetch(`/api/admin/runtime/world/maps/${encodeURIComponent(String(mapId||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}
export async function adminUpdateWorldResourceOnline(resourceKey,payload={}){
  return serverFetch(`/api/admin/runtime/world/resources/${encodeURIComponent(String(resourceKey||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}
export async function adminUpdateWorldSectorOnline(sectorLabel,payload={}){
  return serverFetch(`/api/admin/runtime/world/sectors/${encodeURIComponent(String(sectorLabel||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}
export async function adminUpdateWorldPortalOnline(portalKey,payload={}){
  return serverFetch(`/api/admin/runtime/world/portals/${encodeURIComponent(String(portalKey||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}
export async function adminUpdateWorldResourcePoolOnline(mapId,resourceKey,payload={}){
  return serverFetch(`/api/admin/runtime/world/maps/${encodeURIComponent(String(mapId||''))}/resources/${encodeURIComponent(String(resourceKey||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}


// ===================== V18.1.5 SYSTEMS RUNTIME CONFIG =====================
export async function loadSystemsRuntimeConfigOnline(refresh=false){
  return serverFetch(`/api/runtime/systems${refresh?'?refresh=1':''}`,{},true);
}

// ===================== V18.1.6E ADMIN SYSTEMS EDITOR =====================
export async function adminUpdateMissionCategoryOnline(category,payload={}){
  return serverFetch(`/api/admin/runtime/systems/missions/${encodeURIComponent(String(category||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}
export async function adminUpdateEconomyServiceOnline(serviceId,payload={}){
  return serverFetch(`/api/admin/runtime/systems/economy/${encodeURIComponent(String(serviceId||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}
export async function adminUpdateCraftingRecipeOnline(recipeId,payload={}){
  return serverFetch(`/api/admin/runtime/systems/crafting/${encodeURIComponent(String(recipeId||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}


// ===================== V18.1.7B BATTLE PASS RUNTIME =====================
export async function loadBattlePassRuntimeConfigOnline(refresh=false){
  return serverFetch(`/api/runtime/pass${refresh?'?refresh=1':''}`,{},true);
}
export async function adminUpdateBattlePassSeasonOnline(seasonKey,payload={}){
  return serverFetch(`/api/admin/runtime/pass/seasons/${encodeURIComponent(String(seasonKey||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}
export async function adminUpdateBattlePassTierOnline(seasonKey,tierNo,payload={}){
  return serverFetch(`/api/admin/runtime/pass/seasons/${encodeURIComponent(String(seasonKey||''))}/tiers/${encodeURIComponent(String(tierNo||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}


// V18.1.7C • Lojas Comum + Premium Data Driven
export async function loadShopsRuntimeConfigOnline(refresh=false){
  return serverFetch(`/api/runtime/shops${refresh?'?refresh=1':''}`,{},true);
}
export async function adminUpdateCommonShopItemOnline(catalogKey,payload={}){
  return serverFetch(`/api/admin/runtime/shops/common/${encodeURIComponent(String(catalogKey||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}
export async function adminUpdatePremiumShopItemOnline(productId,payload={}){
  return serverFetch(`/api/admin/runtime/shops/premium/${encodeURIComponent(String(productId||''))}`,{method:'POST',body:JSON.stringify(payload||{})},true);
}

// V18.2.6 • BOX BÔNUS editável por ADM.
export async function loadBonusConfigOnline(refresh=false){
  return serverFetch(`/api/runtime/bonus${refresh?'?refresh=1':''}`,{},true);
}
export async function adminUpdateBonusConfigOnline(config){
  return serverFetch('/api/admin/runtime/bonus',{method:'POST',body:JSON.stringify({config})},true);
}

// V19.0.6 — ADM Portais Astrais
export async function loadGalaxyGatesOnline(refresh=false){
 return serverFetch('/api/runtime/gates'+(refresh?'?refresh=1':''),{},true);
}
export async function adminUpdateGalaxyGateOnline(key,config){
 return serverFetch('/api/admin/runtime/gates',{method:'POST',body:JSON.stringify({key,config})},true);
}

// V19.0.8 — Criadores visuais de conteudo administrativo (autenticados).
export async function adminUpsertCustomMissionOnline(payload){return serverFetch('/api/admin/runtime/systems/custom-missions',{method:'POST',body:JSON.stringify(payload)},true);}
export async function adminDeleteCustomMissionOnline(key){return serverFetch(`/api/admin/runtime/systems/custom-missions/${encodeURIComponent(key)}`,{method:'DELETE'},true);}
export async function adminCreateCraftRecipeOnline(payload){return serverFetch('/api/admin/runtime/systems/new/crafting',{method:'POST',body:JSON.stringify(payload)},true);}
export async function adminCreateEconomyServiceOnline(payload){return serverFetch('/api/admin/runtime/systems/new/economy',{method:'POST',body:JSON.stringify(payload)},true);}
export async function adminCreatePassSeasonOnline(payload){return serverFetch('/api/admin/runtime/pass/seasons/new',{method:'POST',body:JSON.stringify(payload)},true);}
export async function loadAuctionRulesOnline(){return serverFetch('/api/runtime/auction-rules',{},true);}
export async function adminUpdateAuctionRulesOnline(payload){return serverFetch('/api/admin/runtime/auction-rules',{method:'POST',body:JSON.stringify(payload)},true);}

// V19.0.9 • Balanceamento completo de naves e equipamentos.
export async function loadBalanceRuntimeOnline(force=false){
 return serverFetch(`/api/runtime/balance${force?'?refresh=1':''}`,{},true);
}
export async function adminUpdateBalanceOnline(kind,item_id,fields,expected_version){
 return serverFetch('/api/admin/runtime/balance',{method:'POST',body:JSON.stringify({kind,item_id,fields,expected_version})},true);
}

// Operacoes de Elite — medidas e resgates exclusivamente no servidor.
export async function loadEliteOperationsOnline(){return authedServerFetch('/api/elite',{},false);}
export async function claimEliteOperationOnline(objectiveId){return authedServerFetch('/api/elite/claim',{method:'POST',body:JSON.stringify({objectiveId:String(objectiveId||'')})},false);}

export async function loadAdminEliteObjectivesOnline(){return authedServerFetch('/api/admin/elite/objectives',{},false);}
export async function saveAdminEliteObjectiveOnline(payload){return authedServerFetch('/api/admin/elite/objectives',{method:'POST',body:JSON.stringify(payload)},false);}

// Campanhas e domínio: APIs autenticadas; nenhum campo de pontuação é enviado pelo cliente.
export async function loadWarCampaignsOnline(){return authedServerFetch('/api/war/campaigns',{},false);}
export async function claimWarSupplyOnline(){return authedServerFetch('/api/war/supply/claim',{method:'POST',body:'{}'},false);}
export async function claimWarCampaignOnline(id){return authedServerFetch(`/api/war/campaigns/${encodeURIComponent(String(id))}/claim`,{method:'POST',body:'{}'},false);}
export async function loadAdminWarCampaignsOnline(){return authedServerFetch('/api/admin/war/campaigns',{},false);}
export async function saveAdminWarCampaignOnline(payload){return authedServerFetch('/api/admin/war/campaigns',{method:'POST',body:JSON.stringify(payload)},false);}
export async function saveAdminWarRulesOnline(payload){return authedServerFetch('/api/admin/war/rules',{method:'POST',body:JSON.stringify(payload)},false);}

// Temporadas competitivas, titulos Elite equipaveis e operacoes do universo.
export async function loadCommandOverviewOnline(){return serverFetch('/api/command/overview',{},true);}
export async function claimCompetitiveSeasonOnline(id){return serverFetch(`/api/command/season/${encodeURIComponent(id)}/claim`,{method:'POST'},true);}
export async function equipEliteTitleOnline(objective_id){return serverFetch('/api/command/elite/equip-title',{method:'POST',body:JSON.stringify({objective_id})},true);}
export async function loadCommandAdminOnline(){return serverFetch('/api/command/admin',{},true);}
export async function saveCompetitiveSeasonOnline(data){return serverFetch('/api/command/admin/season',{method:'POST',body:JSON.stringify(data)},true);}
export async function saveWorldDirectiveOnline(data){return serverFetch('/api/command/admin/directive',{method:'POST',body:JSON.stringify(data)},true);}

export async function unequipEliteTitleOnline(){return serverFetch('/api/command/elite/unequip-title',{method:'POST'},true);}

// Missões de clã — métricas verificadas exclusivamente pelo servidor.
export async function loadClanOperationsOnline(){return serverFetch('/api/command/clan/operations',{},true);}
export async function claimClanOperationOnline(id){return serverFetch(`/api/command/clan/operations/${encodeURIComponent(id)}/claim`,{method:'POST',body:'{}'},true);}
export async function saveAdminClanOperationOnline(data){return serverFetch('/api/command/admin/clan-operation',{method:'POST',body:JSON.stringify(data)},true);}

// V34.6 — relay management, game-session authenticated. Mutations never use the public token directly against tables.
export const loadRelayDominationOnline=()=>serverFetch('/api/relay/state',{},true);
export const relayModuleActionOnline=payload=>serverFetch('/api/relay/module',{method:'POST',body:JSON.stringify(payload)},true);
export const claimRelayMissionOnline=id=>serverFetch(`/api/relay/mission/${encodeURIComponent(id)}/claim`,{method:'POST',body:'{}'},true);
export const saveRelayAdminOnline=payload=>serverFetch('/api/relay/admin/rules',{method:'POST',body:JSON.stringify(payload)},true);
export const saveRelayModuleBalanceOnline=payload=>serverFetch('/api/relay/admin/module-balance',{method:'POST',body:JSON.stringify(payload)},true);
export const adminReleaseRelayOnline=payload=>serverFetch('/api/relay/admin/release',{method:'POST',body:JSON.stringify(payload)},true);

export const repairRelayOnline=payload=>serverFetch('/api/relay/repair',{method:'POST',body:JSON.stringify(payload)},true);

// V35: fortifications are server-authenticated, atomic and independent from ship modules.
export const upgradeRelayFortificationOnline=payload=>serverFetch('/api/relay/fortification/upgrade',{method:'POST',body:JSON.stringify(payload)},true);
export const saveRelayFortificationTierOnline=payload=>serverFetch('/api/relay/admin/fortification-tier',{method:'POST',body:JSON.stringify(payload)},true);

// V36 • all Dominion operations are authenticated, persisted and server-authoritative.
export const loadDominionStateOnline=()=>serverFetch('/api/relay/dominion/state',{},true);
export const claimDominionOnline=kind=>serverFetch('/api/relay/dominion/claim',{method:'POST',body:JSON.stringify({kind})},true);
export const declareDominionWarOnline=(targetClanId,startsAt=null)=>serverFetch('/api/relay/dominion/declare',{method:'POST',body:JSON.stringify({targetClanId,startsAt})},true);
export const saveDominionRulesOnline=payload=>serverFetch('/api/relay/dominion/admin/rules',{method:'POST',body:JSON.stringify(payload)},true);
export const claimDominionWarPrizeOnline=warId=>serverFetch('/api/relay/dominion/war/prize',{method:'POST',body:JSON.stringify({warId})},true);

// V37 • Contratos de fronteira sempre verificados no SQL.
export const loadFrontierStateOnline=()=>serverFetch('/api/frontier/state',{},true);
export const claimFrontierContractOnline=contractId=>serverFetch('/api/frontier/claim',{method:'POST',body:JSON.stringify({contractId})},true);
export const craftFrontierTechOnline=()=>serverFetch('/api/frontier/craft',{method:'POST',body:'{}'},true);
export const claimFrontierClanOnline=()=>serverFetch('/api/frontier/clan-claim',{method:'POST',body:'{}'},true);
export const saveFrontierAdminContractOnline=payload=>serverFetch('/api/frontier/admin/contract',{method:'POST',body:JSON.stringify(payload)},true);

// V38.1 — Astral Rewards: sessão autenticada do jogo, nunca service_role no navegador.
export async function loadAstralRewardsV381(){return authedServerFetch('/api/astral-rewards');}
export async function lockAstralRewardV381(gate){return authedServerFetch('/api/astral-rewards/lock',{method:'POST',body:JSON.stringify({gate})});}
export async function claimAstralRewardV381(gate){return authedServerFetch('/api/astral-rewards/claim',{method:'POST',body:JSON.stringify({gate})});}
export async function adminSetAstralRewardV381(gate,config){return authedServerFetch('/api/admin/astral-rewards',{method:'POST',body:JSON.stringify({gate,config})});}

// V39–V42: APIs autenticadas; nenhum acesso direto a segredos.
export async function loadUnifiedExpansionV42(){return authedServerFetch('/api/frontier/v42');}
export async function actUnifiedExpansionV42(action,code,amount=1,idempotencyKey){return authedServerFetch('/api/frontier/v42/action',{method:'POST',body:JSON.stringify({action,code,amount,idempotencyKey})});}
export async function squadUnifiedExpansionV42(action,inviteCode=''){return authedServerFetch('/api/frontier/v42/squad',{method:'POST',body:JSON.stringify({action,inviteCode})});}
export async function adminUnifiedExpansionV42(code,cost){return authedServerFetch('/api/admin/frontier/v42/catalog',{method:'POST',body:JSON.stringify({code,cost})});}

// V42.1 — objetivo semanal cooperativo: dados e resgate autoritativos.
export async function loadSquadObjectiveV421(){return authedServerFetch('/api/frontier/v421/squad-objective');}
export async function claimSquadObjectiveV421(){return authedServerFetch('/api/frontier/v421/squad-objective/claim',{method:'POST',body:'{}'});}
export async function adminSquadObjectiveV421(goal,minimumPersonal,rewardResearch){return authedServerFetch('/api/admin/frontier/v421/squad-objective',{method:'POST',body:JSON.stringify({goal,minimumPersonal,rewardResearch})});}

// V42.3 - equipagem persistente + operacoes cooperativas verificadas.
export async function loadStageAV423(){return authedServerFetch('/api/frontier/v423/loadouts');}
export async function saveLoadoutV423(config,slot,item){return authedServerFetch('/api/frontier/v423/loadouts',{method:'POST',body:JSON.stringify({config,slot,item})});}
export async function loadOpsV423(){return authedServerFetch('/api/frontier/v423/operations');}
export async function claimOpsV423(tier){return authedServerFetch('/api/frontier/v423/operations/claim',{method:'POST',body:JSON.stringify({tier})});}
export async function adminOpsV423(tier,goal,minimum,reward,enabled){return authedServerFetch('/api/admin/frontier/v423/operations',{method:'POST',body:JSON.stringify({tier,goal,minimum,reward,enabled})});}

// V42.4–42.6 | trusted HTTP bridge; never pass balance, damage, kill count or rewards.
export async function loadExplorationV426(){return authedServerFetch('/api/frontier/v426/exploration');}
export async function startSectorV426(sector,requestId){return authedServerFetch('/api/frontier/v426/exploration/start',{method:'POST',body:JSON.stringify({sector,requestId})});}
export async function claimSectorV426(runId){return authedServerFetch('/api/frontier/v426/exploration/claim',{method:'POST',body:JSON.stringify({runId})});}
export async function loadMarketV426(){return authedServerFetch('/api/frontier/v426/market');}
export async function offerMarketV426(item,quantity,unitPrice,requestId){return authedServerFetch('/api/frontier/v426/market/sell',{method:'POST',body:JSON.stringify({item,quantity,unitPrice,requestId})});}
export async function buyMarketV426(offerId){return authedServerFetch('/api/frontier/v426/market/buy',{method:'POST',body:JSON.stringify({offerId})});}
export async function cancelMarketV426(offerId){return authedServerFetch('/api/frontier/v426/market/cancel',{method:'POST',body:JSON.stringify({offerId})});}
export async function loadClanProjectsV426(){return authedServerFetch('/api/frontier/v426/clan');}
export async function fundClanProjectV426(structure,points,requestId){return authedServerFetch('/api/frontier/v426/clan/fund',{method:'POST',body:JSON.stringify({structure,points,requestId})});}
export async function adminSectorV426(code,minutes,kills,cost,reward,enabled){return authedServerFetch('/api/admin/frontier/v426/sector',{method:'POST',body:JSON.stringify({code,minutes,kills,cost,reward,enabled})});}
export async function adminMarketV426(feeBps,enabled){return authedServerFetch('/api/admin/frontier/v426/market',{method:'POST',body:JSON.stringify({feeBps,enabled})});}
export async function adminClanV426(structure,goal,enabled){return authedServerFetch('/api/admin/frontier/v426/clan',{method:'POST',body:JSON.stringify({structure,goal,enabled})});}

// Regulagem da tecnologia Astral, com autorizacao de ADM no banco.
export async function adminAstralPowerV431(enabled){return authedServerFetch('/api/admin/frontier/astral-power',{method:'POST',body:JSON.stringify({enabled})});}

export async function adminAstralModuleV435(code,enabled){return authedServerFetch('/api/admin/frontier/astral-module',{method:'POST',body:JSON.stringify({code,enabled})});}
export async function loadRaidV435(){return authedServerFetch('/api/frontier/raid');}
export async function adminRaidV435(target,minimum,reward,enabled){return authedServerFetch('/api/admin/frontier/raid',{method:'POST',body:JSON.stringify({target,minimum,reward,enabled})});}
export async function claimRaidV435(){return authedServerFetch('/api/frontier/raid/claim',{method:'POST',body:'{}'});}

export async function adminAstralTestKitV440(code,quantity=5){return authedServerFetch('/api/admin/frontier/test-kit',{method:'POST',body:JSON.stringify({code,quantity})});}

export async function loadFrontierAuditV450(){return authedServerFetch('/api/admin/frontier/diagnostics');}

// V111 • Economia AUX: ADM autorizado no Render e leilão liquidado no SQL.
export async function loadAdminAuxEconomyOnline(){return serverFetch('/api/admin/runtime/aux-economy',{},true);}
export async function updateAdminAuxEconomyOnline(payload){return serverFetch('/api/admin/runtime/aux-economy',{method:'POST',body:JSON.stringify(payload)},true);}

export async function claimAuxProtocolAuctionV111({hourKey,lotRef}){return authedSupabaseFetch('/rest/v1/rpc/claim_aux_protocol_auction_v111',{method:'POST',body:JSON.stringify({p_hour_key:String(hourKey),p_lot_ref:String(lotRef)})});}

export const natalStatusOnline=()=>authedServerFetch('/api/natal',{},false);
export const natalClaimOnline=key=>authedServerFetch('/api/natal/claim',{method:'POST',body:JSON.stringify({key})},false);
