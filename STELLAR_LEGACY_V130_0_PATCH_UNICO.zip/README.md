STELLAR LEGACY V130.0 — CUMULATIVA ZIP ÚNICO
Instalar diretamente via Instalador Universal na base V126.0. Vendas exigem a migração V125 já aplicada. O APK deve ser testado.
