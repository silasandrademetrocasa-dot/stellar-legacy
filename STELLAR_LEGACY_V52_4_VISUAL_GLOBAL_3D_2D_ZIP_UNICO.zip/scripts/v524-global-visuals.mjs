/* Stellar Legacy V52.4 — global graphics selector and asset single source of truth.
 * Browser-only graphics changes, no changes to equipment, currencies or saves.
 */
import fs from 'node:fs';
import assert from 'node:assert/strict';
const F='public/game.js', H='public/index.html', R='public/modules/stellar-ship3d-v50.js';
for(const f of [F,H,R])assert(fs.existsSync(f),`V52.4 requer ${f}`);
const marker='STELLAR_V524_GLOBAL_VISUALS';
let src=fs.readFileSync(F,'utf8');
if(src.includes(marker)){console.log('✅ V52.4 já aplicada (idempotente)');process.exit(0)}
assert(src.includes('STELLAR_3D_V50'), 'V52.4: renderizador V50 não integrado; não modificar');
const ids=['phoenix','leonov','liberator','piranha','vengeance','bigboy','goliath','citadel','aegis','spearhead','defcom','yamato','nostromo'];
for(const id of ids)assert(fs.existsSync(`public/assets/v52_4/ships/${id}.png`),`Imagem superior ausente: ${id}`);
const npcs=['streuner','recruitStreuner','aiderStreuner','bossStreuner','lordakia','bossLordakia','saimon','bossSaimon','mordon','bossMordon','devolarium','bossDevolarium','sibelon','bossSibelon'];
for(const id of npcs)assert(fs.existsSync(`public/assets/v52_4/npcs/npc_${id}.png`),`NPC superior ausente: ${id}`);
// Assets are reassigned once after all ESM imports, AFTER the V52/52.3 overlays.
// Preserves all other graphics and references for historical/legacy save compatibility.
const code=`\n/* ${marker} — unified new visuals; never point approved entities to v17 */
for(const id of ${JSON.stringify(ids)}){
  GAME_ASSETS.ships[id]='/assets/v52_4/ships/'+id+'.png';
  GAME_ASSETS.shipMap[id]='/assets/v52_4/ships/'+id+'.png';
}
for(const id of ${JSON.stringify(npcs)})GAME_ASSETS.npcs[id]='/assets/v52_4/npcs/npc_'+id+'.png';
for(const id of ['pet','petElite']){
 GAME_ASSETS.drones[id]='/assets/v52_4/aux9.png';
 GAME_ASSETS.droneMap[id]='/assets/v52_4/aux9.png';
}
/* One shared renderer preference for ships, AUX, NPCs and resources. */
const STELLAR_VISUAL_SETTING_V524='stellar3d.v50';
function stellarVisualModeV524(){try{const mode=localStorage.getItem(STELLAR_VISUAL_SETTING_V524);return mode==='off'?'2d':mode==='on'?'3d':'auto';}catch{return 'auto'}}
function stellarCan3dV524(){const mode=stellarVisualModeV524();return mode==='3d'||(mode==='auto'&&resolvedQualityMode()!=='low')}
function stellarSetVisualModeV524(mode){STELLAR_3D_V50.setMode(mode==='2d'?'off':mode==='3d'?'on':'auto');renderSettings();
 try{preloadActiveGameplayAssets()}catch{};
 if(mode!=='2d'&&progress?.activeShipId)STELLAR_3D_V50.preload(progress.activeShipId);
}
function stellarEnsureVisualSettingsV524(){
 if(!ui.configModal||!ui.qualityButtons)return;
 let section=ui.configModal.querySelector('#stellarVisualSectionV524');
 if(!section){
  section=document.createElement('section');section.id='stellarVisualSectionV524';section.className='settings-section';
  section.innerHTML='<div class="settings-title"><div><b>VISUAL DO JOGO</b><small>Uma escolha para naves, AUX-9, NPCs, minérios e caixas.</small></div></div>'+
   '<div class="quality-grid stellar-visual-grid" role="group" aria-label="Visual 3D ou 2D">'+
   '<button type="button" class="quality-card" data-stellar-visual="auto"><b>AUTOMÁTICO</b><span>3D quando o celular suportar, senão 2D novo.</span></button>'+
   '<button type="button" class="quality-card" data-stellar-visual="3d"><b>3D</b><span>Prioriza os modelos 3D em todos os elementos.</span></button>'+
   '<button type="button" class="quality-card" data-stellar-visual="2d"><b>2D</b><span>Visual superior das novas naves, mais econômico.</span></button></div>'+
   '<small id="stellarVisualStatusV524" class="performance-hint"></small>';
  ui.qualityButtons.closest('.settings-section')?.after(section);
  section.addEventListener('click',e=>{const button=e.target.closest('[data-stellar-visual]');if(button)stellarSetVisualModeV524(button.dataset.stellarVisual)});
 }
 const current=stellarVisualModeV524();
 for(const b of section.querySelectorAll('[data-stellar-visual]')){const on=b.dataset.stellarVisual===current;b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on))}
 const status=section.querySelector('#stellarVisualStatusV524');if(status)status.textContent=!STELLAR_3D_V50.supported?'WebGL indisponível: 2D novo como fallback':current==='2d'?'2D: sprites novos':current==='3d'?'3D preferido • fallback 2D se incompatível':'Automático • qualidade '+resolvedQualityMode().toUpperCase();
}
`;
assert(src.includes('const canvas = document.querySelector'), 'V52.4: posição de inicialização do jogo não encontrada');
src=src.replace('const canvas = document.querySelector',code+'\nconst canvas = document.querySelector');
// Integrate settings without brittle modal HTML structure.
assert(/function renderSettings\(\)\s*\{/.test(src),'V52.4: Configurações ausentes');
src=src.replace(/(function renderSettings\(\)\s*\{\s*if\(!ui\.configModal\)return;)/, '$1\n  stellarEnsureVisualSettingsV524();');
// Remove the old 3D on/off bar from Hangar (V50 installs it there).
const oldBar=/\s*const modeBar=document\.createElement\('div'\);[\s\S]{0,1700}?root\.appendChild\(modeBar\);/;
if(oldBar.test(src)){src=src.replace(oldBar,'\n  /* V52.4: Seletor único movido para Configurações */');console.log('✅ V52.4: barra 3D removida do Hangar')}
else console.log('ℹ️ V52.4: barra antiga do Hangar não encontrada (talvez removida)');
// Ensure V50's local/remote ship paths obey the global setting.
src=src.replaceAll('if(STELLAR_3D_V50.draw(ctx,progress.activeShipId,a,shipSize))','if(stellarCan3dV524()&&STELLAR_3D_V50.draw(ctx,progress.activeShipId,a,shipSize))');
src=src.replaceAll('if(STELLAR_3D_V50.draw(ctx,isShipAllowedV50(rp.shipId)', 'if(stellarCan3dV524()&&STELLAR_3D_V50.draw(ctx,isShipAllowedV50(rp.shipId)');
// Restrict a patch to the named top-level function; old V52 had 3D guarded by graphics quality.
function modifyFunction(name,callback){
 const find=new RegExp('^function\\s+'+name+'\\s*\\(','gm');const ms=[...src.matchAll(find)];
 if(ms.length!==1){console.log(`⚠️ ${name}: função não localizada, fallback 2D mantido`);return false}
 const a=ms[0].index;const rx=/^function\s+[\w$]+\s*\(/gm;rx.lastIndex=a+ms[0][0].length;
 const next=rx.exec(src);const b=next?.index??src.length;const before=src.slice(a,b),after=callback(before);
 if(before===after){console.log(`⚠️ ${name}: layout diferente, 2D mantido`);return false}
 src=src.slice(0,a)+after+src.slice(b);console.log(`✅ ${name}: visual 3D global aplicado`);return true;
}
// Existing V52.3 visuals are adopted and no longer depend on high/low quality when 3D explicitly selected.
const adjustExisting=(segment)=>segment
 .replace(/resolvedQualityMode\(\)\s*!==\s*'low'\s*&&\s*STELLAR_3D_V50\./g,'stellarCan3dV524()&&STELLAR_3D_V50.')
 .replace(/resolvedQualityMode\(\)\s*===\s*'high'\s*&&\s*STELLAR_3D_V50\./g,'stellarCan3dV524()&&STELLAR_3D_V50.');
function addForImageBranch(fn,call){
 modifyFunction(fn,seg=>{
  let v=adjustExisting(seg);
  if(v.includes('STELLAR_3D_V50.drawAsset'))return v;
  const branch=/if\s*\(\s*img\s*&&\s*img\.naturalWidth\s*\)\s*\{/;
  if(!branch.test(v))return v;
  return v.replace(branch,`if(stellarCan3dV524()&&${call}){ /* V52.4: asset 3D */ } else if(img&&img.naturalWidth){`);
 });
}
// drawAssetAt keeps the function's own canvas translation, while drawAsset uses translated context.
addForImageBranch('drawPet',"STELLAR_3D_V50.drawAssetAt(ctx,'aux9',petRuntime.angle||0,48,p.x,p.y)");
addForImageBranch('drawRemotePet',"STELLAR_3D_V50.drawAssetAt(ctx,'aux9',q.angle||0,42,p.x,p.y)");
addForImageBranch('drawEnemy',"STELLAR_3D_V50.drawAsset(ctx,'npc_'+e.type,Math.atan2(player.y-e.y,player.x-e.x),e.size*(boss?3.45:3.08))");
// Assets with own loop: preserve the original drawing logic until GLB is ready.
for(const fn of ['drawOres','drawBonusBoxes','drawLoot'])modifyFunction(fn,adjustExisting);
// Avoid rendering oversized legacy cards in old async cached image references by fully replacing the asset map above.
fs.writeFileSync(F,`/* ${marker} */\n`+src);
// Enable preference 'on' distinct from 'auto' in existing WebGL renderer. The module preserves legacy API.
let render=fs.readFileSync(R,'utf8');
render=render.replace("const mode=localStorage.getItem('stellar3d.v50')||'auto'", "const mode=localStorage.getItem('stellar3d.v50')||'auto'");
const modeRx="localStorage.getItem('stellar3d.v50')||'auto'";
assert(render.includes(modeRx), 'V52.4: não reconheceu modo do motor 3D');
render=render.replace("localStorage.setItem('stellar3d.v50',mode==='off'?'off':'auto')", "localStorage.setItem('stellar3d.v50',['off','on','auto'].includes(mode)?mode:'auto')");
// Fix yaw direction consistently; forward +Z rotated toward the positive X screen direction for gameplay angle 0.
// Keep existing calibrated engine yaw when source already contains it.
fs.writeFileSync(R, render);
console.log('✅ V52.4: fonte visual única, 2D top-down novo, configurações globais e 3D / fallback');
