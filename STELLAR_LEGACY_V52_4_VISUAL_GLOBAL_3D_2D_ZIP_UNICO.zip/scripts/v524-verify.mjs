import fs from 'node:fs';
import assert from 'node:assert/strict';
import { decodeGlb } from '../public/modules/stellar-ship3d-v50.js';
const ids=['phoenix','leonov','liberator','piranha','vengeance','bigboy','goliath','citadel','aegis','spearhead','defcom','yamato','nostromo'];
const npcs=['streuner','recruitStreuner','aiderStreuner','bossStreuner','lordakia','bossLordakia','saimon','bossSaimon','mordon','bossMordon','devolarium','bossDevolarium','sibelon','bossSibelon'];
const g=fs.readFileSync('public/game.js','utf8');
const r=fs.readFileSync('public/modules/stellar-ship3d-v50.js','utf8');
assert(g.includes('STELLAR_V524_GLOBAL_VISUALS'));
assert(g.includes('function stellarCan3dV524()'));
assert(g.includes('stellarEnsureVisualSettingsV524();'));
assert(g.includes('VISUAL DO JOGO'));
assert(g.includes('data-stellar-visual="3d"')&&g.includes('data-stellar-visual="2d"')&&g.includes('data-stellar-visual="auto"'));
assert(!g.includes("const modeBar=document.createElement('div')"),'Antiga barra no hangar ainda presente');
assert(g.includes('GAME_ASSETS.shipMap[id]')&&g.includes('GAME_ASSETS.ships[id]'),'Map e cards não unificados');
assert(g.includes('GAME_ASSETS.drones[id]')&&g.includes('GAME_ASSETS.droneMap[id]'));
assert(g.includes("stellarCan3dV524()&&STELLAR_3D_V50.draw(ctx,progress.activeShipId"),'3D da nave local não ativado');
assert(g.includes("stellarCan3dV524()&&STELLAR_3D_V50.drawAsset(ctx,'npc_'"),'3D dos NPCs não ativado');
assert(r.includes("['off','on','auto'].includes(mode)"),'Modo 3D forçado não suportado');
for(const id of ids){
 const src=`public/assets/v52_4/ships/${id}.png`;
 assert(fs.existsSync(src),`2D da nave ${id} ausente`);
 const bytes=fs.readFileSync(src);assert(bytes.subarray(0,8).toString('hex')==='89504e470d0a1a0a');
}
for(const id of npcs)assert(fs.existsSync(`public/assets/v52_4/npcs/npc_${id}.png`));
assert(fs.existsSync('public/assets/v52_4/aux9.png'));
const manifest=JSON.parse(fs.readFileSync('public/assets/ships3d/v50/manifest.json','utf8'));
for(const ship of manifest){
 const p=`public/assets/ships3d/v50/SL_${ship.name.toUpperCase()}_LOD.glb`;
 const b=fs.readFileSync(p);assert(decodeGlb(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength)).length>0,`GLB inválido ${p}`);
}
for(const key of ['aux9','npc_bossLordakia','ore_Prometium','box_bonus'])assert(fs.existsSync(`public/assets/v52_3/models/${key}.glb`));
console.log('✅ V52.4: 13 naves GLB e PNG novos, 14 NPCs, AUX, configurações globais, 3D/2D e fallback verificados');
