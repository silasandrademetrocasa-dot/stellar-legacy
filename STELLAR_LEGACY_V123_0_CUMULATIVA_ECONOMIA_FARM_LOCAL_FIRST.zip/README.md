# STELLAR LEGACY V123.0 — ECONOMIA + FARM, UM DEPLOY

**Base:** V122.0 / 47.7.61. **Destino:** V123.0 / 47.7.62.

Instale SOMENTE este ZIP via Instalador Universal no repositório que já recebeu V122.0.
O pacote é cumulativo (V121/V122/V123); inclui o SQL em `sql/STELLAR_V123_0_ECONOMIA_COMPRA_IDEMPOTENTE.sql` para reprodutibilidade.
O SQL V123 já foi aplicado no Supabase stellar-legacy. Não é preciso executá-lo novamente nesse ambiente.

Migração ativa em compras comuns **com request_id**: operações idempotentes por conta, recibo durável, lock SQL, save com compare-and-swap. Compras antigas sem request_id continuam via V118 para compatibilidade. Redução do save forçado em cada clique no catálogo. Recuperação do Farm após timeout via status oficial.

NÃO MIGRA AINDA: venda, leilão, compras em lote, recompensas, PvP, clãs, Warfront para o gateway novo. Farm continua pago exclusivamente por RPC antiga. Mantém modo observe e permissões do Supabase; não apagar dados.

Auditoria: `npm run check`, `node --test --test-concurrency=4 tests/*.test.mjs`.
Teste mobile após deploy: compra 1 item barato, fechar/abrir, sem duplicidade; Farm curto; compras repetidas e saldo. Não declarar homologação de Android sem esses testes.

Leia docs/V123_0_CUMULATIVA_ECONOMIA_FARM.md.
