export const FACTIONS = {
  earth: { id: 'earth', name: 'Terra Alliance', short: 'TERRA', prefix: '1', color: '#4fd7ff', description: 'Tecnologia, comércio e defesa orbital.' },
  mars: { id: 'mars', name: 'Mars Dominion', short: 'MARTE', prefix: '2', color: '#ff6a59', description: 'Força militar, indústria e expansão agressiva.' },
  jupiter: { id: 'jupiter', name: 'Jupiter Federation', short: 'JÚPITER', prefix: '3', color: '#bd78ff', description: 'Pesquisa, mineração e domínio das rotas externas.' },
};

export const SHIPS = {
  // Naves sem habilidade especial: disponíveis normalmente na Loja.
  phoenix: { id:'phoenix', name:'Aurora', lasers:1, generators:1, speed:320, cargo:100, hp:104000, extras:1, price:0, currency:'credits', role:'Nave inicial', shopAvailable:false },
  liberator: { id:'liberator', name:'Pioneer', lasers:4, generators:6, speed:300, cargo:400, hp:116000, extras:2, price:10000000, currency:'credits', role:'Progressão inicial' },
  piranha: { id:'piranha', name:'Raptor', lasers:6, generators:8, speed:360, cargo:600, hp:164000, extras:2, price:30000000, currency:'credits', role:'Ataque rápido' },
  nostromo: { id:'nostromo', name:'Meridian', lasers:7, generators:10, speed:340, cargo:700, hp:220000, extras:3, price:80000000, currency:'credits', role:'Farm e progressão' },
  bigboy: { id:'bigboy', name:'Bastion', lasers:8, generators:15, speed:260, cargo:800, hp:360000, extras:3, price:150000000, currency:'credits', role:'Tanque comum' },
  nDiplomat: { id:'nDiplomat', name:'Concord', lasers:7, generators:10, speed:340, cargo:900, hp:240000, extras:3, price:160000000, currency:'credits', role:'Nave de progressão avançada' },
  nEnvoy: { id:'nEnvoy', name:'Vanguard', lasers:10, generators:10, speed:340, cargo:1000, hp:160000, extras:3, price:240000000, currency:'credits', role:'Caçadora comum avançada' },
  nAmbassador: { id:'nAmbassador', name:'Sovereign', lasers:12, generators:12, speed:340, cargo:1500, hp:320000, extras:3, price:400000000, currency:'credits', role:'Nave comum topo de créditos' },

  // Elite de Loja.
  leonov: { id:'leonov', name:'Lynx', lasers:6, generators:6, speed:360, cargo:500, hp:164000, extras:1, price:900000, currency:'uridium', role:'Elite de mapas baixos', bonusLowMaps:{hp:96000,speed:20,cargo:500,laserMult:1.5,rocketMult:2,shieldMult:2} },
  vengeance: { id:'vengeance', name:'Valkyrie', lasers:10, generators:10, speed:380, cargo:1000, hp:280000, extras:2, price:1400000, currency:'uridium', role:'Elite veloz' },
  goliath: { id:'goliath', name:'Leviathan', lasers:15, generators:15, speed:300, cargo:1500, hp:356000, extras:3, price:2500000, currency:'uridium', role:'Elite de combate pesado' },
  pusat: { id:'pusat', name:'Striker', lasers:16, generators:12, speed:370, cargo:500, hp:225000, extras:3, price:3500000, currency:'uridium', role:'Elite ofensiva de alta velocidade' },

  // Naves com habilidades especiais: catálogo futuro de Evento / Missão / Passe.
  aegis: { id:'aegis', name:'Seraph', lasers:11, generators:18, speed:315, cargo:2250, hp:455000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • suporte', ability:'Hull Mend • Barrier Mend • Repair Beacon' },
  basilisk: { id:'basilisk', name:'Venatrix', lasers:15, generators:17, speed:330, cargo:1650, hp:450000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • controle tóxico', ability:'Toxic Veil • Overdrive Valor' },
  berserker: { id:'berserker', name:'Ravager', lasers:8, generators:18, speed:300, cargo:1650, hp:620000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • contra-ataque', ability:'Barrier Link • Fury Core • Retaliation' },
  centurion: { id:'centurion', name:'Praetor', lasers:16, generators:17, speed:335, cargo:1600, hp:455000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • projetos instáveis', ability:'Projetos especiais com bônus e habilidades' },
  citadel: { id:'citadel', name:'Bulwark', lasers:8, generators:21, speed:250, cargo:4500, hp:750000, extras:5, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • tanque pesado', ability:'Taunt Beacon • Warp Surge • Guardian Field • Bastion Mode' },
  cyborg: { id:'cyborg', name:'Nexus Prime', lasers:16, generators:17, speed:325, cargo:1600, hp:455000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • dano contínuo', ability:'Rift Collapse' },
  defcom: { id:'defcom', name:'Phantom', lasers:12, generators:11, speed:380, cargo:900, hp:290000, extras:3, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • camuflagem', ability:'Phase Cloak' },
  defcomRaven: { id:'defcomRaven', name:'Wraith', lasers:12, generators:12, speed:385, cargo:1000, hp:365000, extras:3, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • camuflagem reforçada', ability:'Phase Cloak' },
  diminisher: { id:'diminisher', name:'Nullifier', lasers:15, generators:17, speed:325, cargo:1700, hp:460000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • anti-escudo', ability:'Barrier Break' },
  disruptor: { id:'disruptor', name:'Interdictor', lasers:14, generators:16, speed:345, cargo:1650, hp:450000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • interferência', ability:'Vector Redirect • Barrier Scramble • Signal Blackout' },
  goliathX: { id:'goliathX', name:'Leviathan-X', lasers:15, generators:18, speed:305, cargo:1900, hp:540000, extras:5, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • congelamento', ability:'Cryo Talon' },
  hammerclaw: { id:'hammerclaw', name:'Ironclaw', lasers:13, generators:18, speed:305, cargo:1900, hp:465000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • suporte pesado', ability:'Hull Mend • Barrier Mend • Repair Beacon' },
  hecate: { id:'hecate', name:'Lumina', lasers:15, generators:17, speed:320, cargo:1600, hp:475000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • feixe de partículas', ability:'Photon Lance' },
  holo: { id:'holo', name:'Mirage', lasers:15, generators:16, speed:330, cargo:1650, hp:445000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • reversão', ability:'Self Rewind • Target Rewind' },
  hyperion: { id:'hyperion', name:'Gravastar', lasers:15, generators:18, speed:320, cargo:1750, hp:480000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • controle gravitacional', ability:'Gravity Lock' },
  keres: { id:'keres', name:'Plaguewing', lasers:15, generators:17, speed:330, cargo:1650, hp:445000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • contágio', ability:'Contagion Spread • Phase Feint' },
  mimesis: { id:'mimesis', name:'Echo', lasers:13, generators:15, speed:350, cargo:1650, hp:430000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • evasão', ability:'Echo Scramble • Phase Shift' },
  orcus: { id:'orcus', name:'Doppel', lasers:15, generators:16, speed:320, cargo:1750, hp:440000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • duplicação', ability:'Echo Clone • Energy Assimilation' },
  paladin: { id:'paladin', name:'Warden', lasers:13, generators:20, speed:315, cargo:1750, hp:500000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • sobrevivência', ability:'Void Ripper • Final Stand' },
  retiarus: { id:'retiarus', name:'Lancer', lasers:15, generators:16, speed:340, cargo:1600, hp:465000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • tiro carregado', ability:'Overcharge • Charged Lance' },
  sentinel: { id:'sentinel', name:'Guardian', lasers:15, generators:18, speed:305, cargo:1800, hp:535000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • defesa', ability:'Fortress Matrix' },
  solace: { id:'solace', name:'Reclaimer', lasers:15, generators:17, speed:320, cargo:1800, hp:465000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • reparação', ability:'Nanite Swarm' },
  solaris: { id:'solaris', name:'Helios', lasers:15, generators:17, speed:330, cargo:1650, hp:460000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • incêndio', ability:'Solar Burn' },
  spearhead: { id:'spearhead', name:'Pathfinder', lasers:7, generators:12, speed:410, cargo:650, hp:280000, extras:3, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • reconhecimento', ability:'Phase Cloak • Signal Jam • Hunter Mark • Deep Scan' },
  spectrum: { id:'spectrum', name:'Prism', lasers:15, generators:18, speed:310, cargo:1750, hp:510000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • defesa prismática', ability:'Prism Barrier' },
  tartarus: { id:'tartarus', name:'Hellrunner', lasers:14, generators:16, speed:345, cargo:1700, hp:460000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • velocidade / foguetes', ability:'Barrage Mode • Vector Boost' },
  tempest: { id:'tempest', name:'Stormrider', lasers:14, generators:16, speed:360, cargo:1700, hp:450000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • eletricidade', ability:'Arc Link • Arc Discharge • Arc Reserve' },
  venom: { id:'venom', name:'Viper', lasers:15, generators:17, speed:335, cargo:1700, hp:450000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • dano contínuo', ability:'Rift Collapse' },
  yamato: { id:'yamato', name:'Kensei', lasers:10, generators:13, speed:365, cargo:1100, hp:340000, extras:3, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • aceleração', ability:'Warp Surge' },
  yRonin: { id:'yRonin', name:'Shogun', lasers:11, generators:14, speed:375, cargo:1200, hp:390000, extras:3, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • aceleração', ability:'Warp Surge' },
  zephyr: { id:'zephyr', name:'Gale', lasers:13, generators:16, speed:370, cargo:1650, hp:380000, extras:4, price:0, currency:'uridium', eventOnly:true, role:'EVENTO • momentum', ability:'Kinetic Drive • Tri-Barrage' },
};

export const ITEMS = {
  // LASERS
  lf1: { id:'lf1', type:'laser', name:'ARC-1', damage:65, rarity:'common', price:1000000, currency:'credits', description:'Laser common • dano 65.' },
  mp1: { id:'mp1', type:'laser', name:'ARC-2', damage:90, rarity:'common', price:8000000, currency:'credits', description:'Laser common • dano 90.' },
  sl01: { id:'sl01', type:'laser', name:'ARC-3', damage:125, rarity:'rare', price:32000000, currency:'credits', description:'Laser rare • dano 125.' },
  lf2: { id:'lf2', type:'laser', name:'ARC-4', damage:155, rarity:'rare', price:90000, currency:'uridium', description:'Laser rare • dano 155.' },
  lf3: { id:'lf3', type:'laser', name:'ARC-5', damage:190, alienBonus:0.08, rarity:'epic', price:220000, currency:'uridium', description:'Laser epic • dano 190 • +8% contra aliens.' },
  lf4: { id:'lf4', type:'laser', name:'ARC-6', damage:220, rarity:'epic', price:500000, currency:'uridium', description:'Laser epic • dano 220.' },

  lfx: { id:'lfx', type:'laser', name:'ARC-X', damage:250, alienBonus:0.04, rarity:'legendary', price:0, currency:'uridium', eventOnly:true, description:'Laser legendary • dano 250 • +4% contra aliens • Exclusivo de eventos.' },
  lfomega: { id:'lfomega', type:'laser', name:'ARC-Ω', damage:275, alienBonus:0.06, rarity:'legendary', price:0, currency:'uridium', eventOnly:true, description:'Laser legendary • dano 275 • +6% contra aliens • Exclusivo de eventos.' },

  // SPEED GENERATORS
  g3n1010: { id:'g3n1010', type:'generator', subtype:'speed', name:'THR-1', speed:2, rarity:'common', price:250000, currency:'credits', description:'Motor common • +2 velocidade.' },
  g3n2010: { id:'g3n2010', type:'generator', subtype:'speed', name:'THR-2', speed:3, rarity:'common', price:1000000, currency:'credits', description:'Motor common • +3 velocidade.' },
  g3n3210: { id:'g3n3210', type:'generator', subtype:'speed', name:'THR-3', speed:4, rarity:'rare', price:8000000, currency:'credits', description:'Motor rare • +4 velocidade.' },
  g3n3310: { id:'g3n3310', type:'generator', subtype:'speed', name:'THR-4', speed:5, rarity:'rare', price:25000, currency:'uridium', description:'Motor rare • +5 velocidade.' },
  g3n6900: { id:'g3n6900', type:'generator', subtype:'speed', name:'THR-5', speed:7, rarity:'epic', price:100000, currency:'uridium', description:'Motor epic • +7 velocidade.' },
  g3n7900: { id:'g3n7900', type:'generator', subtype:'speed', name:'THR-6', speed:10, rarity:'epic', price:260000, currency:'uridium', description:'Motor epic • +10 velocidade.' },

  g3n8700: { id:'g3n8700', type:'generator', subtype:'speed', name:'THR-7', speed:14, rarity:'legendary', price:0, currency:'uridium', eventOnly:true, description:'Motor legendary • +14 velocidade • Exclusivo de eventos.' },

  // SHIELD GENERATORS
  fs01: { id:'fs01', type:'generator', subtype:'shield', name:'AEG-1', shield:3200, absorption:70, shieldRegenBonus:0.0625, rarity:'common', price:18000000, currency:'credits', description:'3.200 escudo • 70% absorção • +6,25% regeneração.' },
  fs02: { id:'fs02', type:'generator', subtype:'shield', name:'AEG-2', shield:5600, absorption:75, shieldRegenBonus:0.0625, rarity:'rare', price:70000000, currency:'credits', description:'5.600 escudo • 75% absorção • +6,25% regeneração.' },
  fs03: { id:'fs03', type:'generator', subtype:'shield', name:'AEG-3', shield:12500, absorption:82, shieldRegenBonus:0.0625, rarity:'rare', price:260000, currency:'uridium', description:'12.500 escudo • 82% absorção • +6,25% regeneração.' },
  fs04: { id:'fs04', type:'generator', subtype:'shield', name:'AEG-4', shield:17200, absorption:84, shieldRegenBonus:0.0625, rarity:'epic', price:500000, currency:'uridium', description:'17.200 escudo • 84% absorção • +6,25% regeneração.' },
  fs05: { id:'fs05', type:'generator', subtype:'shield', name:'AEG-5', shield:23000, absorption:86, shieldRegenBonus:0.0625, rarity:'legendary', price:0, currency:'uridium', eventOnly:true, description:'23.000 escudo • 86% absorção • +6,25% regeneração • Exclusivo de eventos.' },
  sg3nb00: { id:'sg3nb00', type:'generator', subtype:'shield', name:'VSH-0', shield:13500, absorption:78, price:0, currency:'uridium', eventOnly:true, description:'13.500 escudo • 78% absorção • EVENTO.' },
  sg3na01: { id:'sg3na01', type:'generator', subtype:'shield', name:'VSH-1', shield:1000, absorption:40, rarity:'common', price:1000000, currency:'credits', description:'1.000 escudo • 40% absorção.' },
  sg3na02: { id:'sg3na02', type:'generator', subtype:'shield', name:'VSH-2', shield:5000, absorption:50, rarity:'rare', price:12000000, currency:'credits', description:'5.000 escudo • 50% absorção.' },
  sg3na03: { id:'sg3na03', type:'generator', subtype:'shield', name:'VSH-3', shield:6500, absorption:60, rarity:'rare', price:70000, currency:'uridium', description:'6.500 escudo • 60% absorção.' },
  sg3nb01: { id:'sg3nb01', type:'generator', subtype:'shield', name:'VSH-4', shield:15000, absorption:78, rarity:'epic', price:220000, currency:'uridium', description:'15.000 escudo • 78% absorção.' },
  sg3nb02: { id:'sg3nb02', type:'generator', subtype:'shield', name:'VSH-5', shield:20000, absorption:85, rarity:'legendary', price:0, currency:'uridium', eventOnly:true, description:'20.000 escudo • 85% absorção • Exclusivo de eventos.' },
  sg3nb03: { id:'sg3nb03', type:'generator', subtype:'shield', name:'VSH-6', shield:26000, absorption:88, rarity:'legendary', price:0, currency:'uridium', eventOnly:true, description:'26.000 escudo • 88% absorção • Exclusivo de eventos.' },

  // EXTRAS
  autoLaserCpu: { id: 'autoLaserCpu', type: 'extra', name: 'Mira Autônoma', price: 10000000, currency: 'credits', description: 'Ao selecionar um alvo, inicia o laser automaticamente.' },
  autoRocketCpu: { id: 'autoRocketCpu', type: 'extra', name: 'Lançador Autônomo', price: 12000000, currency: 'credits', description: 'Dispara automaticamente o míssil selecionado durante o combate.' },
  rocketTurboCpu: { id: 'rocketTurboCpu', type: 'extra', name: 'Propulsor de Recarga', price: 25000000, currency: 'credits', description: 'Reduz o cooldown de mísseis pela metade.' },

  // EXPANSÃO DE SLOTS EXTRAS
  extraSlotCpuCommon: {
    id: 'extraSlotCpuCommon', type: 'extra', name: 'CPU Expansora de Extras • Comum',
    price: 50000000, currency: 'credits', slotBonus: 3, exclusiveGroup: 'extraSlotExpansion',
    description: 'Enquanto equipada, libera +4 slots EXTRAS adicionais na nave ativa. Não acumula com a versão Elite.'
  },
  extraSlotCpuElite: {
    id: 'extraSlotCpuElite', type: 'extra', name: 'CPU Expansora de Extras • Elite',
    price: 250000, currency: 'uridium', slotBonus: 6, exclusiveGroup: 'extraSlotExpansion',
    description: 'Enquanto equipada, libera +9 slots EXTRAS adicionais na nave ativa. Não acumula com a versão Comum.'
  },

  // ROBÔS DE REPARAÇÃO AUTOMÁTICA
  rep2: {
    id: 'rep2', type: 'extra', name: 'Nanobot de Reparo • Comum',
    price: 20000000, currency: 'credits', repairRate: 0.01, repairTick: 5000, shieldRepairTick: 10000, repairDelay: 5, exclusiveGroup: 'repairBot',
    description: 'Após 5s sem receber dano, repara +5.000 HP por segundo. O escudo regenera +10.000 por segundo.'
  },
  repElite: {
    id: 'repElite', type: 'extra', name: 'Nanobot de Reparo • Elite',
    price: 180000, currency: 'uridium', repairRate: 0.02, repairTick: 10000, shieldRepairTick: 15000, repairDelay: 5, exclusiveGroup: 'repairBot',
    description: 'Após 5s sem receber dano, repara +10.000 HP por segundo. Enquanto equipado, o escudo regenera +15.000 por segundo.'
  },

  repPrime: { id:'repPrime', type:'extra', name:'Nanobot Prime', price:0, currency:'uridium', eventOnly:true, exclusiveGroup:'repairBot', repairRate:0.024, repairTick:12000, shieldRepairTick:18000, repairDelay:5, description:'Reparador raro de evento • 12.000 HP/s e 18.000 escudo/s após 5s fora de combate.' },

  // EXPANSÃO DE PORÃO
  cargoCpuCommon: {
    id: 'cargoCpuCommon', type: 'extra', name: 'Módulo de Porão • Comum',
    price: 75000000, currency: 'credits', cargoBonus: 2500, exclusiveGroup: 'cargoExpansion',
    description: 'Enquanto equipado, aumenta a capacidade do porão da nave ativa em +3.000 unidades. Não acumula com a versão Elite.'
  },
  cargoCpuElite: {
    id: 'cargoCpuElite', type: 'extra', name: 'Módulo de Porão • Elite',
    price: 500000, currency: 'uridium', cargoBonus: 10000, exclusiveGroup: 'cargoExpansion',
    description: 'Enquanto equipado, aumenta a capacidade do porão da nave ativa em +10.000 unidades. Não acumula com a versão Comum.'
  },

  ammoAutoBuyCpu: { id: 'ammoAutoBuyCpu', type: 'extra', name: 'Repositor Automático', price: 30000000, currency: 'credits', description: 'Compra automaticamente novo pacote da munição laser e do míssil selecionados quando o estoque estiver baixo.' },
  remoteTraderCpuElite: { id:'remoteTraderCpuElite',type:'extra',name:'Terminal Mercante Remoto • Elite',price:350000,currency:'uridium',description:'EXTRA Elite: enquanto equipado, permite vender recursos diretamente na aba Refinaria do Hangar em qualquer setor, sem retorno à base. Venda manual, nunca automática.' },

  // DRONES
  flax: { id:'flax', type:'drone', name:'Halo', slots:1, price:10000000, currency:'credits', description:'Drone comum com 1 slot de equipamento.' },
  iris: { id:'iris', type:'drone', name:'Nova', slots:2, price:15000, currency:'uridium', description:'Drone Elite com 2 slots de equipamento.' },
};

export const LASER_AMMO = {
  lcb10: { id:'lcb10', name:'PLS-1', mult:1, color:'#76d9ff', pack:10000, price:500000, currency:'credits' },
  mcb25: { id:'mcb25', name:'PLS-2', mult:2, color:'#ffe36d', pack:5000, price:1500000, currency:'credits' },
  mcb50: { id:'mcb50', name:'PLS-3', mult:3, color:'#ff9d62', pack:5000, price:20000, currency:'uridium' },
  ucb100: { id:'ucb100', name:'PLS-4', mult:4, color:'#ff5d8b', pack:5000, price:100000, currency:'uridium' },
  sab50: { id:'sab50', name:'SIP-2', mult:2, shieldDrain:true, color:'#79f1ff', pack:5000, price:45000, currency:'uridium', description:'Captura energia de escudo x2 e transfere o valor drenado para seu próprio escudo.' },
}

export const ROCKETS = {
  r310: { id: 'r310', name: 'CMT-1', damage: 1000, color: '#79d1ff', pack: 100, price: 500000, currency: 'credits' },
  plt2026: { id: 'plt2026', name: 'CMT-2', damage: 2000, color: '#98ff6c', pack: 100, price: 2000000, currency: 'credits' },
  plt2021: { id: 'plt2021', name: 'CMT-3', damage: 4000, color: '#ffd15b', pack: 100, price: 10000, currency: 'uridium' },
  plt3030: { id: 'plt3030', name: 'CMT-4', damage: 6000, color: '#ff7676', pack: 100, price: 30000, currency: 'uridium' },
};


export const RESOURCES = {
  // Mineração precisa competir com caça e missões.
  // Valores unitários de venda na base X-1.
  Prometium: { id: 'Prometium', name: 'Ferron', color: '#ff9f43', sell: 1000 },
  Endurium: { id: 'Endurium', name: 'Cryon', color: '#59d3ff', sell: 1500 },
  Terbium: { id: 'Terbium', name: 'Virel', color: '#d76bff', sell: 2500 },
  Prometid: { id: 'Prometid', name: 'Ferrite', color: '#ff6b6b', sell: 10000 },
  Duranium: { id: 'Duranium', name: 'Duracite', color: '#65f0bf', sell: 15000 },
  Promerium: { id: 'Promerium', name: 'Solarium', color: '#ffe66d', sell: 35000 },
  // Voidite usa o ID legado de recurso especial e não é vendido por Créditos.
  Xenomit: { id: 'Xenomit', name: 'Voidite', color: '#ffffff', sell: 0 },
};

// ECONOMIA REBALANCEADA: Créditos preservados, Stellarium reforçado e XP reduzido para progressão mais longa.
// BOSS principais continuam com aproximadamente 2x a recompensa do alien normal correspondente.

export const NPC_TYPES = {
  streuner: { name: 'Scavenger', hp:900, shield:500, credits:6200, uridium:13, xp:200, speed:68, damage:95, color: '#ff8b75', size: 14, resources: { Prometium: 12, Endurium: 12 } },
  recruitStreuner: { name: 'Scavenger Scout', hp:1100, shield:700, credits:8800, uridium:17, xp:260, speed:90, damage:130, color: '#ff9b6f', size: 15, resources: { Prometium: 14, Endurium: 14 } },
  aiderStreuner: { name: 'Scavenger Support', hp:1500, shield:1000, credits:12400, uridium:26, xp:370, speed:72, damage:210, color: '#ffbb62', size: 16, resources: { Prometium: 15, Terbium: 15 } },
  bossStreuner: { name: 'Scavenger Prime', hp:1600, shield:800, credits:15400, uridium:32, xp:440, speed:62, damage:120, color: '#ff5e6e', size: 19, resources: { Prometium: 20, Terbium: 20 } },

  lordakia: { name: 'Vrax', hp:2000, shield:2000, credits:18500, uridium:32, xp:530, speed:95, damage:240, color: '#9f73ff', size: 18, resources: { Prometium: 20, Terbium: 20, Endurium: 20 } },
  bossLordakia: { name: 'Vrax Prime', hp:4000, shield:4000, credits:37100, uridium:63, xp:1060, speed:95, damage:480, color: '#c765ff', size: 22, resources: { Prometium: 40, Terbium: 40, Endurium: 40, Xenomit: 1 } },

  saimon: { name: 'Zyron', hp:6000, shield:6000, credits:36000, uridium:47, xp:1060, speed:82, damage:600, color: '#55e2ff', size: 20, resources: { Prometium: 40, Terbium: 40, Endurium: 40, Prometid: 2, Duranium: 2 } },
  bossSaimon: { name: 'Zyron Prime', hp:12000, shield:12000, credits:72100, uridium:94, xp:2110, speed:82, damage:1200, color: '#24b0ff', size: 25, resources: { Prometium: 80, Terbium: 80, Endurium: 80, Prometid: 4, Duranium: 4, Xenomit: 2 } },

  mordon: { name: 'Kharon', hp:20000, shield:10000, credits:92700, uridium:105, xp:2640, speed:52, damage:1170, color: '#ffa34d', size: 25, resources: { Prometium: 80, Terbium: 80, Endurium: 80, Prometid: 8, Duranium: 8, Promerium: 1 } },
  bossMordon: { name: 'Kharon Prime', hp:40000, shield:20000, credits:185400, uridium:210, xp:5280, speed:52, damage:2340, color: '#ff6948', size: 31, resources: { Prometium: 160, Terbium: 160, Endurium: 160, Prometid: 16, Duranium: 16, Promerium: 2, Xenomit: 4 } },

  devolarium: { name: 'Dreadnox', hp:108000, shield:108000, credits:330000, uridium:280, xp:8780, speed:38, damage:3780, color: '#7edcff', size: 32, resources: { Prometium: 100, Terbium: 100, Endurium: 100, Prometid: 16, Duranium: 16, Promerium: 2 } },
  bossDevolarium: { name: 'Dreadnox Prime', hp:216000, shield:216000, credits:660000, uridium:560, xp:17570, speed:38, damage:7560, color: '#c8f0ff', size: 40, resources: { Prometium: 200, Terbium: 200, Endurium: 200, Prometid: 32, Duranium: 32, Promerium: 4, Xenomit: 8 } },

  sibelon: { name: 'Colossar', hp:216000, shield:216000, credits:715000, uridium:448, xp:14640, speed:30, damage:8350, color: '#66ffcb', size: 36, resources: { Prometium: 200, Terbium: 200, Endurium: 200, Prometid: 32, Duranium: 32, Promerium: 4 } },
  bossSibelon: { name: 'Colossar Prime', hp:432000, shield:432000, credits:1430000, uridium:896, xp:29280, speed:30, damage:16695, color: '#19d59d', size: 45, resources: { Prometium: 400, Terbium: 400, Endurium: 400, Prometid: 64, Duranium: 64, Promerium: 8, Xenomit: 16 } },

  emberFang: { name:'Ember Fang', hp:266800, shield:172500, credits:731600, uridium:487, xp:19580, speed:88, damage:4535, color:'#ff6d5d', size:32, resources:{"Prometid":20,"Duranium":20,"Promerium":3} },
  bossEmberFang: { name:'Ember Fang Prime', hp:533600, shield:345000, credits:1475000, uridium:986, xp:40500, speed:78, damage:8425, color:'#ff8c75', size:42, resources:{"Prometid":31,"Duranium":31,"Promerium":7,"Xenomit":2} },
  ironWasp: { name:'Iron Wasp', hp:324800, shield:253000, credits:896800, uridium:580, xp:23620, speed:96, damage:5510, color:'#ff8970', size:34, resources:{"Prometid":22,"Duranium":22,"Promerium":3} },
  bossIronWasp: { name:'Iron Wasp Prime', hp:649600, shield:494500, credits:1829000, uridium:1137, xp:48600, speed:84, damage:10045, color:'#ff9a84', size:44, resources:{"Prometid":36,"Duranium":36,"Promerium":7,"Xenomit":2} },
  riftMauler: { name:'Rift Mauler', hp:417600, shield:368000, credits:1156400, uridium:754, xp:31050, speed:82, damage:6910, color:'#ff7854', size:38, resources:{"Prometid":25,"Duranium":25,"Promerium":4,"Xenomit":1} },
  bossRiftMauler: { name:'Rift Mauler Prime', hp:835200, shield:713000, credits:2360000, uridium:1508, xp:63450, speed:72, damage:12745, color:'#ff8a61', size:50, resources:{"Prometid":40,"Duranium":40,"Promerium":9,"Xenomit":3} },
  obsidianPike: { name:'Obsidian Pike', hp:580000, shield:483000, credits:1593000, uridium:986, xp:41850, speed:90, damage:8965, color:'#ff6a44', size:40, resources:{"Prometid":27,"Duranium":29,"Promerium":6,"Xenomit":2} },
  bossObsidianPike: { name:'Obsidian Pike Prime', hp:1136800, shield:989000, credits:3304000, uridium:1972, xp:87750, speed:78, damage:16415, color:'#ff7e57', size:54, resources:{"Prometid":45,"Duranium":47,"Promerium":11,"Xenomit":4} },
  apexOverlord: { name:'Apex Overlord', hp:6000000, shield:4200000, credits:14000000, uridium:8800, xp:425000, speed:64, damage:32000, color:'#ff5038', size:64, resources:{"Prometid":110,"Duranium":110,"Promerium":36,"Xenomit":45} },
  sentinelScavenger: { name:'Sentinel Scavenger', hp:780000, shield:590000, credits:1952000, uridium:1140, xp:52200, speed:92, damage:10465, color:'#ff705a', size:42, resources:{"Prometid":34,"Duranium":34,"Promerium":7,"Xenomit":2} },
  sentinelScout: { name:'Sentinel Scout', hp:912000, shield:684400, credits:2257000, uridium:1320, xp:60900, speed:100, damage:11770, color:'#ff8064', size:43, resources:{"Prometid":36,"Duranium":36,"Promerium":7,"Xenomit":2} },
  sentinelSupport: { name:'Sentinel Support', hp:1080000, shield:826000, credits:2684000, uridium:1560, xp:75400, speed:86, damage:13950, color:'#ff8a70', size:46, resources:{"Prometid":38,"Duranium":40,"Promerium":9,"Xenomit":3} },

  riftScout: { name:'Batedor da Fenda', hp:371200, shield:253000, credits:1003000, uridium:696, xp:24300, speed:96, damage:5615, color:'#4bdaff', size:33, resources:{"Prometid":27,"Duranium":27,"Promerium":4} },
  bossRiftScout: { name:'Batedor da Fenda Prime', hp:719200, shield:517500, credits:2124000, uridium:1392, xp:51300, speed:82, damage:10585, color:'#8ceaff', size:45, resources:{"Prometid":40,"Duranium":40,"Promerium":9,"Xenomit":2} },
  voidCorsair: { name:'Corsário do Vazio', hp:556800, shield:437000, credits:1475000, uridium:986, xp:37800, speed:94, damage:8210, color:'#e58cff', size:38, resources:{"Prometid":31,"Duranium":31,"Promerium":6,"Xenomit":1} },
  bossVoidCorsair: { name:'Corsário do Vazio Prime', hp:1067200, shield:874000, credits:3186000, uridium:1914, xp:78300, speed:78, damage:15660, color:'#ff9fd0', size:52, resources:{"Prometid":45,"Duranium":45,"Promerium":10,"Xenomit":3} },
  nexusWarden: { name:'Guardião Nexus', hp:840000, shield:731600, credits:2318000, uridium:1440, xp:62350, speed:82, damage:11990, color:'#7fffbb', size:44, resources:{"Prometid":38,"Duranium":38,"Promerium":8,"Xenomit":2} },
  bossNexusWarden: { name:'Guardião Nexus Prime', hp:1620000, shield:1357000, credits:4758000, uridium:2760, xp:124700, speed:68, damage:22455, color:'#9dffcf', size:58, resources:{"Prometid":54,"Duranium":54,"Promerium":13,"Xenomit":6} },
  astralReaper: { name:'Ceifador Astral', hp:1260000, shield:1038400, credits:3477000, uridium:2100, xp:92800, speed:108, damage:17005, color:'#c5fbff', size:48, resources:{"Prometid":43,"Duranium":43,"Promerium":9,"Xenomit":3} },
  bossAstralReaper: { name:'Ceifador Astral Prime', hp:2460000, shield:2006000, credits:7076000, uridium:4080, xp:191400, speed:86, damage:30955, color:'#fb4a8f', size:66, resources:{"Prometid":63,"Duranium":63,"Promerium":16,"Xenomit":9} },
};

// Catálogo preparado para mapas futuros. Estes aliens NÃO são usados nos mapas atuais.
export const FUTURE_ALIENS = {
  lordakiumSpore:{name:'Vrax Spore',hp:4000,shield:4000,damage:160,xp:400,credits:800,uridium:3,futureOnly:true},
  sibelonit:{name:'Colossar Spawn',hp:40000,shield:40000,damage:3200,xp:3200,credits:12800,uridium:12,futureOnly:true},
  bossSibelonit:{name:'Colossar Spawn Prime',hp:160000,shield:160000,damage:12800,xp:12800,credits:102400,uridium:48,futureOnly:true},
  uberSibelonit:{name:'Colossar Spawn Apex',hp:320000,shield:320000,damage:8000,xp:25600,credits:204800,uridium:96,futureOnly:true},
  lordakium:{name:'Vrax Overlord',hp:300000,shield:200000,damage:3600,xp:25600,credits:204800,uridium:64,futureOnly:true},
  bossLordakium:{name:'Vrax Overlord Prime',hp:1200000,shield:800000,damage:14400,xp:102400,credits:819200,uridium:256,futureOnly:true},
  uberLordakium:{name:'Vrax Overlord Apex',hp:2400000,shield:1600000,damage:32000,xp:204800,credits:1638400,uridium:512,futureOnly:true},
  kristallin:{name:'Crysalid',hp:50000,shield:40000,damage:1650,xp:6400,credits:12800,uridium:16,futureOnly:true},
  bossKristallin:{name:'Crysalid Prime',hp:200000,shield:160000,damage:4700,xp:25600,credits:51200,uridium:64,futureOnly:true},
  uberKristallin:{name:'Crysalid Apex',hp:400000,shield:320000,damage:13200,xp:51200,credits:102400,uridium:128,futureOnly:true},
  kristallon:{name:'Crysalon',hp:400000,shield:300000,damage:4450,xp:51200,credits:409600,uridium:128,futureOnly:true},
  bossKristallon:{name:'Crysalon Prime',hp:1600000,shield:1200000,damage:20000,xp:204800,credits:1638400,uridium:512,futureOnly:true},
  uberKristallon:{name:'Crysalon Apex',hp:3200000,shield:2400000,damage:40000,xp:490000,credits:3276800,uridium:1024,futureOnly:true},
  streuneR:{name:'Reaver',hp:40000,shield:30000,damage:3000,xp:6000,credits:12000,uridium:15,futureOnly:true},
  bossStreuneR:{name:'Reaver Prime',hp:80000,shield:40000,damage:2000,xp:12800,credits:25600,uridium:32,futureOnly:true},
  uberStreuneR:{name:'Reaver Apex',hp:320000,shield:240000,damage:7500,xp:48000,credits:96000,uridium:120,futureOnly:true},
  protegit:{name:'Wardrone',hp:50000,shield:40000,damage:1500,xp:6400,credits:12800,uridium:16,futureOnly:true},
  uberProtegit:{name:'Wardrone Apex',hp:400000,shield:320000,damage:12000,xp:51200,credits:102400,uridium:128,futureOnly:true},
  cubikon:{name:'Nexus Core',hp:1600000,shield:1200000,damage:0,xp:536200,credits:1638400,uridium:1024,futureOnly:true,spawns:'Protegit'},
  impulseII:{name:'Riftling II',hp:1200000,shield:750000,damage:null,xp:null,credits:200000,uridium:45,futureOnly:true},
  attendIX:{name:'Warden IX',hp:9000000,shield:4800000,damage:null,xp:null,credits:1000000,uridium:275,futureOnly:true},
  invokeXVI:{name:'Harbinger XVI',hp:36000000,shield:0,damage:null,xp:null,credits:9500000,uridium:2000,futureOnly:true},
  mindfireBehemoth:{name:'Pyre Behemoth',hp:135000000,shield:0,damage:null,xp:null,credits:200000000,uridium:5000,futureOnly:true},
  strokelightBarrage:{name:'Starfall Barrage',hp:4500000,shield:500000,damage:null,xp:null,credits:6500000,uridium:4000,futureOnly:true},
  emperorLordakium:{name:'Emperor Vrax',hp:9600000,shield:6800000,damage:45000,xp:768000,credits:2000000,uridium:9214,futureOnly:true},
  emperorKristallon:{name:'Emperor Crysalon',hp:14080000,shield:10560000,damage:60000,xp:1536000,credits:5000000,uridium:36864,futureOnly:true},
  emperorSibelon:{name:'Emperor Colossar',hp:6400000,shield:6400000,damage:35000,xp:409600,credits:1400000,uridium:4608,futureOnly:true},
};

export const MAPS = {
  x1: {
    id: 'x1', tier: 1, name: 'Fronteira Inicial', risk: 'Seguro', world: { w: 7200, h: 5400 }, enemyMultiplier: 1.60, ores: ['Prometium', 'Endurium'], oreCount: 44, landmarkCount: 6,
    palette: { nebula: '#123a52', accent: '#4fd7ff', deep: '#030916' },
    structures: ['Home Base', 'Mission Control', 'Trader', 'Hangar', 'Ship Repair', 'Company Hierarchy'],
    portals: [{ x: 6660, y: 2700, to: 'x2' }],
    enemyGroups: [{ type: 'streuner', count: 10 }, { type: 'recruitStreuner', count: 6 }, { type: 'aiderStreuner', count: 5 }],
  },
  x2: {
    id: 'x2', tier: 2, name: 'Nebulosa Azul', risk: 'Baixo', world: { w: 7900, h: 5800 }, enemyMultiplier: 1.60, ores: ['Prometium', 'Endurium', 'Terbium'], oreCount: 52, landmarkCount: 7,
    palette: { nebula: '#154d3e', accent: '#63e7bf', deep: '#030a12' },
    structures: ['Jump Gate X-1', 'Jump Gate X-3', 'Jump Gate X-4'],
    portals: [{ x: 503, y: 2900, to: 'x1' }, { x: 7325, y: 1088, to: 'x3' }, { x: 7325, y: 4712, to: 'x4' }],
    enemyGroups: [{ type: 'streuner', count: 7 }, { type: 'recruitStreuner', count: 5 }, { type: 'aiderStreuner', count: 5 }, { type: 'bossStreuner', count: 4 }, { type: 'lordakia', count: 8 }, { type: 'bossLordakia', count: 2 }],
  },
  x3: {
    id: 'x3', tier: 3, name: 'Cinturão Sombrio', risk: 'Médio', world: { w: 8650, h: 6250 }, enemyMultiplier: 1.70, ores: ['Endurium', 'Terbium'], oreCount: 58, landmarkCount: 8,
    palette: { nebula: '#4b2b58', accent: '#c978ff', deep: '#080512' },
    structures: ['Jump Gate X-2', 'Jump Gate X-4', 'Clan Battle Station'],
    portals: [{ x: 601, y: 3125, to: 'x2' }, { x: 8049, y: 3125, to: 'x4' }],
    enemyGroups: [{ type: 'lordakia', count: 7 }, { type: 'saimon', count: 7 }, { type: 'bossSaimon', count: 2 }, { type: 'mordon', count: 6 }, { type: 'bossMordon', count: 2 }, { type: 'devolarium', count: 2 }, { type: 'bossDevolarium', count: 1 }],
  },
  x4: {
    id: 'x4', tier: 4, name: 'Planícies de Fogo', risk: 'Alto', world: { w: 9400, h: 6750 }, enemyMultiplier: 1.75, ores: ['Endurium', 'Terbium'], oreCount: 64, landmarkCount: 9,
    palette: { nebula: '#173159', accent: '#66d9ff', deep: '#040a18' },
    structures: ['Jump Gate X-2', 'Jump Gate X-3', 'Battle Gate'],
    portals: [{ x: 675, y: 1326, to: 'x2' }, { x: 675, y: 5424, to: 'x3' }, { x: 8677, y: 3375, to: 'battleHome' }],
    enemyGroups: [{ type: 'lordakia', count: 5 }, { type: 'saimon', count: 6 }, { type: 'bossSaimon', count: 4 }, { type: 'mordon', count: 6 }, { type: 'sibelon', count: 3 }, { type: 'bossSibelon', count: 1 }],
  },
  x5: {
    id:'x5', tier:5, oreYield:2, minLevel:18, name:'Véu da Fenda', risk:'Alto', world:{w:10100,h:7300}, enemyMultiplier:1,
    ores:["Prometium", "Endurium", "Terbium"], oreCount:74, landmarkCount:10,
    palette:{nebula:'#133948',accent:'#51e5ff',deep:'#030b13'},
    structures:["Battle Gate 4-X", "Gate X-6"], portals:[],
    enemyGroups: [{ type: 'emberFang', count: 10 }, { type: 'bossEmberFang', count: 2 }, { type: 'ironWasp', count: 8 }, { type: 'bossIronWasp', count: 2 }],
  },
  x6: {
    id:'x6', tier:6, oreYield:3, minLevel:22, name:'Desfiladeiro Vazio', risk:'Crítico', world:{w:10700,h:7800}, enemyMultiplier:1,
    ores:["Prometium", "Endurium", "Terbium"], oreCount:81, landmarkCount:11,
    palette:{nebula:'#3a1d50',accent:'#d28fff',deep:'#0b0517'},
    structures:["Gate X-5", "Gate X-7"], portals:[],
    enemyGroups: [{ type: 'riftMauler', count: 8 }, { type: 'bossRiftMauler', count: 2 }, { type: 'obsidianPike', count: 7 }, { type: 'bossObsidianPike', count: 2 }],
  },
  x7: {
    id:'x7', tier:7, oreYield:4, minLevel:27, name:'Coração do Nexus', risk:'Extremo', world:{w:11300,h:8300}, enemyMultiplier:1,
    ores:["Prometium", "Endurium", "Terbium"], oreCount:88, landmarkCount:12,
    palette:{nebula:'#134637',accent:'#8cffb5',deep:'#030d0b'},
    structures:["Gate X-6", "Gate X-8"], portals:[],
    enemyGroups: [{ type: 'riftMauler', count: 5 }, { type: 'obsidianPike', count: 7 }, { type: 'bossObsidianPike', count: 3 }, { type: 'apexOverlord', count: 2 }],
  },
  x8: {
    id:'x8', tier:8, oreYield:5, minLevel:32, name:'Bastião Astral', risk:'Extremo', world:{w:12000,h:8900}, enemyMultiplier:1,
    ores:["Prometium", "Endurium", "Terbium"], oreCount:94, landmarkCount:13,
    palette:{nebula:'#4e243d',accent:'#ff947b',deep:'#120611'},
    structures:["Nova Base", "Trader", "Hangar", "Ship Repair", "Mission Control", "Gate X-7"], portals:[],
    enemyGroups: [{ type: 'sentinelScavenger', count: 7 }, { type: 'sentinelScout', count: 6 }, { type: 'sentinelSupport', count: 5 }],
  },
  b41: {
    id: 'b41', label: '4-1', tier: 41, battle: true, name: 'Deep Battle Alpha', risk: 'Extremo', world: { w: 11800, h: 8400 }, enemyMultiplier: 1.90, ores: [], oreCount: 0, landmarkCount: 10,
    palette: { nebula: '#29385d', accent: '#7ec8ff', deep: '#050814' },
    structures: ['Battle Gate 4-2', 'Battle Gate 4-3', 'Earth Battle Gate'],
    portals: [{ x: 900, y: 4200, to: 'x4HomeEarth' }, { x: 10800, y: 2280, to: 'b42' }, { x: 10800, y: 6120, to: 'b43' }],
    enemyGroups: [{ type: 'riftScout', count: 8 }, { type: 'bossRiftScout', count: 2 }, { type: 'voidCorsair', count: 6 }],
  },
  b42: {
    id: 'b42', label: '4-2', tier: 42, battle: true, name: 'Alien Core Beta', risk: 'Extremo', world: { w: 12500, h: 8900 }, enemyMultiplier: 2.00, ores: [], oreCount: 0, landmarkCount: 11,
    palette: { nebula: '#38442a', accent: '#8ee1a1', deep: '#050b12' },
    structures: ['Battle Gate 4-1', 'Battle Gate 4-3', 'Mars Battle Gate'],
    portals: [{ x: 960, y: 4440, to: 'x4HomeMars' }, { x: 11420, y: 2525, to: 'b41' }, { x: 11420, y: 6375, to: 'b43' }],
    enemyGroups: [{ type: 'voidCorsair', count: 8 }, { type: 'bossVoidCorsair', count: 3 }, { type: 'nexusWarden', count: 5 }],
  },
  b43: {
    id: 'b43', label: '4-3', tier: 43, battle: true, name: 'Abismo Vermelho', risk: 'Extremo', world: { w: 13500, h: 9600 }, enemyMultiplier: 2.20, ores: [], oreCount: 0, landmarkCount: 12,
    palette: { nebula: '#5d4421', accent: '#ffc65a', deep: '#0a0805' },
    structures: ['Battle Gate 4-1', 'Battle Gate 4-2', 'Jupiter Battle Gate'],
    portals: [{ x: 1020, y: 4800, to: 'x4HomeJupiter' }, { x: 12295, y: 2760, to: 'b41' }, { x: 12295, y: 6840, to: 'b42' }],
    enemyGroups: [{ type: 'nexusWarden', count: 8 }, { type: 'bossNexusWarden', count: 2 }, { type: 'astralReaper', count: 4 }, { type: 'bossNexusWarden', count: 1 }],
  },
  ggAlpha: {
    id: 'ggAlpha', label: 'AURORA', tier: 90, gate: true, battle: true, name: 'Portal Astral Alpha', risk: 'Portal',
    world: { w: 11500, h: 8500 }, enemyMultiplier: 1, ores: [], oreCount: 0, landmarkCount: 0,
    palette: { nebula: '#124b50', accent: '#62ffe0', deep: '#020e16' },
    structures: ['Portal Astral Alpha'], portals: [], enemyGroups: [],
  },
  ggBeta: {
    id: 'ggBeta', label: 'NEXUS', tier: 94, gate: true, battle: true, name: 'Portal Astral Beta', risk: 'Portal Elite',
    world: { w: 13200, h: 9600 }, enemyMultiplier: 1, ores: [], oreCount: 0, landmarkCount: 0,
    palette: { nebula: '#332052', accent: '#b49aff', deep: '#090819' },
    structures: ['Portal Astral Beta'], portals: [], enemyGroups: [],
  },
  ggGamma: {
    id: 'ggGamma', label: 'ECLIPSE', tier: 99, gate: true, battle: true, name: 'Portal Astral Gamma', risk: 'Portal Extremo',
    world: { w: 14800, h: 10800 }, enemyMultiplier: 1, ores: [], oreCount: 0, landmarkCount: 0,
    palette: { nebula: '#4d1627', accent: '#ff9b59', deep: '#12060e' },
    structures: ['Portal Astral Gamma'], portals: [], enemyGroups: [],
  },
};

/* STELLAR_SHIPS3D_FLEET_V50: 43 historic definitions preserved for backwards-compatible saves;
 * only the 13 approved classes are playable/marketable. */
{
 const allowed=new Set(["phoenix","leonov","liberator","piranha","vengeance","bigboy","goliath","citadel","aegis","spearhead","defcom","yamato","nostromo"]);
 for(const [id,ship] of Object.entries(SHIPS)){if(!allowed.has(id)){ship.shopAvailable=false;ship.auctionEligible=false;ship.eventOnly=true;ship.unavailableV50=true;}}
}
