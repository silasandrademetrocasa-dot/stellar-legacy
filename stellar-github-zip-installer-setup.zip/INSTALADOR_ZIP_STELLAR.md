# Instalador de ZIP — Stellar Legacy

Este workflow substitui o antigo **ChatGPT Deploy Bridge** por um instalador manual de versões completas em ZIP.

## Configuração única

1. No GitHub, abra `.github/workflows/main.yml`.
2. Substitua o conteúdo pelo arquivo `stellar-installer-main.yml`.
3. Faça o commit direto na `main`.

Depois disso, não é necessário substituir dezenas ou centenas de arquivos manualmente.

## Fluxo de atualização

1. Gere/receba um ZIP completo do projeto com nome começando por `stellar-legacy`, por exemplo:
   `stellar-legacy-v11.0.0.zip`.
2. Faça upload de **somente esse ZIP na raiz do repositório** e confirme o commit.
3. Abra a aba **Actions**.
4. Selecione **🚀 Instalar versão do Stellar Legacy**.
5. Clique em **Run workflow**.
6. O workflow:
   - localiza o único ZIP `stellar-legacy*.zip`;
   - valida caminhos e bloqueia ZIPs perigosos;
   - aceita pacote plano ou dentro de uma única pasta principal;
   - extrai em área temporária;
   - lê a versão do `package.json`;
   - sincroniza a nova versão com `rsync --delete`;
   - preserva `.git/` e `.github/` para não apagar o próprio instalador;
   - remove arquivos antigos que não existem mais no ZIP;
   - apaga o ZIP enviado;
   - valida `public/game.js`, `public/api.js`, `public/data.js` e `server/index.js`;
   - cria o commit `deploy: Stellar Legacy Vx.x.x via ZIP installer`;
   - envia o commit para a `main`.
7. Com o Render configurado para auto-deploy da `main`, a nova versão entra no deploy automaticamente.

## Regras do ZIP

O pacote deve conter no mínimo:

```text
package.json
public/
  game.js
  api.js
  data.js
server/
  index.js
```

Ele pode vir assim:

```text
stellar-legacy-v11.0.0.zip
  package.json
  public/
  server/
```

ou assim:

```text
stellar-legacy-v11.0.0.zip
  stellar-legacy-v11.0.0/
    package.json
    public/
    server/
```

## O que fica protegido

O instalador nunca substitui diretamente:

```text
.git/
.github/
```

Assim, um ZIP defeituoso não consegue apagar o workflow que faz a instalação.

## Limpeza automática

A instalação usa `rsync --delete`. Isso significa que, se um arquivo antigo existe no GitHub mas não existe no ZIP novo, ele é removido no mesmo commit. É exatamente o comportamento desejado para evitar acúmulo de changelogs, SQLs antigos e arquivos de versões anteriores.

## Em caso de erro

Se qualquer validação falhar, o commit/push não acontece. O jogo atual da `main` permanece intacto. Corrija o ZIP, apague o ZIP defeituoso do repositório se necessário, envie o novo pacote e rode novamente.
