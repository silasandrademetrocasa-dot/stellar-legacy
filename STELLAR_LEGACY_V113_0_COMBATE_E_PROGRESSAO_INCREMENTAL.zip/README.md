# STELLAR LEGACY V113.0 — COMBATE E PROGRESSÃO

Pacote INCREMENTAL cumulativo sobre a V112.0. Não substitui o projeto completo.

## Instalar
1. Na raiz do GitHub mantenha um único ZIP, este V113.0.
2. Execute o workflow `Instalador Universal`.
3. Após o Render atualizar, reabra o jogo com recarga forçada para carregar o novo game.js.
4. Abra painel ADM > Balanceamento ao Vivo > Auditoria V113 e confira números publicados.

## Conteúdo
- Rebalanceamento publicado no Supabase: 8 naves, 8 equipamentos, 25 NPCs/bosses, 4 categorias de missão e Passe de novembro.
- Três categorias de NPCs têm curvas próprias de recompensa/risco, mantendo spawns e respawns existentes.
- AUX NII agora custa 50M CR e NIII custa 180M CR, com recursos extras; propriedade, CONF1/2 e especializações antigas preservadas.
- Objetivos diários do Passe passam a escalar do nível 15 ao nível 44 sem exigir premium.
- Painel ADM com auditoria de risco/retorno, uma operação SOMENTE LEITURA.
- O teste integral de regressão foi executado localmente; testes de sessão real ainda são necessários.

## SQL
**O SQL V113 JÁ FOI APLICADO NO SUPABASE**, com backup dos valores antigos.
NÃO rodar migrations do ZIP novamente pelo workflow. Os scripts estão incluídos para histórico e eventual rollback manual.

## Proteções preservadas
Nenhum arquivo de Autopilot V112, Farm Offline V111.1, mundo, recompensas NPC ou dados de jogador é substituído. Drones não perdem slots. O ZIP não contém imagens ou arquivos de assets.

## Limites
O banco de produção foi alterado somente nas tabelas de configurações indicadas. Não rodamos teste de combate real nem liquidação de NPC/boss em produção; faça os cenários do documento `docs/v113/PLANO_BALANCEAMENTO_V113.md`.
