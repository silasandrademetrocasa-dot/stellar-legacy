/* Stellar Legacy V52: visual-only overlay, idempotent and fail-closed.
 * V50.1 must already exist. Player data, stats, economy, auth and SQL untouched.
 */
import fs from 'node:fs';
import assert from 'node:assert/strict';
const MARK='STELLAR_VISUAL_FLEET_V52_0';
const file='public/game.js';
assert(fs.existsSync(file),'V52 requer public/game.js');
let src=fs.readFileSync(file,'utf8');
assert(src.includes('STELLAR_SHIPS3D_FLEET_V50'),'V52 requer V50.1 instalada antes');
if(src.includes(MARK)){console.log('✅ V52 já aplicada');process.exit(0);}
assert(fs.existsSync('public/modules/stellar-ship3d-v50.js'),'V52 requer módulo V50');
assert(fs.readFileSync('public/modules/stellar-ship3d-v50.js','utf8').includes('STELLAR_V52_RENDER_UPGRADE'),'V52 módulo WebGL atualizado ausente');
for(const folder of ['public/assets/v52/models','public/assets/v52/cards'])assert(fs.existsSync(folder),`V52 requer ${folder}`);
function spliceOnce(needle,replace,label){const n=src.split(needle).length-1;if(n!==1)throw Error(`V52 ${label}: esperado 1 ocorrência, encontrado ${n}`);src=src.replace(needle,replace);}
const ships=['phoenix','leonov','liberator','piranha','vengeance','bigboy','goliath','citadel','aegis','spearhead','defcom','yamato','nostromo'];
const npcs=['streuner','recruitStreuner','aiderStreuner','bossStreuner','lordakia','bossLordakia','saimon','bossSaimon','mordon','bossMordon','devolarium','bossDevolarium','sibelon','bossSibelon'];
const ores=['Prometium','Endurium','Terbium','Prometid','Duranium','Promerium','Xenomit'];
const assetInit=`\n/* ${MARK}: same V50 GLB in gameplay and new card previews */
for(const id of ${JSON.stringify(ships)})GAME_ASSETS.ships[id]='/assets/v52/cards/ship_'+id+'.png';
for(const id of ${JSON.stringify(npcs)})GAME_ASSETS.npcs[id]='/assets/v52/cards/npc_'+id+'.png';
for(const id of ${JSON.stringify(ores)})GAME_ASSETS.resources[id]='/assets/v52/cards/ore_'+id+'.png';
GAME_ASSETS.drones.pet='/assets/v52/cards/aux9.png';
GAME_ASSETS.drones.petElite='/assets/v52/cards/aux9.png';
GAME_ASSETS.droneMap.pet='/assets/v52/cards/aux9.png';
GAME_ASSETS.droneMap.petElite='/assets/v52/cards/aux9.png';
GAME_ASSETS.bonus.box='/assets/v52/cards/box_bonus.png';
GAME_ASSETS.loot.cargo='/assets/v52/cards/box_loot.png';
STELLAR_3D_V50.preload('phoenix');
`;
const importAnchor="import { GAME_ASSETS } from './assets/v17/manifest.js?v=19.0.5';";
spliceOnce(importAnchor,importAnchor+assetInit,'visuals shared shop/hangar/aux/resources');
// AUX local and remote: use the same GLB in-game, with PNG fallback on low quality.
function insertInFn(start,end,needle,replace,label){const a=src.indexOf(start),b=src.indexOf(end,a+start.length);if(a<0||b<a)throw Error(`V52 ${label}: função ausente`);let seg=src.slice(a,b);const n=seg.split(needle).length-1;if(n!==1)throw Error(`V52 ${label}: âncora ${n}x`);seg=seg.replace(needle,replace);src=src.slice(0,a)+seg+src.slice(b);}
insertInFn('function drawPet(){','function drawShipModel(', 'if(img&&img.naturalWidth){', `if(resolvedQualityMode()!=='low'&&STELLAR_3D_V50.drawAssetAt(ctx,'aux9',petRuntime.angle||0,48,p.x,p.y)){/* Modelo AUX-9 3D */}\n  else if(img&&img.naturalWidth){`,'AUX map');
insertInFn('function drawRemotePet(rp){','function drawRemoteLaser(', 'if(img&&img.naturalWidth){', `if(resolvedQualityMode()!=='low'&&STELLAR_3D_V50.drawAssetAt(ctx,'aux9',q.angle||0,42,p.x,p.y)){/* Modelo AUX remoto */}\n  else if(img&&img.naturalWidth){`,'AUX remote');
insertInFn('function drawEnemy(e){','function drawDrones(', 'if(img&&img.naturalWidth){', `if(resolvedQualityMode()!=='low'&&STELLAR_3D_V50.drawAsset(ctx,'npc_'+e.type,Math.atan2(player.y-e.y,player.x-e.x),e.size*(boss?3.45:3.08))){drawNpcAuraLocal(e,boss,e.size*2.7);}\n  else if(img&&img.naturalWidth){`,'NPC GLB');
// Hint to loading images: UI shop and hangar use shipCardAsset()/droneCardAsset() automatically.
// Strong cache busting through versioned /assets/v52 path; no changes to images outside approved 13.
const out=`/* ${MARK} */\n`+src;
fs.writeFileSync(file,out);
console.log('✅ V52: 13 previews Loja+Hangar, AUX Loja+Equipamento+Mapa, 14 NPC classes, 7 minérios, box e loot, rotação 3D corrigida');
