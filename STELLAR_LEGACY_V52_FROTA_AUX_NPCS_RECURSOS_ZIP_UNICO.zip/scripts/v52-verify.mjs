import fs from 'node:fs';import assert from 'node:assert/strict';
import {decodeGlb,ALLOWED_SHIPS_V50} from '../public/modules/stellar-ship3d-v50.js';
const root='public/assets/v52',m=JSON.parse(fs.readFileSync(`${root}/manifest.json`,'utf8'));
assert.equal(Object.keys(m.ships).length,13,'13 naves oficiais');
assert.equal(Object.keys(m.npc).length,14,'14 arquétipos NPC incluindo bosses');
assert.equal(Object.keys(m.resources).length,7,'7 minérios');
for(const [id,row] of Object.entries(m.ships)){
 assert(ALLOWED_SHIPS_V50[id]);assert(fs.existsSync('public'+row.card),`card da nave ${id}`);
}
for(const r of [m.aux,...Object.values(m.npc),...Object.values(m.resources),...Object.values(m.loot)]){
 const path='public'+r.path;assert(fs.existsSync(path),`GLB ausente ${path}`);
 const data=fs.readFileSync(path),ab=data.buffer.slice(data.byteOffset,data.byteOffset+data.byteLength),parts=decodeGlb(ab);
 assert(parts.length>=1,`GLB sem peças ${path}`);
 assert(parts.reduce((n,p)=>n+p.indices.length/3,0)>20,`GLB vazio ${path}`);
 assert(fs.existsSync('public'+r.card),`prévia ausente ${r.card}`);
}
const game=fs.readFileSync('public/game.js','utf8');const renderer=fs.readFileSync('public/modules/stellar-ship3d-v50.js','utf8');
assert(game.includes('STELLAR_VISUAL_FLEET_V52_0'),'V52 não integrada no jogo');
assert(game.includes("drawAssetAt(ctx,'aux9'"),'AUX 3D não integrado');
assert(game.includes("drawAsset(ctx,'npc_'"),'NPC 3D não integrado');
assert(renderer.includes('Math.PI/2+angle'),'rotação corrigida ausente');
assert(renderer.includes('return {draw,drawAsset,drawAssetAt,preload,setMode,getMode'),'métodos do renderizador ausentes');
console.log('✅ V52: rotação 3D, 13 cards/13 naves, AUX, 14 NPCs, 7 minérios, bônus e loot, fallback');
