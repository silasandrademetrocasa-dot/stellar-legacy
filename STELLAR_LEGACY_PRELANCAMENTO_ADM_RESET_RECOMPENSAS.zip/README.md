# STELLAR LEGACY — Hotfix de pré-lançamento (V47.7.6)

## O que muda

1. Configurações: mostra FPS livre (rAF) nos perfis Baixa, Média e Alta. Preserva os FPS nominais internos de 45/60 do modo AUTO como **metas de ajuste automático**, não como limitadores de renderização; o limitador rAF já está desativado em todos os perfis.
2. ADM > ZERAR CONTA: a função SQL antiga continua fazendo o reset básico e é envolvida por uma função que limpa o progresso adicional, incrementa uma época de reset, invalida o save local antigo (mesmo que ele tenha data maior) e recusa restauração por upload desatualizado.
3. ADM > DELETAR: resolve relacionamentos que bloqueavam exclusão do Auth, preserva cupons criados para terceiros transferindo sua autoria para o ADM e só informa sucesso depois da exclusão confirmada.
4. Proteção dos saves com trigger no PostgreSQL contra corrida de um navegador antigo.
5. Inclui teste de regressão de FPS, reset e exclusão; mantém outros testes existentes.

## Instalação

**IMPORTANTE:** a instalação envolve DUAS etapas; a SQL é necessária.

1. Aplicar `sql/STELLAR_V47_8_0_PRELAUNCH_RESET_DELETE.sql` no Supabase. Este script NÃO zera ou deleta qualquer conta imediatamente; apenas atualiza as funções que são chamadas pelo ADM.
2. Enviar este ZIP sozinho para a raiz do GitHub e executar o Workflow `Stellar Legacy — Instalador Universal`. Os arquivos são aplicados durante a validação e enviados à main somente se todos os testes passarem.
3. Reabrir o jogo (atualização da página); no ADM escolher sua conta de teste, pressionar ZERAR CONTA e confirmar. Desconectar e autenticar novamente nesta mesma conta; seleção de facção e status inicial devem aparecer.
4. Testar a ação DELETAR apenas numa conta descartável, diferente da conta que será usada no teste de curva; depois da exclusão, o login anterior não deve funcionar.

Nenhuma conta foi zerada ou apagada na preparação do pacote.

## Atenção

- O fluxo sempre exige login válido e autorização real de administrador via Supabase.
- Limpeza local é feita após receber a época autoritativa do servidor. Se ficar sem conexão, progresso local antigo não deve ser considerado confiável até reconexão.
- Operações de exclusão de usuário removem informações; teste somente em contas com backup ou descartáveis.
- Sem novos prêmios automáticos; as taxas de recompensa foram preservadas, não rebalanceadas arbitrariamente.

## Auditoria de recompensas no Supabase (somente leitura, 22/10/2026)

Foram verificadas 9 categorias de integridade: catálogo de 22 NPCs, 1.667 entradas de recompensas NPC, chaves duplicadas de NPC, 12 registros de premiação diária da arena, datas duplicadas na arena, 56 estados de evento, 60 tiers de passe, 1 missão customizada e 5 configurações de evento. Não apareceram valores negativos, registros NPC duplicados pela chave de abate ou estados de prêmio inválidos nos critérios auditados. **Isso não substitui um teste real de entrega de recompensas**, nem comprova que todas as missões, chefes e passes foram acionados em produção.

## Roteiro sugerido: teste de curva de 2 horas

- 0–15 min: ADM reseta conta de teste, faz login com o mesmo acesso; não há níveis, equipamentos ou recursos antigos. Escolha nova facção e confirme bônus inicial.
- 15–45 min: derrotar NPCs de 2 mapas; comparar CR, STL e XP exibidos com o saldo que fica depois de sair/entrar; não deve pagar duas vezes pelo mesmo abate.
- 45–65 min: completar missões, coletar caixas, minério e passar níveis; reabrir cliente para confirmar progresso persistente.
- 65–85 min: arena e recompensa diária (um único resgate por dia); conferir pontuação/placar.
- 85–105 min: eventos e boss; verificar premiação e títulos/passe, sem duplicação ao atualizar.
- 105–120 min: relogar com o mesmo acesso, revisar hangar e recompensas acumuladas; rodar relatório FPS em Baixa/Média/Alta.

**A exclusão de contas deve ser testada apenas em uma conta descartável separada.**
