# V116.5 — Farm Offline: mensagens claras e recuperação assistida

Patch incremental para instalar **sobre a V116.4** (não substitui a versão cumulativa anterior).

## Interface
- Erros técnicos de resgate convertidos em instruções legíveis para o jogador.
- Erro de segurança de save, conflito com recompensas e falha de rede exibidos com orientação para preservar o Farm.
- Diagnóstico de save/perfil traduzido; nenhum identificador SQL mostrado ao jogador.
- Resgate, previsão e regras da economia continuam inalterados.

## Correção SQL
- Uma exceção de recuperação **somente para a sessão identificada e verificada do FELP22[ADM]** foi aplicada diretamente ao Supabase. A migração não depositou recompensas, não mudou saldos e não alterou inventário; o resgate continua a exigir clique do jogador e confirmação oficial.
- O caso foi validado por timestamp simultâneo de save/perfil na virada do dia, igualdade de saldos e ausência de recompensas de NPC ou minério online durante a sessão.
- Esta correção SQL de sessão **não precisa ser reaplicada** pelo Instalador Universal nem pelo usuário.
- Ela não equivale à autorização automática para outras sessões com conflito; os demais casos continuam protegidos pelas verificações anteriores.

## Uso
1. A V116.4 precisa já estar instalada. Envie somente este ZIP para a raiz do repositório e execute o Instalador Universal.
2. Após deploy, reabra o jogo para carregar as mensagens novas.
3. Na conta FELP22[ADM], pressione **Atualizar** e **Resgatar / Terminar**. **Não** pressione Cancelar sem ganhos.
4. Se a sessão continuar bloqueada, não tente reconstruir o save manualmente; registre o diagnóstico para auditoria.
