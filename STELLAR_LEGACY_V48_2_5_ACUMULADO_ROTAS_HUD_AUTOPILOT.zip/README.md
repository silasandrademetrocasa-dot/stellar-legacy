# STELLAR LEGACY V48.2.5 — PACOTE ACUMULADO

Base: V48.2.2 instalada, release `47.7.6`.

- **V48.2.4**: NAVE com CONF 1/2 no cabeçalho, PORÃO + VEL na mesma linha e painel recolhido só com a seta. O texto técnico de reconciliação vira log, não aviso para o jogador.
- **V48.2.5**: Mapa de Rotas padronizado visualmente em Terra/Marte/Júpiter. ADM vê TODOS e pode filtrar facções. Portais e desbloqueios são os mesmos do servidor.
- **Autopilot**: preserva sessão em reconexões curtas de até 20 s durante trocas de mapa, continua pela rota selecionada após vender e reabastecer. Na base X-1 compra usando loja normal oficial, sem exigir CPU. Fora da base o AUTO BUY permanece condicionado ao CPU equipado e confirmado no servidor. Conserva orçamento configurado e preços do LIVE OPS.

**Importante**: não faz reparo de rollback de XP. A divergência XP/telemetria continua sob investigação. Nada é creditado artificialmente.

Instalação: remover ZIP antigo da raiz, enviar só este ZIP, executar o Instalador Universal e verificar GitHub Actions/Render. **Sem SQL.**
