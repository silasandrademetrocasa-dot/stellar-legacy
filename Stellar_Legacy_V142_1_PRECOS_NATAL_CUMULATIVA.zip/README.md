V142.1 cumulativa para V141 ou V142. SQL já aplicado. Use o workflow habitual e leia README_V142_1.md.
