# Stellar Legacy V47.7.5 — Frontier U-X + Target Lock Final

Patch incremental baseado na V47.7.4 publicada no GitHub. **Não é um projeto completo.** Carregar somente o ZIP na raiz do repositório e executar o Instalador Universal. O workflow remove o ZIP somente após todos os testes passarem.

## Correções

- U-1, U-2, U-3: a sala WebSocket usa a facção **validada pelo servidor**, independentemente do valor de interface `territoryFaction: "battle"`. O SQL mantém o nó U neutro e cada facção recebe sua própria sala. Normalizamos somente U-X; a proteção territorial X-1..X-8 e a regra de nível dos jogadores permanecem.
- Ao ocorrer recusa, o usuário recebe a causa do servidor em vez da mensagem genérica de nível/ADM. Não concede qualquer privilégio administrativo.
- TARGET LOCK recolhido em mobile: esconde `PRÓXIMO`, mantém botão de expansão centralizado e clicável em quadrado 40 × 40, sem cortar o HUD.
- Pente fino: testes de facções, zonas de acesso, níveis, CSS compacto e manutenção de FPS, eventos e economia. Nenhum SQL, save, inventário ou mudança de sprites.

## Testes

- Rodar `npm run check`, `npm run check:v21` e `npm test` no GitHub Actions para a validação completa. Os testes locais de unidade e de aplicação do patch são auxiliares e não simulam uma partida real de Android.
- Teste manual: entrar no U-1 a partir de 1-8, confirmar "UNIVERSO SINCRONIZADO" e NPCs; atravessar U-2/U-3; minimizar e restaurar TARGET LOCK; conferir FPS no modo BAIXA.

## Infraestrutura

Mantenha Render e Supabase atuais. Não existe alteração de SQL nesta versão.
